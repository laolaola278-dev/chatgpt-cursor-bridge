(function() {
  "use strict";
  class BridgeUnavailableError extends Error {
    code = "bridge_unavailable";
    constructor(message = "Local Bridge unavailable") {
      super(message);
      this.name = "BridgeUnavailableError";
    }
  }
  class BridgeRequestError extends Error {
    code;
    status;
    constructor(status, code, message) {
      super(message);
      this.name = "BridgeRequestError";
      this.status = status;
      this.code = code;
    }
  }
  const DEFAULT_BRIDGE_ORIGIN = "http://127.0.0.1:8765";
  const DEFAULT_TIMEOUT_MS = 8e3;
  class BridgeClient {
    origin;
    timeoutMs;
    fetchImpl;
    constructor(options = {}) {
      this.origin = (options.origin ?? DEFAULT_BRIDGE_ORIGIN).replace(/\/+$/, "");
      this.timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
      this.fetchImpl = options.fetchImpl ?? globalThis.fetch.bind(globalThis);
    }
    get baseUrl() {
      return this.origin;
    }
    async request(path, init = {}) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), this.timeoutMs);
      let response;
      try {
        response = await this.fetchImpl(`${this.origin}${path}`, {
          ...init,
          signal: controller.signal,
          headers: {
            "Content-Type": "application/json",
            ...init.headers ?? {}
          }
        });
      } catch {
        throw new BridgeUnavailableError(
          "Local Bridge unavailable. Start it with: uvicorn app.main:app --port 8765"
        );
      } finally {
        clearTimeout(timer);
      }
      const text2 = await response.text();
      let body = null;
      if (text2) {
        try {
          body = JSON.parse(text2);
        } catch {
          body = null;
        }
      }
      if (!response.ok) {
        const errorBody = body ?? {};
        throw new BridgeRequestError(
          response.status,
          errorBody.error ?? "bridge_error",
          errorBody.message ?? `Bridge returned HTTP ${response.status}`
        );
      }
      return body;
    }
    health() {
      return this.request("/health");
    }
    listProjects() {
      return this.request("/workspace/list");
    }
    readFile(project, path) {
      const query = `?project=${encodeURIComponent(project)}&path=${encodeURIComponent(path)}`;
      return this.request(`/file/read${query}`);
    }
    createFile(body) {
      return this.request("/file/create", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    writeFile(body) {
      return this.request("/file/write", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    applyPatch(body) {
      return this.request("/patch/apply", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    approve(requestId) {
      return this.request("/permission/approve", {
        method: "POST",
        body: JSON.stringify({ request_id: requestId })
      });
    }
    reconfirm(requestId) {
      return this.request("/permission/reconfirm", {
        method: "POST",
        body: JSON.stringify({ request_id: requestId })
      });
    }
    rejectApproval(requestId, reason = "Rejected by user") {
      return this.request("/permission/reject", {
        method: "POST",
        body: JSON.stringify({ request_id: requestId, reason })
      });
    }
    // -- Memory (Phase 3) ------------------------------------------------
    readMemory(project, document2) {
      const query = `?project=${encodeURIComponent(project)}&document=${encodeURIComponent(document2)}`;
      return this.request(`/memory/read${query}`);
    }
    memoryStatus(project) {
      return this.request(
        `/memory/status?project=${encodeURIComponent(project)}`
      );
    }
    gitStatus(project) {
      return this.request(`/git/status?project=${encodeURIComponent(project)}`);
    }
    gitDiff(project, staged = false) {
      return this.request(
        `/git/diff?project=${encodeURIComponent(project)}&staged=${String(staged)}`
      );
    }
    workflowStatus(workflowId) {
      return this.request(`/workflow/${encodeURIComponent(workflowId)}`);
    }
    systemHealth() {
      return this.request("/system/health");
    }
    projectContext(project) {
      return this.request(`/context/project?project=${encodeURIComponent(project)}`);
    }
    pendingApprovals() {
      return this.request("/permission/pending");
    }
    contextSearch(query = "", options = {}) {
      const params = new URLSearchParams({ q: query });
      if (options.project) params.set("project", options.project);
      if (options.from) params.set("from", options.from);
      if (options.to) params.set("to", options.to);
      return this.request(`/context/search?${params.toString()}`);
    }
    sessionList(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/session/list${query}`);
    }
    agentStatus(project, task) {
      const params = new URLSearchParams();
      if (project) params.set("project", project);
      if (task) params.set("task", task);
      const query = params.toString() ? `?${params.toString()}` : "";
      return this.request(`/agent/status${query}`);
    }
    modelRoute(task) {
      return this.request(`/model-router/route?task=${encodeURIComponent(task)}`);
    }
    runtimeStatus() {
      return this.request("/runtime/status");
    }
    runtimeEvents(limit = 100) {
      return this.request(`/runtime/events?limit=${encodeURIComponent(String(limit))}`);
    }
    taskList(status) {
      const query = status ? `?status=${encodeURIComponent(status)}` : "";
      return this.request(`/task/list${query}`);
    }
    quality(workflowId) {
      return this.request(`/quality/${encodeURIComponent(workflowId)}`);
    }
    teamList(workflowId) {
      const query = workflowId ? `?workflow_id=${encodeURIComponent(workflowId)}` : "";
      return this.request(`/team/list${query}`);
    }
    taskDependencies(taskId) {
      return this.request(`/task/${encodeURIComponent(taskId)}/dependencies`);
    }
    collaborationEvents(limit = 100) {
      return this.request(`/collaboration/events?limit=${encodeURIComponent(String(limit))}`);
    }
    projectProfile(project) {
      return this.request(`/project/profile?project=${encodeURIComponent(project)}`);
    }
    projectGraph(project) {
      return this.request(`/project/graph?project=${encodeURIComponent(project)}`);
    }
    impactAnalysis(project, changedFiles = []) {
      const params = new URLSearchParams({ project });
      for (const file of changedFiles) params.append("changed_file", file);
      return this.request(`/impact/analyze?${params.toString()}`);
    }
    projectMemoryHistory(project) {
      return this.request(`/memory/project/history?project=${encodeURIComponent(project)}`);
    }
    intelligenceInsights(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/intelligence/insights${query}`);
    }
    intelligenceProposals(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/intelligence/proposals${query}`);
    }
    intelligenceDecisions(project) {
      return this.request(`/intelligence/decisions?project=${encodeURIComponent(project)}`);
    }
    intelligenceQuality(workflowId) {
      return this.request(`/quality/v5/${encodeURIComponent(workflowId)}`);
    }
    // -- Phase 25 Engineering Intelligence Evolution (GET only) ----------
    intelligenceObservations(project) {
      return this.request(`/intelligence/observations?project=${encodeURIComponent(project)}`);
    }
    intelligencePatterns(project) {
      return this.request(`/intelligence/patterns?project=${encodeURIComponent(project)}`);
    }
    intelligencePredictions(project) {
      return this.request(`/intelligence/predictions?project=${encodeURIComponent(project)}`);
    }
    intelligenceRecommendations(project) {
      return this.request(`/intelligence/recommendations?project=${encodeURIComponent(project)}`);
    }
    intelligenceOutcomes(project) {
      return this.request(`/intelligence/outcomes?project=${encodeURIComponent(project)}`);
    }
    intelligenceKnowledge(project) {
      return this.request(`/intelligence/knowledge?project=${encodeURIComponent(project)}`);
    }
    intelligenceEvidence(project) {
      return this.request(`/intelligence/evidence?project=${encodeURIComponent(project)}`);
    }
    intelligenceQuality11(project) {
      return this.request(`/intelligence/quality?project=${encodeURIComponent(project)}`);
    }
    // -- Phase 26 Engineering Intelligence 2.0 (GET only) ----------------
    intelligenceTrends(project, metric, period = "daily") {
      const params = new URLSearchParams({ project, period });
      if (metric) params.set("metric", metric);
      return this.request(`/intelligence/trends?${params.toString()}`);
    }
    intelligenceCorrelations(project) {
      return this.request(`/intelligence/correlations?project=${encodeURIComponent(project)}`);
    }
    intelligenceImpact(project, changedFiles = [], changedSymbols = []) {
      const params = new URLSearchParams({ project });
      for (const file of changedFiles) params.append("changed_file", file);
      for (const symbol of changedSymbols) params.append("changed_symbol", symbol);
      return this.request(`/intelligence/impact?${params.toString()}`);
    }
    intelligenceDependencies(project) {
      return this.request(`/intelligence/dependencies?project=${encodeURIComponent(project)}`);
    }
    intelligenceEvaluations(project) {
      return this.request(`/intelligence/evaluations?project=${encodeURIComponent(project)}`);
    }
    intelligenceRecommendationRanking(project) {
      return this.request(`/intelligence/recommendations/ranking?project=${encodeURIComponent(project)}`);
    }
    intelligenceEvidenceGraph(project) {
      return this.request(`/intelligence/evidence/graph?project=${encodeURIComponent(project)}`);
    }
    // -- Phase 27 Engineering Intelligence Validation (GET only) ----------
    intelligenceValidation(project) {
      return this.request(`/intelligence/validation?project=${encodeURIComponent(project)}`);
    }
    intelligenceAccuracy(project, filters = {}) {
      const params = new URLSearchParams({ project });
      if (filters.agentId) params.set("agent_id", filters.agentId);
      if (filters.modelId) params.set("model_id", filters.modelId);
      if (filters.kind) params.set("kind", filters.kind);
      return this.request(`/intelligence/accuracy?${params.toString()}`);
    }
    intelligenceEffectiveness(project) {
      return this.request(`/intelligence/effectiveness?project=${encodeURIComponent(project)}`);
    }
    intelligenceDecisionOutcomes(project) {
      return this.request(`/intelligence/decision-outcomes?project=${encodeURIComponent(project)}`);
    }
    intelligenceBenchmarks(project) {
      return this.request(`/intelligence/benchmarks?project=${encodeURIComponent(project)}`);
    }
    intelligenceKnowledgeImprovements(project, status) {
      const params = new URLSearchParams({ project });
      if (status) params.set("status", status);
      return this.request(`/intelligence/knowledge/improvements?${params.toString()}`);
    }
    // -- Phase 28 Engineering Intelligence Governance (GET only) ------------
    intelligenceGovernance(project) {
      return this.request(`/intelligence/governance?project=${encodeURIComponent(project)}`);
    }
    intelligenceGovernanceRisks(project, filters = {}) {
      const params = new URLSearchParams({ project });
      if (filters.riskLevel) params.set("risk_level", filters.riskLevel);
      if (filters.sourceKind) params.set("source_kind", filters.sourceKind);
      if (filters.agentId) params.set("agent_id", filters.agentId);
      return this.request(`/intelligence/governance/risk?${params.toString()}`);
    }
    intelligenceGovernanceTrends(project, period = "weekly") {
      const params = new URLSearchParams({ project, period });
      return this.request(`/intelligence/governance/trends?${params.toString()}`);
    }
    intelligenceGovernancePolicies(project, scope) {
      const params = new URLSearchParams({ project });
      if (scope) params.set("scope", scope);
      return this.request(`/intelligence/governance/policies?${params.toString()}`);
    }
    intelligenceGovernanceViolations(project, severity) {
      const params = new URLSearchParams({ project });
      if (severity) params.set("severity", severity);
      return this.request(`/intelligence/governance/violations?${params.toString()}`);
    }
    intelligenceGovernanceReviews(project, status) {
      const params = new URLSearchParams({ project });
      if (status) params.set("status", status);
      return this.request(`/intelligence/governance/reviews?${params.toString()}`);
    }
    intelligenceGovernanceQualityGate(project) {
      return this.request(`/intelligence/governance/quality-gate?project=${encodeURIComponent(project)}`);
    }
    intelligenceGovernanceGraph(project) {
      return this.request(`/intelligence/governance/graph?project=${encodeURIComponent(project)}`);
    }
    // -- Phase 29 Advanced Developer Context (GET only) ----------------------
    devContextBundle(project, agent = "ASSISTANT") {
      const params = new URLSearchParams({ project, agent });
      return this.request(`/context/dev/bundle?${params.toString()}`);
    }
    devProjectContext(project) {
      return this.request(`/context/dev/project?project=${encodeURIComponent(project)}`);
    }
    devFiles(project, limit = 200) {
      return this.request(`/context/dev/files?project=${encodeURIComponent(project)}&limit=${limit}`);
    }
    devFile(project, path, maxFileKb = 256) {
      const params = new URLSearchParams({ project, max_file_kb: String(maxFileKb) });
      return this.request(`/context/dev/file/${encodeURIComponent(path)}?${params.toString()}`);
    }
    devSymbols(project, q = "", limit = 200) {
      const params = new URLSearchParams({ project, limit: String(limit) });
      if (q) params.set("q", q);
      return this.request(`/context/dev/symbols?${params.toString()}`);
    }
    devSymbol(project, symbolId) {
      return this.request(`/context/dev/symbol/${symbolId}?project=${encodeURIComponent(project)}`);
    }
    devDependencies(project, limit = 200) {
      return this.request(`/context/dev/dependencies?project=${encodeURIComponent(project)}&limit=${limit}`);
    }
    devGit(project) {
      return this.request(`/context/dev/git?project=${encodeURIComponent(project)}`);
    }
    devTests(project) {
      return this.request(`/context/dev/tests?project=${encodeURIComponent(project)}`);
    }
    devContextStatus(project) {
      return this.request(`/context/dev/status?project=${encodeURIComponent(project)}`);
    }
    // -- Phase 30 Context Intelligence (GET only) ----------------------------
    contextIntelligenceSuggest(project, query = "", options = {}) {
      const params = new URLSearchParams({ project });
      if (query) params.set("query", query);
      if (options.agent) params.set("agent", options.agent);
      if (options.selectedPath) params.set("selected_path", options.selectedPath);
      if (options.selectedText) params.set("selected_text", options.selectedText);
      if (options.error) params.set("error", options.error);
      if (options.testFailure) params.set("test_failure", options.testFailure);
      if (options.limit) params.set("limit", String(options.limit));
      return this.request(`/context/dev/intelligence/suggest?${params.toString()}`);
    }
    contextIntelligenceRelationships(project, file, symbol) {
      const params = new URLSearchParams({ project });
      if (file) params.set("file", file);
      if (symbol) params.set("symbol", symbol);
      return this.request(`/context/dev/intelligence/relationships?${params.toString()}`);
    }
    contextIntelligenceError(project, error, options = {}) {
      const params = new URLSearchParams({ project, error });
      if (options.stackTrace) params.set("stack_trace", options.stackTrace);
      if (options.testFailure) params.set("test_failure", options.testFailure);
      if (options.file) params.set("file", options.file);
      return this.request(`/context/dev/intelligence/error?${params.toString()}`);
    }
    contextIntelligenceTestFailure(project, test, options = {}) {
      const params = new URLSearchParams({ project, test });
      if (options.failure) params.set("failure", options.failure);
      if (options.expected) params.set("expected", options.expected);
      if (options.actual) params.set("actual", options.actual);
      if (options.traceback) params.set("traceback", options.traceback);
      return this.request(`/context/dev/intelligence/test-failure?${params.toString()}`);
    }
    contextIntelligenceGit(project) {
      return this.request(`/context/dev/intelligence/git?project=${encodeURIComponent(project)}`);
    }
    contextIntelligenceReview(project, options = {}) {
      const params = new URLSearchParams({ project });
      if (options.file) params.set("file", options.file);
      if (options.symbol) params.set("symbol", options.symbol);
      if (options.selection) params.set("selection", options.selection);
      if (options.diff) params.set("diff", options.diff);
      return this.request(`/context/dev/intelligence/review?${params.toString()}`);
    }
    contextIntelligenceInjection(project, text2, source = "project_content") {
      const params = new URLSearchParams({ project, text: text2, source });
      return this.request(`/context/dev/intelligence/injection?${params.toString()}`);
    }
    contextIntelligenceBudget(project, query = "") {
      const params = new URLSearchParams({ project });
      if (query) params.set("query", query);
      return this.request(`/context/dev/intelligence/budget?${params.toString()}`);
    }
    contextIntelligenceSnapshot(project) {
      return this.request(`/context/dev/intelligence/snapshot?project=${encodeURIComponent(project)}`);
    }
    stagePatchProposal(body) {
      return this.request("/context/dev/intelligence/patch-proposal", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    // -- Phase 31 LLM Gateway (stateless chat + read-only registry) --------
    llmProviders() {
      return this.request(`/llm/providers`);
    }
    llmModels(provider = "") {
      const query = provider ? `?provider=${encodeURIComponent(provider)}` : "";
      return this.request(`/llm/models${query}`);
    }
    llmConversations(project) {
      return this.request(`/llm/conversations?project=${encodeURIComponent(project)}`);
    }
    llmConversationDetail(conversationId, project) {
      return this.request(`/llm/conversations/${encodeURIComponent(conversationId)}?project=${encodeURIComponent(project)}`);
    }
    llmToolProposals(project) {
      return this.request(`/llm/tool-proposals?project=${encodeURIComponent(project)}`);
    }
    llmChat(body) {
      return this.request("/llm/chat", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    llmConversationCreate(body) {
      return this.request("/llm/conversations", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    llmConversationMessage(body, conversationId) {
      return this.request(`/llm/conversations/${encodeURIComponent(conversationId)}/messages`, {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    llmToolProposal(body, conversationId) {
      return this.request(`/llm/conversations/${encodeURIComponent(conversationId)}/tool-proposal`, {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    // -- Phase 32 AI Assistant (settings, providers, context, chat) ---------
    //
    // `providerConfig` is the only method that carries an API key. The key is a
    // transient argument taken straight from the Settings input: it is posted to
    // the Bridge (which encrypts it with AES-256-GCM), never stored in extension
    // state, never logged and never placed in a URL or query parameter.
    userSettings() {
      return this.request("/user/settings");
    }
    providerStatus() {
      return this.request("/provider/status");
    }
    providerTest(body) {
      return this.request("/provider/test", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    /** Approval-gated: returns a pending request; activation needs a human. */
    providerConfig(body) {
      return this.request("/provider/config", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    /** Approval-gated: deletes the stored (encrypted) credential once approved. */
    providerForget(body) {
      return this.request("/provider/forget", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    /** Approval-gated: non-sensitive preferences only (mode, provider, model…). */
    userSettingsUpdate(body) {
      return this.request("/user/settings", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    contextStatus(project = "", scope = "user") {
      const query = new URLSearchParams();
      if (project) query.set("project", project);
      query.set("scope", scope);
      return this.request(`/context/status?${query.toString()}`);
    }
    /**
     * Stateless assistant chat. `web_context` is only ever populated from a
     * bundle the user produced by clicking Ask AI; the Bridge rejects any bundle
     * without that explicit trigger.
     */
    assistantChat(body) {
      return this.request("/assistant/chat", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    /**
     * Streams assistant tokens over SSE. `signal` is the Stop button: aborting
     * ends the stream and never schedules a retry.
     */
    async assistantChatStream(body, options) {
      let response;
      try {
        response = await this.fetchImpl(`${this.origin}/assistant/chat/stream`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
          signal: options.signal
        });
      } catch {
        throw new BridgeUnavailableError(
          "Local Bridge unavailable. Start it with: uvicorn app.main:app --port 8765"
        );
      }
      if (!response.ok) {
        let code = "stream_failed";
        try {
          const raw = await response.text();
          const parsed = raw ? JSON.parse(raw) : null;
          const reported = parsed?.error ?? parsed?.code;
          if (typeof reported === "string" && reported) code = reported;
        } catch {
        }
        throw new BridgeRequestError(response.status, code, `Assistant stream failed (${response.status})`);
      }
      const emit = (frame) => {
        for (const line2 of frame.split("\n")) {
          if (!line2.startsWith("data:")) continue;
          const payload = line2.slice(5).trim();
          if (!payload) continue;
          try {
            options.onEvent(JSON.parse(payload));
          } catch {
          }
        }
      };
      const reader = response.body?.getReader();
      if (!reader) {
        emit(await response.text());
        return;
      }
      const decoder = new TextDecoder();
      let buffer = "";
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const frames = buffer.split("\n\n");
        buffer = frames.pop() ?? "";
        for (const frame of frames) emit(frame);
      }
      if (buffer.trim()) emit(buffer);
    }
    // -- Phase 27 staging helpers (approval-gated POST; never auto-execute) --
    stageEvaluation(body) {
      return this.request("/intelligence/evaluation", { method: "POST", body: JSON.stringify(body) });
    }
    stageBenchmarkRun(body) {
      return this.request("/intelligence/benchmark/run", { method: "POST", body: JSON.stringify(body) });
    }
    stageKnowledgeImprovement(body) {
      return this.request("/intelligence/knowledge/improvements/propose", { method: "POST", body: JSON.stringify(body) });
    }
    simulation(simulationId) {
      return this.request(`/simulation/${encodeURIComponent(simulationId)}`);
    }
    simulationScenarios(simulationId) {
      return this.request(`/simulation/${encodeURIComponent(simulationId)}/scenarios`);
    }
    simulationEvaluation(simulationId) {
      return this.request(`/simulation/${encodeURIComponent(simulationId)}/evaluation`);
    }
    simulationPlans(simulationId) {
      return this.request(`/simulation/${encodeURIComponent(simulationId)}`).then((result) => ({ simulationId, plans: result.plans ?? [], readOnly: true }));
    }
    simulationQuality(workflowId) {
      return this.request(`/quality/v6/${encodeURIComponent(workflowId)}`);
    }
    planningMemoryHistory(project) {
      return this.request(`/memory/planning/history?project=${encodeURIComponent(project)}`);
    }
    executionTasks(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/execution/tasks${query}`);
    }
    executionProposals(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/execution/proposals${query}`);
    }
    executionResults(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/execution/results${query}`);
    }
    executionVerify(executionId) {
      return this.request(`/execution/${encodeURIComponent(executionId)}/verify`);
    }
    executionQuality7(workflowId) {
      return this.request(`/quality/v7/${encodeURIComponent(workflowId)}`);
    }
    executionMemoryHistory(project) {
      return this.request(`/memory/execution/history?project=${encodeURIComponent(project)}`);
    }
    executionLoopList(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/execution-loop/list${query}`);
    }
    executionDagList(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/execution-dag/list${query}`);
    }
    executionDag(dagId) {
      return this.request(`/execution-dag/${encodeURIComponent(dagId)}`);
    }
    executionDagReady(dagId) {
      return this.request(`/execution-dag/${encodeURIComponent(dagId)}/ready`);
    }
    engineeringMetrics(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/engineering/metrics${query}`);
    }
    executionLoopContext(loopId) {
      return this.request(`/execution-loop/${encodeURIComponent(loopId)}/context`);
    }
    engineeringGraph(project) {
      return this.request(`/engineering-graph/${encodeURIComponent(project)}`);
    }
    failurePatterns(project) {
      return this.request(`/failure-intelligence/patterns?project=${encodeURIComponent(project)}`);
    }
    evolutionTimeline(project) {
      return this.request(`/memory/evolution/history?project=${encodeURIComponent(project)}`);
    }
    agentCapabilityMetrics() {
      return this.request("/engineering/agent-metrics");
    }
    benchmarkList(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/benchmark/list${query}`);
    }
    demoCatalog() {
      return this.request("/demo/catalog");
    }
    demoFlow() {
      return this.request("/demo/flow");
    }
    replayList(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/replay/list${query}`);
    }
    artifactList(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/artifacts${query}`);
    }
    governanceHealth(project) {
      return this.request(`/governance/health/${encodeURIComponent(project)}`);
    }
    governanceDrift(project) {
      return this.request(`/governance/drift/${encodeURIComponent(project)}`);
    }
    governanceDebt(project, status) {
      const query = status ? `?status=${encodeURIComponent(status)}` : "";
      return this.request(`/governance/debt/${encodeURIComponent(project)}${query}`);
    }
    governancePolicies(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/governance/policies${query}`);
    }
    governanceTimeline(project) {
      return this.request(`/governance/timeline?project=${encodeURIComponent(project)}`);
    }
    governanceQuality9(workflowId) {
      return this.request(`/quality/v9/${encodeURIComponent(workflowId)}`);
    }
    organizationGraph() {
      return this.request("/organization/graph");
    }
    organizationHealth() {
      return this.request("/organization/health");
    }
    organizationDashboard() {
      return this.request("/organization/dashboard");
    }
    organizationPatterns(category) {
      const query = category ? `?category=${encodeURIComponent(category)}` : "";
      return this.request(`/organization/patterns${query}`);
    }
    organizationIncidents(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/organization/incidents${query}`);
    }
    organizationDecisions(project) {
      const query = project ? `?project=${encodeURIComponent(project)}` : "";
      return this.request(`/organization/decisions${query}`);
    }
    organizationLearningSimilar(project, signature, category) {
      let query = `project=${encodeURIComponent(project)}`;
      if (signature) query += `&signature=${encodeURIComponent(signature)}`;
      if (category) query += `&category=${encodeURIComponent(category)}`;
      return this.request(`/organization/learning/similar?${query}`);
    }
    organizationQuality10(org) {
      return this.request(`/quality/v10/${encodeURIComponent(org)}`);
    }
    organizationImpact(nodeId) {
      return this.request(`/organization/impact/${encodeURIComponent(nodeId)}`);
    }
    organizationRisk(nodeId, severity = "medium", likelihood = "medium") {
      const query = `?severity=${encodeURIComponent(severity)}&likelihood=${encodeURIComponent(likelihood)}`;
      return this.request(`/organization/risk/${encodeURIComponent(nodeId)}${query}`);
    }
    organizationStrategies(project) {
      return this.request(`/organization/strategies/${encodeURIComponent(project)}`);
    }
    organizationRecommendations() {
      return this.request("/organization/recommendations");
    }
    organizationStrategyDetail(strategyId) {
      return this.request(`/organization/strategy/${encodeURIComponent(strategyId)}`);
    }
    organizationDecisionDetail(decisionId) {
      return this.request(`/organization/decision/${encodeURIComponent(decisionId)}`);
    }
    organizationSimulationDetail(simulationId) {
      return this.request(`/organization/simulation/${encodeURIComponent(simulationId)}`);
    }
    organizationContext() {
      return this.request("/organization/context");
    }
    executionLoop(loopId) {
      return this.request(`/execution-loop/${encodeURIComponent(loopId)}`);
    }
    executionLoopTimeline(loopId) {
      return this.request(`/execution-loop/${encodeURIComponent(loopId)}/timeline`);
    }
    executionLoopQuality8(workflowId) {
      return this.request(`/quality/v8/${encodeURIComponent(workflowId)}`);
    }
    runTest(body) {
      return this.request("/test/run", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    appendMemory(body) {
      return this.request("/memory/append", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    recordDecision(body) {
      return this.request("/memory/decision", {
        method: "POST",
        body: JSON.stringify(body)
      });
    }
    /**
     * Stage a mutating action on the Bridge. Returns the pending approval
     * request; nothing is written to disk until `approve()` is called.
     */
    stage(action) {
      const { project, path } = action.target;
      const reason = action.reason;
      switch (action.action) {
        case "file.create":
          return this.createFile({ project, path, content: action.payload.content ?? "", reason });
        case "file.write":
          return this.writeFile({ project, path, content: action.payload.content ?? "", reason });
        case "file.patch":
          return this.applyPatch({ project, path, patch: action.payload.patch ?? "", reason });
        case "memory.append":
          return this.appendMemory({
            project,
            document: action.target.document ?? "tasks.md",
            content: action.payload.content ?? "",
            reason
          });
        case "memory.decision":
          return this.recordDecision({
            project,
            title: action.payload.title ?? "",
            context: action.payload.context ?? "",
            decision: action.payload.decision ?? "",
            consequence: action.payload.consequence ?? "",
            reason
          });
        case "test.run":
          return this.runTest({
            project,
            workflow_id: action.workflow_id ?? "",
            stage_id: action.stage_id ?? "",
            command: action.payload.command ?? "",
            reason
          });
        default:
          return Promise.reject(
            new BridgeRequestError(400, "unsupported_action", `Cannot stage ${action.action}`)
          );
      }
    }
  }
  const CCB_PROTOCOL_VERSION = "1.0";
  const ACTION_TYPES = [
    "file.read",
    "file.create",
    "file.write",
    "file.patch",
    "memory.read",
    "memory.append",
    "memory.decision",
    "git.status",
    "git.diff",
    "test.run",
    "workflow.status"
  ];
  const MEMORY_DOCUMENTS = [
    "project.md",
    "architecture.md",
    "decisions.md",
    "tasks.md",
    "changelog.md"
  ];
  const RISK_LEVELS = ["low", "medium", "high"];
  const ACTION_LABELS = {
    "file.read": "Read File",
    "file.create": "Create File",
    "file.write": "Modify File",
    "file.patch": "Patch File",
    "memory.read": "Read Memory",
    "memory.append": "Append Memory",
    "memory.decision": "Record Decision (ADR)",
    "git.status": "Git Status",
    "git.diff": "Git Diff",
    "test.run": "Run Tests",
    "workflow.status": "Workflow Status"
  };
  const MUTATING_ACTIONS = /* @__PURE__ */ new Set([
    "file.create",
    "file.write",
    "file.patch",
    "memory.append",
    "memory.decision",
    "test.run"
  ]);
  const MEMORY_ACTIONS = /* @__PURE__ */ new Set([
    "memory.read",
    "memory.append",
    "memory.decision"
  ]);
  function isMemoryAction(action) {
    return MEMORY_ACTIONS.has(action);
  }
  function isMutatingAction(action) {
    return MUTATING_ACTIONS.has(action);
  }
  const SAFE_MESSAGES = {
    invalidKey: "Invalid API key",
    rateLimited: "Rate limit reached",
    providerUnavailable: "Provider unavailable",
    backendUnreachable: "Backend unreachable",
    streamingStopped: "Streaming stopped",
    notConfigured: "LLM provider is not configured",
    requestRejected: "Provider rejected the request"
  };
  const SAFE_MESSAGE_LIST = Object.freeze(
    Object.values(SAFE_MESSAGES)
  );
  const KIND_MESSAGE = {
    invalid_key: SAFE_MESSAGES.invalidKey,
    rate_limited: SAFE_MESSAGES.rateLimited,
    provider_unavailable: SAFE_MESSAGES.providerUnavailable,
    backend_unreachable: SAFE_MESSAGES.backendUnreachable,
    streaming_stopped: SAFE_MESSAGES.streamingStopped,
    provider_not_configured: SAFE_MESSAGES.notConfigured,
    request_rejected: SAFE_MESSAGES.requestRejected
  };
  const CODE_KIND = {
    provider_not_configured: "provider_not_configured",
    unknown_provider: "request_rejected",
    unknown_model: "request_rejected",
    provider_unreachable: "backend_unreachable",
    context_consent_required: "request_rejected",
    context_source_rejected: "request_rejected",
    preference_rejected: "request_rejected",
    sandbox_violation: "request_rejected",
    provider_http_error: "provider_unavailable",
    assistant_error: "provider_unavailable"
  };
  const STATUS_FIRST_CODES = ["provider_http_error", "assistant_error"];
  const ABORT_NAMES = ["AbortError", "CanceledError"];
  const NETWORK_HINTS = [
    "failed to fetch",
    "networkerror",
    "network error",
    "load failed",
    "econnrefused",
    "err_connection",
    "fetch failed",
    "socket hang up",
    "and_unreachable"
  ];
  function statusKind(status) {
    if (status <= 0) return null;
    if (status === 401 || status === 403) return "invalid_key";
    if (status === 429) return "rate_limited";
    if (status >= 500) return "provider_unavailable";
    if (status >= 400) return "request_rejected";
    return null;
  }
  function readNumber(source, keys) {
    for (const key of keys) {
      const value = source[key];
      if (typeof value === "number" && Number.isFinite(value)) return value;
      if (typeof value === "string" && /^\d{3}$/.test(value)) return Number(value);
    }
    return 0;
  }
  function readString$1(source, keys) {
    for (const key of keys) {
      const value = source[key];
      if (typeof value === "string" && value) return value;
    }
    return "";
  }
  function inspect(error) {
    let status = 0;
    let code = "";
    let aborted = false;
    let text2 = "";
    if (typeof error === "string") {
      text2 = error;
    } else if (error && typeof error === "object") {
      const record = error;
      status = readNumber(record, ["status", "statusCode", "httpStatus"]);
      code = readString$1(record, ["code", "error"]);
      const name = readString$1(record, ["name"]);
      if (ABORT_NAMES.includes(name)) aborted = true;
      text2 = readString$1(record, ["message"]) || name;
      const body = record.body;
      if (body && typeof body === "object") {
        const nested = body;
        status = status || readNumber(nested, ["status", "statusCode", "httpStatus"]);
        code = code || readString$1(nested, ["code", "error"]);
      }
    }
    if (!status) {
      const match = /\b(4\d{2}|5\d{2})\b/.exec(text2);
      if (match) status = Number(match[1]);
    }
    return { status, code, aborted, text: text2 };
  }
  function classifyError(input) {
    const normalized = input && typeof input === "object" && ("error" in input || "aborted" in input) ? input : { error: input };
    const probe = inspect(normalized.error);
    const aborted = normalized.aborted === true || probe.aborted;
    if (aborted) {
      return { kind: "streaming_stopped", message: KIND_MESSAGE.streaming_stopped, status: 0 };
    }
    const code = (normalized.code || probe.code || "").toLowerCase();
    const status = normalized.status && normalized.status > 0 ? normalized.status : probe.status;
    if (code && CODE_KIND[code]) {
      const kind = (STATUS_FIRST_CODES.includes(code) ? statusKind(status) : null) ?? CODE_KIND[code];
      return { kind, message: KIND_MESSAGE[kind], status };
    }
    const byStatus = statusKind(status);
    if (byStatus) return { kind: byStatus, message: KIND_MESSAGE[byStatus], status };
    const lowered = probe.text.toLowerCase();
    if (NETWORK_HINTS.some((hint) => lowered.includes(hint))) {
      return { kind: "backend_unreachable", message: KIND_MESSAGE.backend_unreachable, status: 0 };
    }
    return { kind: "backend_unreachable", message: KIND_MESSAGE.backend_unreachable, status };
  }
  function safeErrorMessage(input) {
    return classifyError(input).message;
  }
  function isSafeMessage(value) {
    return SAFE_MESSAGE_LIST.includes(value);
  }
  const FORBIDDEN_ERROR_PATTERNS = Object.freeze([
    /Traceback \(most recent call last\)/i,
    /\bat [\w$.]+ \(.*:\d+:\d+\)/,
    /File "[^"]+", line \d+/,
    /\b[A-Za-z]:\\\\?[\w\\/.-]+/,
    // Windows path
    /(^|\s)\/(usr|home|etc|var|opt|root)\//,
    // POSIX path
    /\bsk-[A-Za-z0-9_-]{8,}/,
    /Authorization\s*:/i,
    /\bBearer\s+[A-Za-z0-9._-]{8,}/i,
    /sqlite:\/\//i,
    /postgres(ql)?:\/\//i,
    /\bpassword\s*=/i,
    /<[A-Za-z]+Error\b/
  ]);
  function containsForbiddenDetail(value) {
    return FORBIDDEN_ERROR_PATTERNS.some((pattern) => pattern.test(value));
  }
  function sanitizeStatusText(value) {
    if (!value) return "";
    if (isSafeMessage(value)) return value;
    if (containsForbiddenDetail(value)) return SAFE_MESSAGES.backendUnreachable;
    return value;
  }
  let counter = 0;
  function nextId() {
    counter += 1;
    return `act_${Date.now().toString(36)}_${counter.toString(36)}`;
  }
  class Controller {
    store;
    client;
    render;
    onProjects;
    /** Live assistant stream, aborted by Stop. */
    assistantAbort = null;
    constructor(deps) {
      this.store = deps.store;
      this.client = deps.client;
      this.render = deps.render;
      this.onProjects = deps.onProjects;
    }
    /** Check Bridge health and load the project list. */
    async connect() {
      try {
        await this.client.health();
        await this.store.setBridgeStatus("connected");
        const { projects } = await this.client.listProjects();
        const names = projects.map((project) => project.name);
        this.onProjects?.(names);
        const current = this.store.getState().currentProject;
        if (!current && names.length === 1) {
          await this.store.setProject(names[0]);
        }
        await this.refreshApprovals();
        await this.refreshContext();
        await this.store.appendLog({
          event: "bridge.connect",
          detail: `${names.length} project(s)`,
          approved: true,
          result: "success"
        });
      } catch (error) {
        const offline = error instanceof BridgeUnavailableError;
        await this.store.setBridgeStatus(offline ? "offline" : "error");
        await this.store.update({
          lastResult: offline ? "Local Bridge unavailable" : describe(error)
        });
        await this.store.appendLog({
          event: "bridge.connect",
          detail: describe(error),
          approved: false,
          result: "failed"
        });
      } finally {
        this.render();
      }
    }
    /** Refresh recovered approvals without approving or executing them. */
    async refreshApprovals() {
      try {
        const response = await this.client.pendingApprovals();
        const recovered = response.pending.filter(
          (item2) => typeof item2.requestId === "string" && typeof item2.action === "string" && typeof item2.project === "string" && typeof item2.path === "string" && typeof item2.reason === "string" && typeof item2.preview === "string" && (item2.status === "recovered" || item2.status === "reconfirmed")
        ).map((item2) => item2);
        await this.store.update({ recoveredApprovals: recovered });
      } catch (error) {
        await this.store.update({ lastResult: describe(error) });
      }
    }
    /** Refresh read-only project context for the Workflow Dashboard. */
    async refreshContext() {
      const project = this.store.getState().currentProject;
      if (!project) {
        await this.store.update({ projectContext: null, devContext: null, devContextSelection: [], phase30Intelligence: null, llmProviders: [], llmModels: [], llmConversations: [], llmToolProposals: [], sessions: [], agents: [], modelSelection: null, runtimes: [], tasks: [], runtimeEvents: [], qualityReport: null, teams: [], dependencies: [], collaborationEvents: [], projectProfile: null, projectGraph: null, impactReport: null, projectMemoryHistory: null, intelligenceInsights: [], intelligenceProposals: [], intelligenceDecisions: [], intelligenceQuality: null, intelligenceObservations: [], intelligencePatterns: [], intelligencePredictions: [], intelligenceRecommendations: [], intelligenceOutcomes: [], intelligenceKnowledge: [], intelligenceEvidence: [], intelligenceQuality11: null, intelligenceTrends: [], intelligenceCorrelations: [], intelligenceImpactPredictions: [], intelligenceDependencyRisks: [], intelligenceEvaluations: [], intelligenceEvaluationMetrics: null, intelligenceRecommendationRanking: null, intelligenceEvidenceGraph: null, intelligenceValidation: null, intelligenceAccuracy: null, intelligenceEffectiveness: [], intelligenceEffectivenessSummary: null, intelligenceDecisionOutcomes: [], intelligenceDecisionSummary: null, intelligenceBenchmarks: [], intelligenceImprovements: [], intelligenceGovernance: null, simulation: null, simulationScenarios: [], simulationEvaluations: [], simulationPlans: [], simulationQuality: null, planningMemoryHistory: null, executionTasks: [], executionProposals: [], executionResults: [], executionQuality7: null, executionMemoryHistory: null, executionLoops: [], executionLoopTimeline: [], executionLoopQuality8: null, executionDags: [], executionDagReady: null, engineeringMetrics: null, executionLoopContext: null, engineeringGraph: null, failurePatterns: [], evolutionTimeline: [], agentCapabilityMetrics: [], benchmarks: [], demoScenarios: [], demoFlow: [], replays: [], artifacts: [], governanceHealth: null, governanceDrift: null, governanceDebt: null, governancePolicies: null, governanceTimeline: null, governanceQuality9: null, organizationGraph: null, organizationHealth: null, organizationDashboard: null, organizationPatterns: null, organizationIncidents: null, organizationLearning: null, organizationQuality10: null, organizationStrategyImpact: null, organizationStrategyRisk: null, organizationStrategies: null, organizationRecommendations: null, organizationStrategyContext: null, lastContextRefresh: null });
        this.render();
        return;
      }
      if (this.store.getState().uiMode === "user") {
        await this.refreshAssistant();
        this.render();
        return;
      }
      try {
        const context = await this.client.projectContext(project);
        const sessions = await this.client.sessionList(project).catch(() => ({ sessions: [] }));
        const runtime = await this.client.agentStatus(project, "review implementation and test results").catch(() => ({
          agents: [],
          messages: [],
          models: [],
          selectedModel: null
        }));
        const runtimeStatus = await this.client.runtimeStatus().catch(() => ({ runtimes: [], states: [] }));
        const runtimeEvents = await this.client.runtimeEvents().catch(() => ({ events: [] }));
        const tasks = await this.client.taskList().catch(() => ({ tasks: [] }));
        const teams = await this.client.teamList(context.currentWorkflow?.id).catch(() => ({ teams: [] }));
        const collaboration = await this.client.collaborationEvents().catch(() => ({ events: [] }));
        const projectProfile = await this.client.projectProfile(project).catch(() => null);
        const projectGraph = await this.client.projectGraph(project).catch(() => null);
        const impactReport = await this.client.impactAnalysis(project).catch(() => null);
        const projectMemoryHistory = await this.client.projectMemoryHistory(project).catch(() => null);
        const intelligenceInsights = await this.client.intelligenceInsights(project).catch(() => ({ project, insights: [], readOnly: true }));
        const intelligenceProposals = await this.client.intelligenceProposals(project).catch(() => ({ project, proposals: [], readOnly: true }));
        const intelligenceDecisions = await this.client.intelligenceDecisions(project).catch(() => ({ project, decisions: [], readOnly: true }));
        const intelligenceQuality = context.currentWorkflow ? await this.client.intelligenceQuality(context.currentWorkflow.id).catch(() => null) : null;
        const intelligenceObservations = await this.client.intelligenceObservations(project).then((result) => result.observations).catch(() => []);
        const intelligencePatterns = await this.client.intelligencePatterns(project).then((result) => result.patterns).catch(() => []);
        const intelligencePredictions = await this.client.intelligencePredictions(project).then((result) => result.predictions).catch(() => []);
        const intelligenceRecommendations = await this.client.intelligenceRecommendations(project).then((result) => result.recommendations).catch(() => []);
        const intelligenceOutcomes = await this.client.intelligenceOutcomes(project).then((result) => result.outcomes).catch(() => []);
        const intelligenceKnowledge = await this.client.intelligenceKnowledge(project).then((result) => result.knowledge).catch(() => []);
        const intelligenceEvidence = await this.client.intelligenceEvidence(project).then((result) => result.evidence).catch(() => []);
        const intelligenceQuality11 = await this.client.intelligenceQuality11(project).catch(() => null);
        const intelligenceTrends = await this.client.intelligenceTrends(project).then((result) => result.trends).catch(() => []);
        const intelligenceCorrelations = await this.client.intelligenceCorrelations(project).then((result) => result.correlations).catch(() => []);
        const intelligenceImpactPredictions = await this.client.intelligenceImpact(project).then((result) => result.impact).catch(() => []);
        const intelligenceDependencyRisks = await this.client.intelligenceDependencies(project).then((result) => result.dependencies).catch(() => []);
        const intelligenceEvaluationResponse = await this.client.intelligenceEvaluations(project).catch(() => null);
        const intelligenceEvaluations = intelligenceEvaluationResponse?.evaluations ?? [];
        const intelligenceEvaluationMetrics = intelligenceEvaluationResponse?.metrics ?? null;
        const intelligenceRecommendationRanking = await this.client.intelligenceRecommendationRanking(project).catch(() => null);
        const intelligenceEvidenceGraph = await this.client.intelligenceEvidenceGraph(project).catch(() => null);
        const intelligenceValidation = await this.client.intelligenceValidation(project).catch(() => null);
        const intelligenceGovernance = await this.client.intelligenceGovernance(project).catch(() => null);
        const devContext = await this.client.devContextBundle(project).catch(() => null);
        const phase30Intelligence = await this.client.contextIntelligenceSnapshot(project).catch(() => null);
        const llmProviders = await this.client.llmProviders().then((result) => result.providers).catch(() => []);
        const llmModels = await this.client.llmModels().then((result) => result.models).catch(() => []);
        const llmConversations = await this.client.llmConversations(project).then((result) => result.conversations).catch(() => []);
        const llmToolProposals = await this.client.llmToolProposals(project).then((result) => result.proposals).catch(() => []);
        const simulation = await this.client.simulation(project).catch(() => null);
        const simulationScenarios = simulation ? await this.client.simulationScenarios(simulation.id).then((result) => result.scenarios).catch(() => []) : [];
        const simulationEvaluations = simulation ? await this.client.simulationEvaluation(simulation.id).then((result) => result.evaluations).catch(() => []) : [];
        const simulationQuality = context.currentWorkflow ? await this.client.simulationQuality(context.currentWorkflow.id).catch(() => null) : null;
        const planningMemoryHistory = await this.client.planningMemoryHistory(project).catch(() => null);
        const executionTasks = await this.client.executionTasks(project).then((result) => result.tasks).catch(() => []);
        const executionProposals = await this.client.executionProposals(project).then((result) => result.proposals).catch(() => []);
        const executionResults = await this.client.executionResults(project).then((result) => result.results).catch(() => []);
        const executionQuality7 = context.currentWorkflow ? await this.client.executionQuality7(context.currentWorkflow.id).catch(() => null) : null;
        const executionMemoryHistory = await this.client.executionMemoryHistory(project).catch(() => null);
        const executionLoops = await this.client.executionLoopList(project).then((result) => result.loops).catch(() => []);
        const executionLoopTimeline = executionLoops.length ? await this.client.executionLoopTimeline(executionLoops[0].id).then((result) => result.timeline).catch(() => []) : [];
        const executionLoopQuality8 = executionLoops[0]?.workflowId ? await this.client.executionLoopQuality8(executionLoops[0].workflowId).catch(() => null) : null;
        const executionDags = await this.client.executionDagList(project).then((result) => result.dags).catch(() => []);
        const executionDagReady = executionDags[0] ? await this.client.executionDagReady(executionDags[0].id).catch(() => null) : null;
        const engineeringMetrics = await this.client.engineeringMetrics(project).catch(() => null);
        const executionLoopContext = executionLoops[0] ? await this.client.executionLoopContext(executionLoops[0].id).catch(() => null) : null;
        const engineeringGraph = await this.client.engineeringGraph(project).catch(() => null);
        const failurePatterns = await this.client.failurePatterns(project).then((result) => result.patterns).catch(() => []);
        const evolutionTimeline = await this.client.evolutionTimeline(project).then((result) => result.timeline).catch(() => []);
        const agentCapabilityMetrics = await this.client.agentCapabilityMetrics().then((result) => result.metrics).catch(() => []);
        const benchmarks = await this.client.benchmarkList(project).then((result) => result.benchmarks).catch(() => []);
        const demoScenarios = await this.client.demoCatalog().then((result) => result.scenarios).catch(() => []);
        const demoFlow = await this.client.demoFlow().then((result) => result.flow).catch(() => []);
        const replays = await this.client.replayList(project).then((result) => result.replays).catch(() => []);
        const artifacts = await this.client.artifactList(project).then((result) => result.artifacts).catch(() => []);
        const governanceHealth = await this.client.governanceHealth(project).catch(() => null);
        const governanceDrift = await this.client.governanceDrift(project).catch(() => null);
        const governanceDebt = await this.client.governanceDebt(project).catch(() => null);
        const governancePolicies = await this.client.governancePolicies(project).catch(() => null);
        const governanceTimeline = await this.client.governanceTimeline(project).catch(() => null);
        const governanceQuality9 = context.currentWorkflow ? await this.client.governanceQuality9(context.currentWorkflow.id).catch(() => null) : null;
        const organizationGraph = await this.client.organizationGraph().catch(() => null);
        const organizationHealth = await this.client.organizationHealth().catch(() => null);
        const organizationDashboard = await this.client.organizationDashboard().catch(() => null);
        const organizationPatterns = await this.client.organizationPatterns().catch(() => null);
        const organizationIncidents = await this.client.organizationIncidents(project).catch(() => null);
        const organizationLearning = await this.client.organizationLearningSimilar(project).catch(() => null);
        const organizationQuality10 = await this.client.organizationQuality10("organization").catch(() => null);
        const strategyNodeId = organizationGraph?.services[0]?.id ?? organizationGraph?.projects[0]?.id ?? organizationGraph?.repositories[0]?.id ?? "";
        const organizationStrategyImpact = strategyNodeId ? await this.client.organizationImpact(strategyNodeId).catch(() => null) : null;
        const organizationStrategyRisk = strategyNodeId ? await this.client.organizationRisk(strategyNodeId).catch(() => null) : null;
        const organizationStrategies = await this.client.organizationStrategies(project).catch(() => null);
        const organizationRecommendations = await this.client.organizationRecommendations().catch(() => null);
        const organizationStrategyContext = await this.client.organizationContext().catch(() => null);
        const dependencyResults = await Promise.all(tasks.tasks.slice(0, 10).map((task) => this.client.taskDependencies(task.id).catch(() => ({ taskId: task.id, dependencies: [], hasCycle: false }))));
        const dependencies = dependencyResults.flatMap((result) => result.dependencies);
        const qualityReport = context.currentWorkflow ? await this.client.quality(context.currentWorkflow.id).catch(() => null) : null;
        await this.store.update({
          projectContext: context,
          sessions: sessions.sessions,
          agents: runtime.agents,
          modelSelection: runtime.selectedModel ?? null,
          runtimes: runtimeStatus.runtimes,
          tasks: tasks.tasks,
          runtimeEvents: runtimeEvents.events,
          qualityReport,
          teams: teams.teams,
          dependencies,
          collaborationEvents: collaboration.events,
          projectProfile,
          projectGraph,
          impactReport,
          projectMemoryHistory,
          intelligenceInsights: intelligenceInsights.insights,
          intelligenceProposals: intelligenceProposals.proposals,
          intelligenceDecisions: intelligenceDecisions.decisions,
          intelligenceQuality,
          intelligenceObservations,
          intelligencePatterns,
          intelligencePredictions,
          intelligenceRecommendations,
          intelligenceOutcomes,
          intelligenceKnowledge,
          intelligenceEvidence,
          intelligenceQuality11,
          intelligenceTrends,
          intelligenceCorrelations,
          intelligenceImpactPredictions,
          intelligenceDependencyRisks,
          intelligenceEvaluations,
          intelligenceEvaluationMetrics,
          intelligenceRecommendationRanking,
          intelligenceEvidenceGraph,
          intelligenceValidation,
          intelligenceAccuracy: intelligenceValidation?.accuracy ?? null,
          intelligenceEffectiveness: intelligenceValidation?.effectiveness ?? [],
          intelligenceEffectivenessSummary: intelligenceValidation?.effectivenessSummary ?? null,
          intelligenceDecisionOutcomes: intelligenceValidation?.decisionOutcomes ?? [],
          intelligenceDecisionSummary: intelligenceValidation?.decisionSummary ?? null,
          intelligenceBenchmarks: intelligenceValidation?.benchmarks ?? [],
          intelligenceImprovements: intelligenceValidation?.improvements ?? [],
          intelligenceGovernance,
          devContext,
          phase30Intelligence,
          llmProviders,
          llmModels,
          llmConversations,
          llmToolProposals,
          simulation,
          simulationScenarios,
          simulationEvaluations,
          simulationPlans: simulation?.plans ?? [],
          simulationQuality,
          planningMemoryHistory,
          executionTasks,
          executionProposals,
          executionResults,
          executionQuality7,
          executionMemoryHistory,
          executionLoops,
          executionLoopTimeline,
          executionLoopQuality8,
          executionDags,
          executionDagReady,
          engineeringMetrics,
          executionLoopContext,
          engineeringGraph,
          failurePatterns,
          evolutionTimeline,
          agentCapabilityMetrics,
          benchmarks,
          demoScenarios,
          demoFlow,
          replays,
          artifacts,
          governanceHealth,
          governanceDrift,
          governanceDebt,
          governancePolicies,
          governanceTimeline,
          governanceQuality9,
          organizationGraph,
          organizationHealth,
          organizationDashboard,
          organizationPatterns,
          organizationIncidents,
          organizationLearning,
          organizationQuality10,
          organizationStrategyImpact,
          organizationStrategyRisk,
          organizationStrategies,
          organizationRecommendations,
          organizationStrategyContext,
          lastContextRefresh: (/* @__PURE__ */ new Date()).toISOString()
        });
      } catch (error) {
        await this.store.update({ lastResult: describe(error) });
      }
      await this.refreshAssistant();
      this.render();
    }
    /**
     * Phase 32 · read-only assistant status: user settings, provider status and
     * context status. None of those responses carries an API key, and nothing
     * here writes to the workspace.
     */
    async refreshAssistant() {
      const state = this.store.getState();
      try {
        const settings = await this.client.userSettings();
        const status = await this.client.providerStatus().catch(() => ({ providers: [] }));
        const contextStatus = await this.client.contextStatus(state.currentProject ?? "", state.uiMode).catch(() => null);
        const entries = status.providers;
        const provider = state.assistantProvider || settings.provider || entries[0]?.provider || "local";
        const active = entries.find((item2) => item2.provider === provider) ?? null;
        await this.store.update({
          assistantSettings: settings,
          assistantProviders: entries,
          assistantContextStatus: contextStatus,
          assistantProvider: provider,
          assistantModel: state.assistantModel || active?.selectedModel || active?.models[0] || settings.model || ""
        });
      } catch (error) {
        await this.store.update({ assistantStatus: safeErrorMessage(error) });
      }
    }
    /** Mode is a local, non-sensitive preference (spec §17). */
    async setUiMode(mode) {
      await this.store.setUiMode(mode);
      await this.refreshContext();
    }
    /** Provider and model names are preferences, not credentials. */
    async selectAssistantProvider(provider) {
      const entry = this.store.getState().assistantProviders.find((item2) => item2.provider === provider);
      await this.store.update({
        assistantProvider: provider,
        assistantModel: entry?.selectedModel || entry?.models[0] || "",
        assistantProviderTest: null
      });
      this.render();
    }
    async selectAssistantModel(model) {
      await this.store.update({ assistantModel: model });
      this.render();
    }
    /**
     * Save provider settings.
     *
     * `input.apiKey` is the transient value of the Settings input. It is handed to
     * the Bridge (which encrypts it with AES-256-GCM) and never written to state,
     * never logged and never placed in a URL. The write itself is approval-gated,
     * so this only queues a request for a human to approve.
     */
    async saveProvider(input) {
      try {
        await this.client.providerConfig({
          provider: input.provider,
          model: input.model || void 0,
          base_url: input.baseUrl || void 0,
          api_key: input.apiKey || void 0,
          keep_existing_key: input.apiKey.length === 0,
          reason: "Provider settings update requested in the assistant panel"
        });
        await this.store.update({ assistantStatus: "Provider update waiting for approval." });
      } catch (error) {
        await this.store.update({ assistantStatus: safeErrorMessage(error) });
      }
      await this.refreshAssistant();
      this.render();
    }
    /** Test Connection. The Bridge answers with a fixed, safe vocabulary only. */
    async testProvider(input) {
      try {
        const result = await this.client.providerTest({
          provider: input.provider,
          model: input.model || void 0,
          api_key: input.apiKey || void 0
        });
        await this.store.update({ assistantProviderTest: result, assistantStatus: result.message });
      } catch (error) {
        await this.store.update({ assistantStatus: safeErrorMessage(error) });
      }
      this.render();
    }
    async forgetProviderKey(provider) {
      try {
        await this.client.providerForget({ provider, reason: "Remove the stored provider key" });
        await this.store.update({ assistantStatus: "Key removal waiting for approval." });
      } catch (error) {
        await this.store.update({ assistantStatus: safeErrorMessage(error) });
      }
      await this.refreshAssistant();
      this.render();
    }
    /**
     * Ask AI: store the collected page snapshot for display.
     *
     * Collecting is not sending — the bundle travels to the Bridge only when the
     * user submits a message, and it is dropped straight afterwards.
     */
    async askAi(bundle) {
      await this.store.setAssistantWebContext(bundle);
      await this.store.update({
        assistantStatus: "Page context ready. It is sent only with your next message."
      });
      this.render();
    }
    async clearWebContext() {
      await this.store.setAssistantWebContext(null);
      this.render();
    }
    /** Stop streaming. Nothing is retried afterwards. */
    async stopAssistant() {
      this.assistantAbort?.abort();
      this.assistantAbort = null;
      await this.store.stopAssistantStreaming();
      this.render();
    }
    /**
     * Send one chat message and stream the reply.
     *
     * Tool calls that come back are recorded on the turn as proposals only:
     * `toolCallsExecuted` is always false on the Bridge side and nothing here
     * executes, applies or approves anything.
     *
     * Phase 34 · the captured page is attached **only** when the user left the
     * include switch on, the composer text is handed back if the request fails,
     * and `appendUserTurn: false` lets Retry reuse the user turn that is already in
     * the transcript instead of sending the same message a second time.
     */
    async sendAssistantMessage(text2, options = {}) {
      const before = this.store.getState();
      const webContext = before.assistantContextInclude ? before.assistantWebContext : null;
      const turnId = `turn_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
      if (options.appendUserTurn !== false) {
        await this.store.appendAssistantTurn({
          id: `${turnId}_u`,
          role: "user",
          content: text2,
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      await this.store.appendAssistantTurn({
        id: turnId,
        role: "assistant",
        content: "",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        streaming: true
      });
      await this.store.setAssistantStreaming(true);
      await this.store.setAssistantDraft("");
      this.render();
      const conversation = this.store.activeAssistantConversation;
      const messages = (conversation?.turns ?? []).filter((turn) => turn.id !== turnId && turn.content).map((turn) => ({ role: turn.role, content: turn.content }));
      const abort = new AbortController();
      this.assistantAbort = abort;
      const toolCalls = [];
      let reply = "";
      let failed = false;
      let streamError = "";
      try {
        await this.client.assistantChatStream(
          {
            project: before.currentProject ?? "",
            messages,
            provider: before.assistantProvider || void 0,
            model: before.assistantModel || void 0,
            web_context: webContext
          },
          {
            signal: abort.signal,
            onEvent: (event) => {
              if (event.type === "error") {
                streamError = isSafeMessage(event.content) ? event.content : SAFE_MESSAGES.providerUnavailable;
                return;
              }
              if (event.toolCall) toolCalls.push(event.toolCall);
              if (event.content) reply += event.content;
              void this.store.patchAssistantTurn(turnId, { content: reply, toolCalls: [...toolCalls] });
              this.render();
            }
          }
        );
        if (this.assistantAbort !== abort) return;
        if (streamError) {
          failed = true;
          await this.store.patchAssistantTurn(turnId, {
            content: reply,
            toolCalls,
            streaming: false,
            failed: true
          });
          await this.store.setAssistantDraft(text2);
          await this.store.failAssistantStreaming(streamError);
        } else {
          await this.store.patchAssistantTurn(turnId, { content: reply, toolCalls, streaming: false });
          await this.store.setAssistantStreaming(
            false,
            toolCalls.length ? "Tool proposal waiting for approval." : ""
          );
        }
      } catch (error) {
        if (this.assistantAbort !== abort) return;
        failed = true;
        await this.store.patchAssistantTurn(turnId, {
          content: reply,
          toolCalls,
          streaming: false,
          failed: true
        });
        await this.store.setAssistantDraft(text2);
        await this.store.failAssistantStreaming(safeErrorMessage(error));
      } finally {
        if (this.assistantAbort === abort) this.assistantAbort = null;
        if (webContext && !failed) await this.store.setAssistantWebContext(null);
        this.render();
      }
    }
    /**
     * Retry the last user message. Always a click, never a timer.
     *
     * The failed assistant placeholder is dropped and the existing user turn is
     * reused, so a retry cannot send the same message twice. There is no automatic
     * provider retry anywhere in the extension.
     */
    async retryAssistant() {
      if (this.store.getState().assistantStreaming) return;
      const text2 = this.store.lastAssistantUserMessage;
      if (!text2) return;
      await this.store.dropFailedAssistantTail();
      await this.store.setAssistantDraft("");
      await this.sendAssistantMessage(text2, { appendUserTurn: false });
    }
    // -- Phase 34 · onboarding, conversations and context ---------------------
    //
    // Everything below writes extension display state and nothing else: no Bridge
    // call, no provider write, no key, no approval, no tool proposal, no LLM
    // request. The onboarding state is a plain non-sensitive marker.
    async onboardingNext() {
      await this.store.advanceOnboarding();
      this.render();
    }
    async onboardingBack() {
      await this.store.regressOnboarding();
      this.render();
    }
    async onboardingSkip() {
      await this.store.skipOnboarding();
      this.render();
    }
    async onboardingLater() {
      await this.store.deferOnboarding();
      this.render();
    }
    async onboardingFinish() {
      await this.store.completeOnboarding();
      this.render();
    }
    async onboardingReopen() {
      await this.store.reopenOnboarding();
      this.render();
    }
    async searchConversations(query) {
      await this.store.setAssistantConversationQuery(query);
      this.render();
    }
    async beginRenameConversation(id) {
      await this.store.beginRenameConversation(id);
      this.render();
    }
    async renameConversation(id, title) {
      await this.store.renameAssistantConversation(id, title);
      this.render();
    }
    async cancelRenameConversation() {
      await this.store.cancelRenameConversation();
      this.render();
    }
    async toggleConversationPinned(id) {
      await this.store.toggleAssistantConversationPinned(id);
      this.render();
    }
    async newConversation() {
      await this.store.newAssistantConversation();
      this.render();
    }
    async selectConversation(id) {
      await this.store.selectAssistantConversation(id);
      this.render();
    }
    /** Hides a conversation in this view. Bridge records are untouched. */
    async removeConversation(id) {
      await this.store.removeAssistantConversation(id);
      this.render();
    }
    /** Decide whether the captured page travels with the next message. */
    async toggleContextInclude(include) {
      await this.store.setAssistantContextInclude(include);
      this.render();
    }
    /** Handle parser output coming from the DOM observer. */
    async handleParseResults(results) {
      for (const result of results) {
        if (!result.ok) {
          await this.store.appendLog({
            event: "action.rejected_schema",
            detail: result.error,
            approved: false,
            result: "ignored"
          });
          continue;
        }
        const pending = {
          id: nextId(),
          action: result.action,
          state: "pending",
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          fingerprint: result.fingerprint
        };
        await this.store.addPending(pending);
        await this.store.appendLog({
          event: "action.captured",
          detail: `${result.action.action} ${result.action.target.project}:${result.action.target.path}`,
          approved: false,
          result: "pending"
        });
      }
      this.render();
    }
    /** Explicitly reconfirm one recovered approval; this still does not execute it. */
    async reconfirm(requestId) {
      try {
        await this.client.reconfirm(requestId);
        await this.refreshApprovals();
        await this.store.update({ lastResult: "Recovered approval reconfirmed; execution still requires explicit approval" });
        await this.store.appendLog({
          event: "approval.reconfirmed",
          detail: requestId,
          approved: true,
          result: "pending"
        });
      } catch (error) {
        await this.store.update({ lastResult: describe(error) });
      }
      this.render();
    }
    /** Execute only after the recovered request has been explicitly reconfirmed. */
    async approveRecovered(requestId) {
      try {
        await this.client.approve(requestId);
        await this.refreshApprovals();
        await this.store.update({ lastResult: "Recovered approval executed after explicit confirmation" });
        await this.store.appendLog({
          event: "approval.recovered_executed",
          detail: requestId,
          approved: true,
          result: "success"
        });
      } catch (error) {
        await this.store.update({ lastResult: describe(error) });
      }
      this.render();
    }
    /** User clicked Approve. Stage on the Bridge, then approve it. */
    async approve(id) {
      const item2 = this.store.getState().pendingActions.find((entry) => entry.id === id);
      if (!item2 || item2.state !== "pending") return;
      const label2 = `${item2.action.action} ${item2.action.target.project}:${item2.action.target.path}`;
      if (!isMutatingAction(item2.action.action)) {
        await this.store.patchPending(id, { state: "approving" });
        this.render();
        try {
          let preview;
          let message;
          if (item2.action.action === "memory.read") {
            const file = await this.client.readMemory(
              item2.action.target.project,
              item2.action.target.document ?? "project.md"
            );
            preview = file.content.slice(0, 1200);
            message = `Read ${file.size} bytes`;
          } else if (item2.action.action === "git.status") {
            const result = await this.client.gitStatus(item2.action.target.project);
            preview = JSON.stringify(result, null, 2).slice(0, 1200);
            message = "Git status loaded";
          } else if (item2.action.action === "git.diff") {
            const result = await this.client.gitDiff(
              item2.action.target.project,
              item2.action.payload.staged === true
            );
            preview = String(result.diff ?? JSON.stringify(result, null, 2)).slice(0, 1200);
            message = "Git diff loaded";
          } else if (item2.action.action === "workflow.status") {
            const result = await this.client.workflowStatus(item2.action.workflow_id ?? "");
            preview = JSON.stringify(result, null, 2).slice(0, 1200);
            message = "Workflow status loaded";
          } else {
            const file = await this.client.readFile(
              item2.action.target.project,
              item2.action.target.path
            );
            preview = file.content.slice(0, 1200);
            message = `Read ${file.size} bytes`;
          }
          await this.store.patchPending(id, {
            state: "approved",
            message,
            preview
          });
          await this.store.update({ lastResult: `Read ${item2.action.target.path}` });
          await this.store.appendLog({
            event: "action.read",
            detail: label2,
            approved: true,
            result: "success"
          });
        } catch (error) {
          await this.failAction(id, label2, error);
        }
        this.render();
        return;
      }
      await this.store.patchPending(id, { state: "approving" });
      this.render();
      try {
        const staged = await this.client.stage(item2.action);
        await this.store.patchPending(id, {
          bridgeRequestId: staged.requestId,
          preview: staged.preview
        });
        this.render();
        const executed = await this.client.approve(staged.requestId);
        const size = Number(executed.result?.size ?? 0);
        await this.store.patchPending(id, {
          state: "approved",
          message: `Applied via Bridge (${size} bytes, ${executed.permissionLevel})`
        });
        await this.store.update({ lastResult: `Applied ${item2.action.target.path}` });
        await this.store.appendLog({
          event: "action.approved",
          detail: `${label2} requestId=${staged.requestId}`,
          approved: true,
          result: "success"
        });
      } catch (error) {
        await this.failAction(id, label2, error);
      }
      this.render();
    }
    /** User clicked Reject. Nothing is sent to the Bridge for execution. */
    async reject(id) {
      const item2 = this.store.getState().pendingActions.find((entry) => entry.id === id);
      if (!item2 || item2.state !== "pending") return;
      await this.store.patchPending(id, { state: "rejected", message: "Rejected by user" });
      await this.store.update({ lastResult: `Rejected ${item2.action.target.path}` });
      await this.store.appendLog({
        event: "action.rejected",
        detail: `${item2.action.action} ${item2.action.target.project}:${item2.action.target.path}`,
        approved: false,
        result: "rejected"
      });
      this.render();
    }
    async selectProject(project) {
      await this.store.setProject(project);
      await this.refreshApprovals();
      await this.refreshContext();
      await this.store.appendLog({
        event: "project.selected",
        detail: project,
        approved: true,
        result: "success"
      });
      this.render();
    }
    async failAction(id, label2, error) {
      const offline = error instanceof BridgeUnavailableError;
      if (offline) await this.store.setBridgeStatus("offline");
      const message = offline ? "Local Bridge unavailable" : describe(error);
      await this.store.patchPending(id, { state: "failed", message });
      await this.store.update({ lastResult: message });
      await this.store.appendLog({
        event: "action.failed",
        detail: `${label2}: ${message}`,
        approved: true,
        result: "failed"
      });
    }
  }
  function describe(error) {
    if (error instanceof Error) return error.message;
    return String(error);
  }
  const CONVERSATION_CANDIDATES = [
    "main [role='log']",
    "main [class*='conversation']",
    "main [class*='thread']",
    "main",
    "#__next main",
    "body"
  ];
  const MESSAGE_CANDIDATES = [
    "[data-message-author-role='assistant']",
    "[data-message-author-role]",
    "[data-message-id]",
    "article",
    "[class*='markdown']"
  ];
  const SUPPORTED_HOSTS = ["chatgpt.com", "chat.openai.com"];
  function queryFirst(root, candidates) {
    for (const selector of candidates) {
      try {
        const found = root.querySelector(selector);
        if (found) return found;
      } catch {
      }
    }
    return null;
  }
  const defaultSelectorAdapter = {
    isChatGPTHost(hostname) {
      const host = hostname.toLowerCase();
      return SUPPORTED_HOSTS.some((base) => host === base || host.endsWith(`.${base}`));
    },
    findConversationRoot(doc) {
      return queryFirst(doc, CONVERSATION_CANDIDATES);
    },
    findMessageNodes(root) {
      for (const selector of MESSAGE_CANDIDATES) {
        try {
          const nodes = Array.from(root.querySelectorAll(selector));
          if (nodes.length > 0) return nodes;
        } catch {
        }
      }
      return [];
    },
    closestMessageNode(node) {
      const start = node.nodeType === 1 ? node : node.parentElement ?? null;
      if (!start) return null;
      for (const selector of MESSAGE_CANDIDATES) {
        try {
          const found = start.closest(selector);
          if (found) return found;
        } catch {
        }
      }
      return start;
    },
    extractText(element) {
      return element.textContent ?? "";
    }
  };
  const BLOCK_PATTERN = /<ccb_action>([\s\S]*?)<\/ccb_action>/gi;
  const MAX_BLOCK_LENGTH = 512 * 1024;
  const MAX_REASON_LENGTH = 500;
  const MAX_PATH_LENGTH = 1024;
  const PROJECT_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/;
  const WORKFLOW_PATTERN = /^wf_[0-9a-f]{12,32}$/;
  const STAGE_PATTERN = /^stg_[0-9a-f]{12,32}$/;
  const TOOL_ACTIONS = /* @__PURE__ */ new Set(["git.status", "git.diff", "test.run", "workflow.status"]);
  function fingerprint(input) {
    let hash = 2166136261;
    for (let index = 0; index < input.length; index += 1) {
      hash ^= input.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return `ccb_${(hash >>> 0).toString(16).padStart(8, "0")}`;
  }
  function isPlainObject(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function readString(source, key) {
    const value = source[key];
    return typeof value === "string" ? value : null;
  }
  function isSafeRelativePath(path) {
    if (!path || path.length > MAX_PATH_LENGTH) return false;
    if (path.includes("\0")) return false;
    const normalized = path.replace(/\\/g, "/");
    if (normalized.startsWith("/")) return false;
    if (/^[A-Za-z]:/.test(normalized)) return false;
    return !normalized.split("/").some((segment) => segment === ".." || segment.trim() === "..");
  }
  function validatePayload(action, rawPayload) {
    if (rawPayload !== void 0 && !isPlainObject(rawPayload)) {
      return { ok: false, error: "payload must be an object" };
    }
    const source = isPlainObject(rawPayload) ? rawPayload : {};
    if (action === "file.patch") {
      const patch = readString(source, "patch");
      if (!patch || !patch.trim()) {
        return { ok: false, error: "file.patch requires payload.patch" };
      }
      if (!patch.includes("@@")) {
        return { ok: false, error: "payload.patch must be a unified diff" };
      }
      return { ok: true, payload: { patch } };
    }
    if (action === "file.create" || action === "file.write") {
      const content = readString(source, "content");
      if (content === null) {
        return { ok: false, error: `${action} requires payload.content` };
      }
      return { ok: true, payload: { content } };
    }
    if (action === "memory.append") {
      const content = readString(source, "content");
      if (!content || !content.trim()) {
        return { ok: false, error: "memory.append requires payload.content" };
      }
      return { ok: true, payload: { content: content.trim() } };
    }
    if (action === "memory.decision") {
      const adr = {};
      for (const key of ["title", "context", "decision", "consequence"]) {
        const value = readString(source, key);
        if (!value || !value.trim()) {
          return { ok: false, error: `memory.decision requires payload.${key}` };
        }
        adr[key] = value.trim();
      }
      return { ok: true, payload: adr };
    }
    if (action === "test.run") {
      const command = readString(source, "command");
      if (!command || !["pytest", "npm test", "cmake build"].includes(command)) {
        return { ok: false, error: "test.run requires an allowed payload.command" };
      }
      return { ok: true, payload: { command } };
    }
    if (action === "git.diff") {
      if (source.staged !== void 0 && typeof source.staged !== "boolean") {
        return { ok: false, error: "git.diff payload.staged must be boolean" };
      }
      return { ok: true, payload: { staged: source.staged === true } };
    }
    return { ok: true, payload: {} };
  }
  function validateMemoryTarget(target) {
    const raw = (readString(target, "document") ?? "").trim().toLowerCase();
    if (!raw) {
      return { ok: false, error: "memory actions require target.document" };
    }
    const normalized = raw.endsWith(".md") ? raw : `${raw}.md`;
    if (!MEMORY_DOCUMENTS.includes(normalized)) {
      return { ok: false, error: `unknown memory document: ${raw}` };
    }
    return { ok: true, document: normalized };
  }
  function validateAction(value) {
    if (!isPlainObject(value)) {
      return { ok: false, error: "action block must be a JSON object" };
    }
    const version = readString(value, "version");
    if (version !== CCB_PROTOCOL_VERSION) {
      return { ok: false, error: `unsupported protocol version: ${String(value.version)}` };
    }
    const actionName = readString(value, "action");
    if (!actionName || !ACTION_TYPES.includes(actionName)) {
      return { ok: false, error: `unsupported action: ${String(value.action)}` };
    }
    const action = actionName;
    const target = value.target;
    if (!isPlainObject(target)) {
      return { ok: false, error: "target must be an object" };
    }
    const project = readString(target, "project")?.trim() ?? "";
    if (!PROJECT_PATTERN.test(project)) {
      return { ok: false, error: `invalid project name: ${project || "(empty)"}` };
    }
    let path = readString(target, "path")?.trim() ?? "";
    let document2;
    if (isMemoryAction(action)) {
      const memoryTarget = validateMemoryTarget(target);
      if (!memoryTarget.ok) return memoryTarget;
      document2 = memoryTarget.document;
      path = `memory/${document2}`;
    } else if (TOOL_ACTIONS.has(action)) {
      path = action.replace(".", "/");
    } else if (!isSafeRelativePath(path)) {
      return { ok: false, error: `unsafe or invalid path: ${path || "(empty)"}` };
    }
    const reason = (readString(value, "reason") ?? "").trim();
    if (!reason) {
      return { ok: false, error: "reason is required" };
    }
    if (reason.length > MAX_REASON_LENGTH) {
      return { ok: false, error: "reason exceeds 500 characters" };
    }
    const riskName = readString(value, "risk");
    if (!riskName || !RISK_LEVELS.includes(riskName)) {
      return { ok: false, error: `invalid risk level: ${String(value.risk)}` };
    }
    const risk = riskName;
    const payloadResult = validatePayload(action, value.payload);
    if (!payloadResult.ok) {
      return payloadResult;
    }
    const workflowId = readString(value, "workflow_id") ?? void 0;
    const stageId = readString(value, "stage_id") ?? void 0;
    if (workflowId && !WORKFLOW_PATTERN.test(workflowId) || stageId && !STAGE_PATTERN.test(stageId)) {
      return { ok: false, error: "invalid workflow_id or stage_id" };
    }
    if (action === "test.run" && (!workflowId || !stageId)) {
      return { ok: false, error: "test.run requires workflow_id and stage_id" };
    }
    if (action === "workflow.status" && !workflowId) {
      return { ok: false, error: "workflow.status requires workflow_id" };
    }
    return {
      ok: true,
      action: {
        version: CCB_PROTOCOL_VERSION,
        action,
        target: document2 ? { project, path, document: document2 } : { project, path },
        reason,
        risk,
        payload: payloadResult.payload,
        workflow_id: workflowId,
        stage_id: stageId,
        requiresApproval: true
      }
    };
  }
  function parseActions(text2) {
    if (!text2 || !text2.includes("<ccb_action>")) {
      return [];
    }
    const results = [];
    BLOCK_PATTERN.lastIndex = 0;
    let match = BLOCK_PATTERN.exec(text2);
    while (match !== null) {
      const raw = match[1].trim();
      const id = fingerprint(raw);
      if (!raw) {
        results.push({ ok: false, error: "empty action block", raw, fingerprint: id });
      } else if (raw.length > MAX_BLOCK_LENGTH) {
        results.push({ ok: false, error: "action block too large", raw, fingerprint: id });
      } else {
        let parsed;
        try {
          parsed = JSON.parse(raw);
        } catch {
          results.push({ ok: false, error: "action block is not valid JSON", raw, fingerprint: id });
          match = BLOCK_PATTERN.exec(text2);
          continue;
        }
        const validated = validateAction(parsed);
        if (validated.ok) {
          results.push({ ok: true, action: validated.action, raw, fingerprint: id });
        } else {
          results.push({ ok: false, error: validated.error, raw, fingerprint: id });
        }
      }
      match = BLOCK_PATTERN.exec(text2);
    }
    return results;
  }
  class ConversationObserver {
    adapter;
    debounceMs;
    onResults;
    seen = /* @__PURE__ */ new Set();
    observer = null;
    timer = null;
    root = null;
    constructor(options) {
      this.adapter = options.adapter ?? defaultSelectorAdapter;
      this.debounceMs = options.debounceMs ?? 400;
      this.onResults = options.onResults;
    }
    /** Attach to the conversation root. Returns false when it is not found yet. */
    start(doc = document) {
      const root = this.adapter.findConversationRoot(doc);
      if (!root) return false;
      this.stop();
      this.root = root;
      this.observer = new MutationObserver(() => this.schedule());
      this.observer.observe(root, {
        childList: true,
        subtree: true,
        characterData: true
      });
      this.scan();
      return true;
    }
    stop() {
      if (this.timer !== null) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.observer?.disconnect();
      this.observer = null;
      this.root = null;
    }
    get attached() {
      return this.observer !== null;
    }
    schedule() {
      if (this.timer !== null) clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        this.timer = null;
        this.scan();
      }, this.debounceMs);
    }
    /** Scan the conversation for new, not-yet-seen action blocks. */
    scan() {
      if (!this.root) return [];
      const messages = this.adapter.findMessageNodes(this.root);
      const sources = messages.length > 0 ? messages : [this.root];
      const fresh = [];
      for (const element of sources) {
        const text2 = this.adapter.extractText(element);
        if (!text2.includes("<ccb_action>")) continue;
        for (const result of parseActions(text2)) {
          if (this.seen.has(result.fingerprint)) continue;
          this.seen.add(result.fingerprint);
          fresh.push(result);
        }
      }
      if (fresh.length > 0) {
        this.onResults(fresh);
      }
      return fresh;
    }
    /** Testing/debug helper. */
    reset() {
      this.seen.clear();
    }
  }
  const ONBOARDING_STEPS = Object.freeze([
    Object.freeze({
      id: "start_bridge",
      title: "Start Local Bridge",
      detail: "Run: uvicorn app.main:app --port 8765 — the extension talks to 127.0.0.1 only."
    }),
    Object.freeze({
      id: "configure_provider",
      title: "Configure Provider",
      detail: "Open Settings and pick a provider. The API key goes to the Bridge and is encrypted there."
    }),
    Object.freeze({
      id: "test_connection",
      title: "Test Connection",
      detail: "Use Test connection in Settings. The result is a fixed status word, never a provider response."
    }),
    Object.freeze({
      id: "start_chat",
      title: "Start Chat",
      detail: "Ask a question. The assistant explains and drafts; every change stays a proposal."
    })
  ]);
  const ONBOARDING_STEP_COUNT = ONBOARDING_STEPS.length;
  const STORAGE_KEY = "ccb_state_v1";
  const MAX_ASSISTANT_CONVERSATIONS = 20;
  const MAX_CONVERSATION_TITLE = 80;
  function sanitizeConversationTitle(title) {
    return title.replace(/[\r\n\t]+/g, " ").replace(/\s+/g, " ").trim().slice(0, MAX_CONVERSATION_TITLE);
  }
  function capConversations(list2) {
    if (list2.length <= MAX_ASSISTANT_CONVERSATIONS) return list2;
    const overflow = list2.length - MAX_ASSISTANT_CONVERSATIONS;
    const dropped = /* @__PURE__ */ new Set();
    for (const item2 of list2) {
      if (dropped.size >= overflow) break;
      if (!item2.pinned) dropped.add(item2.id);
    }
    for (const item2 of list2) {
      if (dropped.size >= overflow) break;
      dropped.add(item2.id);
    }
    return list2.filter((item2) => !dropped.has(item2.id));
  }
  function visibleAssistantConversations(list2, query = "") {
    const needle = query.trim().toLowerCase();
    const matches = needle ? list2.filter((item2) => {
      if (item2.title.toLowerCase().includes(needle)) return true;
      return item2.turns.some((turn) => turn.content.toLowerCase().includes(needle));
    }) : [...list2];
    matches.reverse();
    const pinned = matches.filter((item2) => item2.pinned);
    const rest = matches.filter((item2) => !item2.pinned);
    return [...pinned, ...rest];
  }
  const FORBIDDEN_STATE_KEY_FRAGMENTS = [
    "apikey",
    "api_key",
    "secret",
    "authorization",
    "credential",
    "bearer",
    "token",
    "password"
  ];
  const TRANSIENT_STATE_KEYS = [
    "assistantWebContext",
    "assistantProviderTest",
    "assistantStreaming",
    "assistantConversationQuery",
    "assistantRenaming",
    "assistantContextInclude",
    "assistantDraft"
  ];
  function isForbiddenStateKey(key) {
    const normalized = key.toLowerCase();
    return FORBIDDEN_STATE_KEY_FRAGMENTS.some((fragment) => normalized.includes(fragment));
  }
  function stripForbiddenKeys(value) {
    const clean = {};
    for (const [key, entry] of Object.entries(value)) {
      if (isForbiddenStateKey(key)) continue;
      clean[key] = entry;
    }
    return clean;
  }
  function createInitialState() {
    return {
      bridgeStatus: "unknown",
      bridgeOrigin: DEFAULT_BRIDGE_ORIGIN,
      currentProject: null,
      uiMode: "user",
      onboardingState: "new",
      onboardingStep: 0,
      assistantProvider: "local",
      assistantModel: "",
      assistantSettings: null,
      assistantProviders: [],
      assistantProviderTest: null,
      assistantContextStatus: null,
      assistantWebContext: null,
      assistantConversations: [],
      assistantActiveConversation: null,
      assistantStreaming: false,
      assistantStatus: "",
      assistantConversationQuery: "",
      assistantRenaming: null,
      assistantContextInclude: true,
      assistantDraft: "",
      pendingActions: [],
      lastResult: null,
      projectContext: null,
      devContext: null,
      devContextSelection: [],
      phase30Intelligence: null,
      llmProviders: [],
      llmModels: [],
      llmConversations: [],
      llmToolProposals: [],
      recoveredApprovals: [],
      sessions: [],
      agents: [],
      modelSelection: null,
      runtimes: [],
      tasks: [],
      runtimeEvents: [],
      qualityReport: null,
      teams: [],
      dependencies: [],
      collaborationEvents: [],
      projectProfile: null,
      projectGraph: null,
      impactReport: null,
      projectMemoryHistory: null,
      intelligenceInsights: [],
      intelligenceProposals: [],
      intelligenceDecisions: [],
      intelligenceQuality: null,
      intelligenceObservations: [],
      intelligencePatterns: [],
      intelligencePredictions: [],
      intelligenceRecommendations: [],
      intelligenceOutcomes: [],
      intelligenceKnowledge: [],
      intelligenceEvidence: [],
      intelligenceQuality11: null,
      intelligenceTrends: [],
      intelligenceCorrelations: [],
      intelligenceImpactPredictions: [],
      intelligenceDependencyRisks: [],
      intelligenceEvaluations: [],
      intelligenceEvaluationMetrics: null,
      intelligenceRecommendationRanking: null,
      intelligenceEvidenceGraph: null,
      intelligenceValidation: null,
      intelligenceAccuracy: null,
      intelligenceEffectiveness: [],
      intelligenceEffectivenessSummary: null,
      intelligenceDecisionOutcomes: [],
      intelligenceDecisionSummary: null,
      intelligenceBenchmarks: [],
      intelligenceImprovements: [],
      intelligenceGovernance: null,
      simulation: null,
      simulationScenarios: [],
      simulationEvaluations: [],
      simulationPlans: [],
      simulationQuality: null,
      planningMemoryHistory: null,
      executionTasks: [],
      executionProposals: [],
      executionResults: [],
      executionQuality7: null,
      executionMemoryHistory: null,
      executionLoops: [],
      executionLoopTimeline: [],
      executionLoopQuality8: null,
      executionDags: [],
      executionDagReady: null,
      engineeringMetrics: null,
      executionLoopContext: null,
      engineeringGraph: null,
      failurePatterns: [],
      evolutionTimeline: [],
      agentCapabilityMetrics: [],
      benchmarks: [],
      demoScenarios: [],
      demoFlow: [],
      replays: [],
      artifacts: [],
      governanceHealth: null,
      governanceDrift: null,
      governanceDebt: null,
      governancePolicies: null,
      governanceTimeline: null,
      governanceQuality9: null,
      organizationGraph: null,
      organizationHealth: null,
      organizationDashboard: null,
      organizationPatterns: null,
      organizationIncidents: null,
      organizationLearning: null,
      organizationQuality10: null,
      organizationStrategyImpact: null,
      organizationStrategyRisk: null,
      organizationStrategies: null,
      organizationRecommendations: null,
      organizationStrategyContext: null,
      lastContextRefresh: null,
      log: []
    };
  }
  function memoryStorage() {
    const data = /* @__PURE__ */ new Map();
    return {
      async get(key) {
        return data.has(key) ? { [key]: data.get(key) } : {};
      },
      async set(items) {
        for (const [key, value] of Object.entries(items)) data.set(key, value);
      }
    };
  }
  function resolveStorage() {
    const api = globalThis.chrome;
    const local = api?.storage?.local;
    if (!local) return memoryStorage();
    return {
      get: (key) => Promise.resolve(local.get(key)),
      set: (items) => Promise.resolve(local.set(items))
    };
  }
  class ExtensionStore {
    state = createInitialState();
    listeners = /* @__PURE__ */ new Set();
    storage;
    constructor(storage = resolveStorage()) {
      this.storage = storage;
    }
    getState() {
      return this.state;
    }
    subscribe(listener) {
      this.listeners.add(listener);
      listener(this.state);
      return () => this.listeners.delete(listener);
    }
    async hydrate() {
      try {
        const stored = await this.storage.get(STORAGE_KEY);
        const value = stored[STORAGE_KEY];
        if (value && typeof value === "object") {
          this.state = {
            ...createInitialState(),
            ...stripForbiddenKeys(value)
          };
        }
      } catch {
        this.state = createInitialState();
      }
      this.emit();
      return this.state;
    }
    emit() {
      for (const listener of this.listeners) listener(this.state);
    }
    async persist() {
      try {
        const snapshot = { ...this.state };
        for (const key of TRANSIENT_STATE_KEYS) delete snapshot[key];
        await this.storage.set({ [STORAGE_KEY]: snapshot });
      } catch {
      }
    }
    async update(patch) {
      this.state = { ...this.state, ...stripForbiddenKeys(patch) };
      this.emit();
      await this.persist();
      return this.state;
    }
    setBridgeStatus(status) {
      return this.update({ bridgeStatus: status });
    }
    setProject(project) {
      return this.update({ currentProject: project });
    }
    toggleDevContextSelection(id) {
      const selection = this.state.devContextSelection.includes(id) ? this.state.devContextSelection.filter((item2) => item2 !== id) : [...this.state.devContextSelection, id];
      return this.update({ devContextSelection: selection });
    }
    clearDevContextSelection() {
      return this.update({ devContextSelection: [] });
    }
    addPending(action) {
      const exists = this.state.pendingActions.some(
        (item2) => item2.fingerprint === action.fingerprint
      );
      if (exists) return Promise.resolve(this.state);
      return this.update({ pendingActions: [...this.state.pendingActions, action] });
    }
    patchPending(id, patch) {
      return this.update({
        pendingActions: this.state.pendingActions.map(
          (item2) => item2.id === id ? { ...item2, ...patch } : item2
        )
      });
    }
    removePending(id) {
      return this.update({
        pendingActions: this.state.pendingActions.filter((item2) => item2.id !== id)
      });
    }
    get pendingCount() {
      return this.state.pendingActions.filter((item2) => item2.state === "pending").length + this.state.recoveredApprovals.length;
    }
    appendLog(entry) {
      const record = { timestamp: (/* @__PURE__ */ new Date()).toISOString(), ...entry };
      const log = [...this.state.log, record].slice(-200);
      return this.update({ log });
    }
    // -- Phase 32 · AI Assistant -------------------------------------------
    /** Switch surfaces only. Backend capabilities are unaffected either way. */
    setUiMode(mode) {
      return this.update({ uiMode: mode });
    }
    // -- Phase 34 · first-run onboarding -----------------------------------
    //
    // Every method below writes display state only. None of them configures a
    // provider, stores a key, changes a permission level or touches the approval
    // queue: the guide *points at* Settings, it never acts for the user.
    /** Move from the automatic first-launch state into an explicit walkthrough. */
    startOnboarding() {
      return this.update({ onboardingState: "active", onboardingStep: 0 });
    }
    /** Next. Completing the last step finishes the guide and lands on Chat. */
    advanceOnboarding() {
      const next = this.state.onboardingStep + 1;
      if (next >= ONBOARDING_STEP_COUNT) return this.completeOnboarding();
      return this.update({ onboardingState: "active", onboardingStep: next });
    }
    /** Back, for a user who wants to re-read a step. Clamped at the first one. */
    regressOnboarding() {
      const previous = Math.max(0, this.state.onboardingStep - 1);
      return this.update({ onboardingState: "active", onboardingStep: previous });
    }
    /**
     * Skip. Chat is available immediately even with no Bridge and no provider —
     * an unconfigured user is allowed to look around.
     */
    skipOnboarding() {
      return this.update({ onboardingState: "skipped", onboardingStep: 0 });
    }
    /** Setup Later: dismissed for now, still offered as a hint. */
    deferOnboarding() {
      return this.update({ onboardingState: "later", onboardingStep: 0 });
    }
    /** All four steps done. Not shown again on the next launch. */
    completeOnboarding() {
      return this.update({ onboardingState: "done", onboardingStep: ONBOARDING_STEP_COUNT - 1 });
    }
    /** Re-open the guide from the hint. Explicit user action only. */
    reopenOnboarding() {
      return this.update({ onboardingState: "active", onboardingStep: 0 });
    }
    /** Store the Ask AI snapshot for display. Sending it stays a user action. */
    setAssistantWebContext(bundle) {
      return this.update({ assistantWebContext: bundle, assistantContextInclude: bundle !== null });
    }
    /**
     * Phase 34 · decide whether the captured bundle is injected.
     *
     * Only ever called from a click. Setting it to `true` does not send anything:
     * the bundle still travels with the user's next message and nothing else.
     */
    setAssistantContextInclude(include) {
      return this.update({ assistantContextInclude: include });
    }
    /** New Chat: an extension-view-only conversation, never a backend write. */
    newAssistantConversation(title = "New chat") {
      const conversation = {
        id: `local_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
        title,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        turns: [],
        localOnly: true
      };
      return this.update({
        assistantConversations: capConversations([...this.state.assistantConversations, conversation]),
        assistantActiveConversation: conversation.id,
        assistantStatus: "",
        assistantRenaming: null
      });
    }
    selectAssistantConversation(id) {
      if (!this.state.assistantConversations.some((item2) => item2.id === id)) {
        return Promise.resolve(this.state);
      }
      return this.update({ assistantActiveConversation: id });
    }
    /**
     * Remove a conversation from the extension view.
     *
     * Display state only: no Bridge call, so Phase 31 conversation storage keeps
     * every record it had.
     */
    removeAssistantConversation(id) {
      const conversations = this.state.assistantConversations.filter((item2) => item2.id !== id);
      const active = this.state.assistantActiveConversation === id ? conversations[conversations.length - 1]?.id ?? null : this.state.assistantActiveConversation;
      return this.update({
        assistantConversations: conversations,
        assistantActiveConversation: active,
        // A rename box open on the removed row would otherwise be orphaned.
        assistantRenaming: this.state.assistantRenaming === id ? null : this.state.assistantRenaming,
        // Removing the conversation on screen must not leave a dead status line.
        assistantStatus: this.state.assistantActiveConversation === id ? "" : this.state.assistantStatus
      });
    }
    // -- Phase 34 · conversation management (extension view only) -----------
    //
    // Search / Rename / Pin / Unpin / Remove all rewrite the local list. None of
    // them calls the Bridge, so backend conversation storage cannot be deleted or
    // modified from here, no provider key is touched, no tool proposal is created
    // and no LLM request is issued.
    /** Filter text for the local history list. Transient, never persisted. */
    setAssistantConversationQuery(query) {
      return this.update({ assistantConversationQuery: query.slice(0, 120) });
    }
    /** Open the inline rename box. Unknown ids are ignored. */
    beginRenameConversation(id) {
      if (!this.state.assistantConversations.some((item2) => item2.id === id)) {
        return Promise.resolve(this.state);
      }
      return this.update({ assistantRenaming: id });
    }
    cancelRenameConversation() {
      return this.update({ assistantRenaming: null });
    }
    /**
     * Rename a conversation in the extension view.
     *
     * An empty or whitespace-only title keeps the previous one, so the list can
     * never end up with an unclickable blank row.
     */
    renameAssistantConversation(id, title) {
      if (!this.state.assistantConversations.some((item2) => item2.id === id)) {
        return Promise.resolve(this.state);
      }
      const clean = sanitizeConversationTitle(title);
      return this.update({
        assistantConversations: this.state.assistantConversations.map(
          (item2) => item2.id === id ? { ...item2, title: clean || item2.title || "Untitled chat", renamed: clean.length > 0 || item2.renamed } : item2
        ),
        assistantRenaming: null
      });
    }
    /** Pin / Unpin. Pinned conversations sort first and survive list capping. */
    setAssistantConversationPinned(id, pinned) {
      if (!this.state.assistantConversations.some((item2) => item2.id === id)) {
        return Promise.resolve(this.state);
      }
      return this.update({
        assistantConversations: this.state.assistantConversations.map(
          (item2) => item2.id === id ? { ...item2, pinned } : item2
        )
      });
    }
    toggleAssistantConversationPinned(id) {
      const found = this.state.assistantConversations.find((item2) => item2.id === id);
      if (!found) return Promise.resolve(this.state);
      return this.setAssistantConversationPinned(id, !found.pinned);
    }
    async ensureConversation() {
      const active = this.state.assistantActiveConversation;
      if (active && this.state.assistantConversations.some((item2) => item2.id === active)) return active;
      const state = await this.newAssistantConversation();
      return state.assistantActiveConversation;
    }
    async appendAssistantTurn(turn) {
      const id = await this.ensureConversation();
      return this.update({
        assistantConversations: this.state.assistantConversations.map(
          (item2) => item2.id === id ? {
            ...item2,
            // A user-chosen name wins over the automatic first-message title.
            title: item2.turns.length === 0 && turn.role === "user" && !item2.renamed ? sanitizeConversationTitle(turn.content).slice(0, 60) || item2.title : item2.title,
            turns: [...item2.turns, turn]
          } : item2
        )
      });
    }
    patchAssistantTurn(turnId, patch) {
      return this.update({
        assistantConversations: this.state.assistantConversations.map((conversation) => ({
          ...conversation,
          turns: conversation.turns.map((turn) => turn.id === turnId ? { ...turn, ...patch } : turn)
        }))
      });
    }
    setAssistantStreaming(streaming, status = "") {
      return this.update({ assistantStreaming: streaming, assistantStatus: status });
    }
    /**
     * Stop streaming on the user's request.
     *
     * The partial reply is kept and marked stopped. Nothing is retried: a Stop
     * must never trigger an automatic new request.
     */
    stopAssistantStreaming() {
      const conversations = this.state.assistantConversations.map((conversation) => ({
        ...conversation,
        turns: conversation.turns.map(
          (turn) => turn.streaming ? { ...turn, streaming: false, stopped: true } : turn
        )
      }));
      return this.update({
        assistantConversations: conversations,
        assistantStreaming: false,
        assistantStatus: "Streaming stopped"
      });
    }
    /**
     * Phase 34 · keep (or clear) the composer text.
     *
     * Called with the typed text when a send fails, and with `""` once it has been
     * handed back to the composer. Purely display state — it never resends.
     */
    setAssistantDraft(draft) {
      return this.update({ assistantDraft: draft.slice(0, 8e3) });
    }
    /**
     * Phase 34 · mark the turns of a failed request.
     *
     * The user turn stays in the transcript exactly once, so Retry can reuse it
     * instead of appending a duplicate; a half-streamed assistant turn stops
     * streaming and is marked failed. No retry is scheduled here.
     */
    failAssistantStreaming(message) {
      const conversations = this.state.assistantConversations.map((conversation) => ({
        ...conversation,
        turns: conversation.turns.map(
          (turn) => turn.streaming ? { ...turn, streaming: false, failed: true } : turn
        )
      }));
      return this.update({
        assistantConversations: conversations,
        assistantStreaming: false,
        assistantStatus: message
      });
    }
    /**
     * Phase 34 · drop the failed assistant placeholder at the end of the active
     * conversation, so Retry replaces it instead of stacking another one.
     *
     * Only trailing **assistant** turns marked `failed` are removed: the user turn
     * is left exactly where it is, which is what lets Retry reuse it rather than
     * sending the same message twice. Nothing is requested from here.
     */
    dropFailedAssistantTail() {
      const id = this.state.assistantActiveConversation;
      if (!id) return Promise.resolve(this.state);
      return this.update({
        assistantConversations: this.state.assistantConversations.map((conversation) => {
          if (conversation.id !== id) return conversation;
          const turns = [...conversation.turns];
          while (turns.length) {
            const last = turns[turns.length - 1];
            if (last.role !== "assistant" || !last.failed) break;
            turns.pop();
          }
          return { ...conversation, turns };
        })
      });
    }
    get activeAssistantConversation() {
      const id = this.state.assistantActiveConversation;
      return this.state.assistantConversations.find((item2) => item2.id === id) ?? null;
    }
    /**
     * The text Retry would resend: the most recent user turn of the conversation
     * on screen. `null` when there is nothing to retry, which is why Retry can
     * never invent a request of its own.
     */
    get lastAssistantUserMessage() {
      const conversation = this.activeAssistantConversation;
      if (!conversation) return null;
      for (let index = conversation.turns.length - 1; index >= 0; index -= 1) {
        const turn = conversation.turns[index];
        if (turn.role === "user" && turn.content.trim()) return turn.content;
      }
      return null;
    }
  }
  const STAGE_ORDER = [
    "REQUIREMENT",
    "ANALYSIS",
    "ARCHITECTURE",
    "IMPLEMENTATION",
    "TESTING",
    "DEBUG",
    "DELIVERY"
  ];
  function label(value) {
    return value.replace(/_/g, " ").toLowerCase().replace(/(^|\s)\S/g, (char) => char.toUpperCase());
  }
  function stageFor(workflow, stageType) {
    return [...workflow.stages].reverse().find((stage) => stage.stageType === stageType);
  }
  function renderStageTimeline(doc, workflow) {
    const timeline = doc.createElement("div");
    timeline.className = "workflow-timeline";
    timeline.dataset.role = "stage-timeline";
    for (const stageType of STAGE_ORDER) {
      const stage = stageFor(workflow, stageType);
      const card = doc.createElement("div");
      const status = stage?.status ?? "PENDING";
      const stateClass = status === "APPROVED" ? "done" : status === "IN_PROGRESS" || status === "REPORTED" || status === "WAITING_APPROVAL" ? "active" : "pending";
      card.className = `timeline-stage ${stateClass}`;
      card.dataset.stage = stageType;
      const marker = doc.createElement("span");
      marker.className = "timeline-marker";
      marker.textContent = status === "APPROVED" ? "✓" : status === "IN_PROGRESS" || status === "REPORTED" || status === "WAITING_APPROVAL" ? "●" : "○";
      const name = doc.createElement("strong");
      name.textContent = label(stageType);
      const state = doc.createElement("small");
      state.textContent = label(status);
      card.append(marker, name, state);
      if (stage) {
        const meta = doc.createElement("small");
        meta.className = "timeline-meta";
        meta.textContent = `${stage.actionIds.length} action${stage.actionIds.length === 1 ? "" : "s"}`;
        card.appendChild(meta);
        if (stage.report) {
          const details = doc.createElement("details");
          details.className = "stage-report";
          const summary = doc.createElement("summary");
          summary.textContent = "View report";
          const report = doc.createElement("pre");
          report.textContent = stage.report;
          details.append(summary, report);
          card.appendChild(details);
        }
        if (stage.approvalRequestId) {
          const approval = doc.createElement("small");
          approval.className = "stage-approval";
          approval.textContent = status === "WAITING_APPROVAL" ? "Approval pending" : `Approval ${label(status)}`;
          card.appendChild(approval);
        }
      }
      timeline.appendChild(card);
    }
    return timeline;
  }
  function text(doc, value, className = "") {
    const node = doc.createElement("span");
    if (className) node.className = className;
    node.textContent = String(value ?? "—");
    return node;
  }
  function stat(doc, title, value, detail) {
    const card = doc.createElement("div");
    card.className = "dashboard-stat";
    const label2 = doc.createElement("span");
    label2.className = "dashboard-label";
    label2.textContent = title;
    const strong = doc.createElement("strong");
    strong.appendChild(text(doc, value));
    const small = doc.createElement("small");
    small.textContent = detail;
    card.append(label2, strong, small);
    return card;
  }
  function list(doc, values, empty) {
    const wrapper = doc.createElement("div");
    wrapper.className = "dashboard-list";
    if (!values.length) {
      wrapper.textContent = empty;
      return wrapper;
    }
    for (const value of values) {
      const item2 = doc.createElement("div");
      item2.className = "dashboard-list-item";
      item2.textContent = value;
      wrapper.appendChild(item2);
    }
    return wrapper;
  }
  function renderWorkflowDashboard(doc, context, runtime = { agents: [], modelSelection: null }) {
    const dashboard = doc.createElement("section");
    dashboard.className = "workflow-dashboard";
    dashboard.dataset.role = "workflow-dashboard";
    const heading = doc.createElement("div");
    heading.className = "dashboard-heading";
    const title = doc.createElement("div");
    title.className = "dashboard-title";
    title.textContent = "Workflow Dashboard";
    const badge = doc.createElement("span");
    badge.className = "dashboard-badge";
    badge.textContent = context ? "LIVE CONTEXT" : "NO PROJECT";
    heading.append(title, badge);
    dashboard.appendChild(heading);
    if (!context) {
      const empty = doc.createElement("div");
      empty.className = "dashboard-empty";
      empty.textContent = "Select a project and connect to load workflow context.";
      dashboard.appendChild(empty);
      return dashboard;
    }
    const workflow = context.currentWorkflow;
    const stats = doc.createElement("div");
    stats.className = "dashboard-stats";
    stats.append(
      stat(doc, "Project", context.project, "active workspace"),
      stat(doc, "Workflow", workflow?.name ?? "None", workflow?.status ?? "No workflow"),
      stat(
        doc,
        "Current stage",
        context.currentStage?.stageType ?? workflow?.currentStage ?? "—",
        context.currentStage?.status ?? workflow?.status ?? "Pending"
      ),
      stat(doc, "Pending approvals", context.pendingApprovals.length, "explicit decisions required"),
      stat(doc, "Test result", context.lastTestResult?.status ?? "—", context.lastTestResult ? "latest TESTING report" : "no result yet"),
      stat(doc, "Git", context.gitStatus.clean === true ? "Clean" : context.gitStatus.status ?? "Changes", "read-only status")
    );
    dashboard.appendChild(stats);
    const agentSection = doc.createElement("div");
    agentSection.className = "dashboard-agents";
    const agentTitle = doc.createElement("h4");
    agentTitle.textContent = "Multi-agent runtime";
    agentSection.appendChild(agentTitle);
    const agentSummary = doc.createElement("div");
    agentSummary.className = "agent-summary";
    const model = runtime.modelSelection?.model;
    agentSummary.textContent = model ? `Router: ${model.displayName} · ${runtime.modelSelection?.classification.taskType}` : "Router ready · no task selection";
    agentSection.appendChild(agentSummary);
    const agentValues = runtime.agents.slice(0, 6).map((agent) => `${agent.role} · ${agent.status} · ${agent.modelId}`);
    agentSection.appendChild(list(doc, agentValues, "No agents assigned"));
    dashboard.appendChild(agentSection);
    if (workflow) {
      const timelineTitle = doc.createElement("h4");
      timelineTitle.textContent = "Stage timeline";
      dashboard.append(timelineTitle, renderStageTimeline(doc, workflow));
    }
    const lower = doc.createElement("div");
    lower.className = "dashboard-lower";
    const tasks = doc.createElement("div");
    tasks.className = "dashboard-column";
    const tasksTitle = doc.createElement("h4");
    tasksTitle.textContent = "Open tasks";
    tasks.append(tasksTitle, list(doc, context.openTasks, "No open tasks"));
    const changes = doc.createElement("div");
    changes.className = "dashboard-column";
    const changesTitle = doc.createElement("h4");
    changesTitle.textContent = "Recent changes";
    changes.append(changesTitle, list(doc, context.recentChanges.slice(-5).map((entry) => `${entry.action ?? "event"} · ${entry.result ?? ""}`), "No recent changes"));
    const sessions = doc.createElement("div");
    sessions.className = "dashboard-column";
    const sessionsTitle = doc.createElement("h4");
    sessionsTitle.textContent = "Agent sessions";
    const sessionValues = (context.activeSessions ?? []).slice(0, 5).map((session) => {
      const id = String(session.id ?? "session").slice(-12);
      return `${id} · ${String(session.status ?? "UNKNOWN")}`;
    });
    sessions.append(sessionsTitle, list(doc, sessionValues, "No sessions"));
    lower.append(tasks, changes, sessions);
    dashboard.appendChild(lower);
    return dashboard;
  }
  function block$4(doc, title) {
    const node = doc.createElement("section");
    node.className = "runtime-block";
    const heading = doc.createElement("h4");
    heading.textContent = title;
    node.appendChild(heading);
    return node;
  }
  function item$1(doc, value, tone = "") {
    const node = doc.createElement("div");
    node.className = `runtime-item ${tone}`.trim();
    node.textContent = value;
    return node;
  }
  function renderRuntimeDashboard(doc, runtimes, tasks, events, quality) {
    const root = doc.createElement("section");
    root.className = "runtime-dashboard";
    root.dataset.role = "runtime-dashboard";
    const header = doc.createElement("div");
    header.className = "runtime-heading";
    const title = doc.createElement("strong");
    title.textContent = "Autonomous Runtime";
    const badge = doc.createElement("span");
    badge.textContent = "READ ONLY";
    badge.className = "runtime-badge";
    header.append(title, badge);
    root.appendChild(header);
    const summary = doc.createElement("div");
    summary.className = "runtime-summary";
    summary.append(
      item$1(doc, `${runtimes.length} runtime${runtimes.length === 1 ? "" : "s"}`),
      item$1(doc, `${tasks.filter((task) => task.status === "PENDING").length} pending tasks`),
      item$1(doc, `${tasks.filter((task) => task.status === "WAITING_APPROVAL").length} approvals`),
      item$1(doc, quality ? `Quality ${quality.qualityScore}/100` : "Quality —")
    );
    root.appendChild(summary);
    const runtimeBlock = block$4(doc, "Runtime status");
    for (const runtime of runtimes.slice(0, 5)) {
      runtimeBlock.appendChild(item$1(doc, `${runtime.id} · ${runtime.state} · agent ${runtime.agentId}`, runtime.state === "RECOVERED" ? "warning" : ""));
    }
    if (!runtimes.length) runtimeBlock.appendChild(item$1(doc, "No runtime records"));
    root.appendChild(runtimeBlock);
    const taskBlock = block$4(doc, "Task queue");
    for (const task of tasks.slice(0, 6)) taskBlock.appendChild(item$1(doc, `${task.status} · ${task.id} · priority ${task.priority}`));
    if (!tasks.length) taskBlock.appendChild(item$1(doc, "No tasks"));
    root.appendChild(taskBlock);
    const eventBlock = block$4(doc, "Recent events");
    for (const event of events.slice(-5).reverse()) eventBlock.appendChild(item$1(doc, `${event.type} · ${event.source} · ${new Date(event.timestamp).toLocaleTimeString()}`));
    if (!events.length) eventBlock.appendChild(item$1(doc, "No events"));
    root.appendChild(eventBlock);
    if (quality) {
      const qualityBlock = block$4(doc, "Quality gate");
      qualityBlock.appendChild(item$1(doc, `${quality.qualityScore}/100 · ${quality.risk.toUpperCase()}`, quality.risk === "high" || quality.risk === "critical" ? "warning" : ""));
      for (const issue of quality.blockingIssues) qualityBlock.appendChild(item$1(doc, issue, "warning"));
      root.appendChild(qualityBlock);
    }
    return root;
  }
  function row$1(doc, value, tone = "") {
    const node = doc.createElement("div");
    node.className = `collaboration-row ${tone}`.trim();
    node.textContent = value;
    return node;
  }
  function renderCollaborationDashboard(doc, teams, agents, dependencies, events) {
    const root = doc.createElement("section");
    root.className = "collaboration-dashboard";
    root.dataset.role = "collaboration-dashboard";
    const heading = doc.createElement("div");
    heading.className = "collaboration-heading";
    const title = doc.createElement("strong");
    title.textContent = "Agent Collaboration";
    const badge = doc.createElement("span");
    badge.className = "collaboration-badge";
    badge.textContent = "READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    const summary = doc.createElement("div");
    summary.className = "collaboration-summary";
    summary.append(row$1(doc, `${teams.length} team${teams.length === 1 ? "" : "s"}`), row$1(doc, `${agents.length} agents`), row$1(doc, `${dependencies.length} dependency${dependencies.length === 1 ? "" : "ies"}`), row$1(doc, `${events.length} messages`));
    root.appendChild(summary);
    const teamBlock = doc.createElement("div");
    teamBlock.className = "collaboration-block";
    const teamTitle = doc.createElement("h4");
    teamTitle.textContent = "Agent team";
    teamBlock.appendChild(teamTitle);
    if (!teams.length) teamBlock.appendChild(row$1(doc, "No team assigned"));
    for (const team of teams.slice(0, 3)) teamBlock.appendChild(row$1(doc, `${team.id} · ${team.status} · leader ${team.leader} · ${team.members.length} members`, team.status === "WAITING_APPROVAL" ? "warning" : ""));
    root.appendChild(teamBlock);
    const roster = doc.createElement("div");
    roster.className = "collaboration-block";
    const rosterTitle = doc.createElement("h4");
    rosterTitle.textContent = "Agent roster";
    roster.appendChild(rosterTitle);
    if (!agents.length) roster.appendChild(row$1(doc, "No active agents"));
    for (const agent of agents.slice(0, 8)) roster.appendChild(row$1(doc, `${agent.role} · ${agent.status} · ${agent.id}`));
    root.appendChild(roster);
    const graph = doc.createElement("div");
    graph.className = "collaboration-block";
    const graphTitle = doc.createElement("h4");
    graphTitle.textContent = "Task dependency graph";
    graph.appendChild(graphTitle);
    if (!dependencies.length) graph.appendChild(row$1(doc, "No dependency edges"));
    for (const edge of dependencies.slice(0, 8)) graph.appendChild(row$1(doc, `${edge.sourceTask}  →  ${edge.targetTask} · ${edge.dependencyType}`));
    root.appendChild(graph);
    const activity = doc.createElement("div");
    activity.className = "collaboration-block";
    const activityTitle = doc.createElement("h4");
    activityTitle.textContent = "Negotiation activity";
    activity.appendChild(activityTitle);
    if (!events.length) activity.appendChild(row$1(doc, "No collaboration messages"));
    for (const event of events.slice(-5).reverse()) activity.appendChild(row$1(doc, `${event.type} · ${event.sender} → ${event.receiver} · task ${event.taskId}`));
    root.appendChild(activity);
    return root;
  }
  function item(doc, value, tone = "") {
    const node = doc.createElement("div");
    node.className = `project-intelligence-item ${tone}`.trim();
    node.textContent = value;
    return node;
  }
  function renderProjectIntelligenceDashboard(doc, profile, graph, impact, memory) {
    const root = doc.createElement("section");
    root.className = "project-intelligence-dashboard";
    root.dataset.role = "project-intelligence-dashboard";
    const heading = doc.createElement("div");
    heading.className = "project-intelligence-heading";
    const title = doc.createElement("strong");
    title.textContent = "Project Intelligence";
    const badge = doc.createElement("span");
    badge.className = "project-intelligence-badge";
    badge.textContent = "READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    if (!profile) {
      root.appendChild(item(doc, "No indexed project yet. Code indexing remains approval-gated."));
      return root;
    }
    const overview = doc.createElement("div");
    overview.className = "project-intelligence-overview";
    overview.append(
      item(doc, `${profile.moduleCount} modules`),
      item(doc, `Complexity ${profile.complexityScore}/100`),
      item(doc, profile.architectureSummary),
      item(doc, profile.frameworks.join(" · ") || "Framework not detected")
    );
    root.appendChild(overview);
    const columns = doc.createElement("div");
    columns.className = "project-intelligence-columns";
    const graphBlock = doc.createElement("div");
    graphBlock.className = "project-intelligence-block";
    const graphTitle = doc.createElement("h4");
    graphTitle.textContent = "Architecture graph";
    graphBlock.appendChild(graphTitle);
    graphBlock.appendChild(item(doc, graph ? `${graph.nodes.length} nodes · ${graph.edges.length} relations` : "Graph not built"));
    for (const node of graph?.nodes.slice(0, 5) ?? []) graphBlock.appendChild(item(doc, `${node.type} · ${node.label}`));
    columns.appendChild(graphBlock);
    const impactBlock = doc.createElement("div");
    impactBlock.className = "project-intelligence-block";
    const impactTitle = doc.createElement("h4");
    impactTitle.textContent = "Change impact";
    impactBlock.appendChild(impactTitle);
    impactBlock.appendChild(item(doc, impact ? `${impact.risk.toUpperCase()} · ${impact.affectedModules.length} affected modules` : "No change selected", impact?.risk === "high" ? "warning" : ""));
    for (const path of impact?.affectedModules.slice(0, 5) ?? []) impactBlock.appendChild(item(doc, path));
    columns.appendChild(impactBlock);
    const memoryBlock = doc.createElement("div");
    memoryBlock.className = "project-intelligence-block";
    const memoryTitle = doc.createElement("h4");
    memoryTitle.textContent = "Memory timeline";
    memoryBlock.appendChild(memoryTitle);
    for (const record of memory?.history.slice(0, 5) ?? []) memoryBlock.appendChild(item(doc, `${record.category} · ${record.updatedAt}`));
    if (!memory?.history.length) memoryBlock.appendChild(item(doc, "No project memory records"));
    columns.appendChild(memoryBlock);
    root.appendChild(columns);
    return root;
  }
  function line$c(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `engineering-intelligence-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function renderIntelligenceDashboard$1(doc, insights, proposals, decisions, quality, evolution, phase26, phase27, phase28) {
    const root = doc.createElement("section");
    root.className = "engineering-intelligence-dashboard";
    root.dataset.role = "engineering-intelligence-dashboard";
    const heading = doc.createElement("div");
    heading.className = "engineering-intelligence-heading";
    const title = doc.createElement("strong");
    title.textContent = "Engineering Intelligence";
    const badge = doc.createElement("span");
    badge.className = "engineering-intelligence-badge";
    badge.textContent = "ANALYSIS · READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    const summary = doc.createElement("div");
    summary.className = "engineering-intelligence-summary";
    summary.append(
      line$c(doc, `${insights.length} insights`),
      line$c(doc, `${proposals.length} proposals`),
      line$c(doc, `${decisions.length} decisions`),
      line$c(doc, quality ? `Quality ${quality.quality}/100` : "Quality pending")
    );
    root.appendChild(summary);
    const blocks = doc.createElement("div");
    blocks.className = "engineering-intelligence-blocks";
    const insightBlock = doc.createElement("div");
    insightBlock.className = "engineering-intelligence-block";
    const insightTitle = doc.createElement("h4");
    insightTitle.textContent = "Risk signals";
    insightBlock.appendChild(insightTitle);
    for (const insight of insights.slice(0, 4)) {
      insightBlock.appendChild(line$c(doc, `${insight.severity.toUpperCase()} · ${insight.title}`, insight.severity === "high" || insight.severity === "critical" ? "warning" : ""));
    }
    if (!insights.length) insightBlock.appendChild(line$c(doc, "No analyzed risks yet"));
    blocks.appendChild(insightBlock);
    const proposalBlock = doc.createElement("div");
    proposalBlock.className = "engineering-intelligence-block";
    const proposalTitle = doc.createElement("h4");
    proposalTitle.textContent = "Active proposals";
    proposalBlock.appendChild(proposalTitle);
    for (const proposal of proposals.slice(0, 4)) proposalBlock.appendChild(line$c(doc, `${proposal.type} · ${proposal.risk} (${proposal.riskScore})`));
    if (!proposals.length) proposalBlock.appendChild(line$c(doc, "No proposals yet"));
    blocks.appendChild(proposalBlock);
    const decisionBlock = doc.createElement("div");
    decisionBlock.className = "engineering-intelligence-block";
    const decisionTitle = doc.createElement("h4");
    decisionTitle.textContent = "Pending decisions";
    decisionBlock.appendChild(decisionTitle);
    for (const decision of decisions.slice(0, 4)) decisionBlock.appendChild(line$c(doc, `${decision.status} · ${decision.title}`));
    if (!decisions.length) decisionBlock.appendChild(line$c(doc, "No decisions recorded"));
    blocks.appendChild(decisionBlock);
    root.appendChild(blocks);
    if (quality) {
      const debt = doc.createElement("small");
      debt.className = "engineering-intelligence-debt";
      debt.textContent = `Technical debt ${quality.technicalDebt.score}/100 · ${quality.technicalDebt.items} item(s) · Risk ${quality.risk}`;
      root.appendChild(debt);
    }
    if (evolution) {
      const evolutionHeading = doc.createElement("h4");
      evolutionHeading.className = "engineering-intelligence-evolution-title";
      evolutionHeading.textContent = "Observation → Pattern → Prediction";
      root.appendChild(evolutionHeading);
      const evolutionSummary = doc.createElement("div");
      evolutionSummary.className = "engineering-intelligence-evolution-summary";
      evolutionSummary.append(
        line$c(doc, `${evolution.observations?.length ?? 0} observations`),
        line$c(doc, `${evolution.patterns?.length ?? 0} patterns`),
        line$c(doc, `${evolution.predictions?.length ?? 0} predictions`),
        line$c(doc, `${evolution.recommendations?.length ?? 0} recommendations`),
        line$c(doc, `${evolution.outcomes?.length ?? 0} outcomes`),
        line$c(doc, `${evolution.knowledge?.length ?? 0} knowledge records`),
        line$c(doc, `${evolution.evidence?.length ?? 0} evidence bundles`)
      );
      root.appendChild(evolutionSummary);
      const evolutionBlock = doc.createElement("div");
      evolutionBlock.className = "engineering-intelligence-evolution-block";
      for (const observation of (evolution.observations ?? []).slice(0, 3)) {
        evolutionBlock.appendChild(line$c(doc, `${observation.timestamp} · ${observation.type} · ${observation.summary}`));
      }
      for (const prediction of (evolution.predictions ?? []).slice(0, 4)) {
        const risk = prediction.risk_level ?? prediction.riskLevel ?? "medium";
        evolutionBlock.appendChild(line$c(doc, `${risk.toUpperCase()} · ${prediction.prediction_type ?? prediction.predictionType} · confidence ${prediction.confidence}`, risk === "high" || risk === "critical" ? "warning" : ""));
      }
      for (const recommendation of (evolution.recommendations ?? []).slice(0, 3)) {
        evolutionBlock.appendChild(line$c(doc, `→ ${recommendation.recommendation}`, "recommendation"));
      }
      if (!evolutionBlock.childElementCount) evolutionBlock.appendChild(line$c(doc, "No evidence-backed intelligence signals yet"));
      root.appendChild(evolutionBlock);
      const learningBlock = doc.createElement("div");
      learningBlock.className = "engineering-intelligence-evolution-block";
      for (const outcome of (evolution.outcomes ?? []).slice(0, 3)) {
        learningBlock.appendChild(line$c(doc, `Outcome · ${outcome.status} · ${outcome.actual_outcome}`));
      }
      for (const knowledge of (evolution.knowledge ?? []).slice(0, 3)) {
        learningBlock.appendChild(line$c(doc, `Knowledge · ${knowledge.category} · confidence ${knowledge.confidence}`));
      }
      for (const bundle of (evolution.evidence ?? []).slice(0, 3)) {
        learningBlock.appendChild(line$c(doc, `Evidence · ${bundle.bundle_id} · ${bundle.observation_ids.length} observation(s)`));
      }
      if (learningBlock.childElementCount) root.appendChild(learningBlock);
      if (evolution.quality) {
        root.appendChild(line$c(doc, `Quality Gate 11 · ${evolution.quality.status} · ${evolution.quality.quality}/100`, evolution.quality.status === "BLOCK" ? "warning" : ""));
      }
    }
    if (phase26) {
      const heading26 = doc.createElement("h4");
      heading26.className = "engineering-intelligence-phase26-title";
      heading26.textContent = "Engineering Intelligence 2.0 · READ ONLY";
      root.appendChild(heading26);
      const summary26 = doc.createElement("div");
      summary26.className = "engineering-intelligence-phase26-summary";
      summary26.append(
        line$c(doc, `${phase26.trends?.length ?? 0} trends`),
        line$c(doc, `${phase26.correlations?.length ?? 0} correlations`),
        line$c(doc, `${phase26.impact?.length ?? 0} impact predictions`),
        line$c(doc, `${phase26.dependencies?.length ?? 0} dependency risks`),
        line$c(doc, `${phase26.evaluations?.length ?? 0} evaluations`),
        line$c(doc, `${phase26.evidenceGraph?.nodes.length ?? 0} graph nodes`)
      );
      root.appendChild(summary26);
      const block26 = doc.createElement("div");
      block26.className = "engineering-intelligence-phase26-block";
      for (const trend of (phase26.trends ?? []).slice(0, 4)) {
        block26.appendChild(line$c(doc, `Trend · ${trend.metric} · ${trend.direction} · confidence ${trend.confidence}`, trend.direction === "increasing" || trend.direction === "volatile" ? "warning" : ""));
      }
      for (const correlation of (phase26.correlations ?? []).slice(0, 3)) {
        block26.appendChild(line$c(doc, `Correlation · ${correlation.relationship} · confidence ${correlation.confidence}`));
      }
      for (const impact of (phase26.impact ?? []).slice(0, 3)) {
        const risk = impact.risk_level ?? impact.riskLevel ?? "MEDIUM";
        block26.appendChild(line$c(doc, `Impact · ${risk} · ${impact.affected_modules?.length ?? impact.affectedModules?.length ?? 0} module(s) · confidence ${impact.confidence}`, risk === "HIGH" || risk === "CRITICAL" ? "warning" : ""));
      }
      for (const dependency of (phase26.dependencies ?? []).slice(0, 3)) {
        block26.appendChild(line$c(doc, `Dependency · ${dependency.risk} · ${dependency.dependency} · confidence ${dependency.confidence}`, dependency.risk === "HIGH" || dependency.risk === "CRITICAL" ? "warning" : ""));
      }
      if (!block26.childElementCount) block26.appendChild(line$c(doc, "No Phase 26 evidence signals yet"));
      root.appendChild(block26);
      const ranking = phase26.ranking;
      if (ranking) {
        const rankingBlock = doc.createElement("div");
        rankingBlock.className = "engineering-intelligence-phase26-block";
        rankingBlock.appendChild(line$c(doc, `Recommendation ranking · ${ranking.ranked.length} candidate(s) · confidence ${ranking.confidence}`));
        if (ranking.recommended_action) rankingBlock.appendChild(line$c(doc, `Recommended · ${ranking.recommended_action}`, "recommendation"));
        for (const alternative of (ranking.alternative_actions ?? ranking.alternativeActions ?? []).slice(0, 2)) rankingBlock.appendChild(line$c(doc, `Alternative · ${alternative}`, "recommendation"));
        root.appendChild(rankingBlock);
      }
      if (phase26.metrics) {
        const metrics = phase26.metrics;
        root.appendChild(line$c(doc, `Prediction accuracy · ${metrics.accuracy} · correct ${metrics.correct} · incorrect ${metrics.incorrect} · false positive ${metrics.false_positive_rate}`, metrics.accuracy < 0.5 ? "warning" : ""));
      }
      const graph = phase26.evidenceGraph;
      if (graph) root.appendChild(line$c(doc, `Evidence graph · ${graph.nodes.length} node(s) · ${graph.edges.length} edge(s)`));
    }
    if (phase27) {
      const heading27 = doc.createElement("h4");
      heading27.className = "engineering-intelligence-phase26-title";
      heading27.textContent = "Engineering Intelligence Validation · READ ONLY";
      root.appendChild(heading27);
      const accuracy = phase27.accuracy;
      const summary27 = doc.createElement("div");
      summary27.className = "engineering-intelligence-phase26-summary";
      summary27.append(
        line$c(doc, `${phase27.evaluations?.length ?? 0} evaluations`),
        line$c(doc, accuracy ? `accuracy ${accuracy.accuracy}` : "accuracy pending"),
        line$c(doc, phase27.effectivenessSummary ? `effectiveness ${phase27.effectivenessSummary.effectivenessRate}` : "effectiveness pending"),
        line$c(doc, phase27.decisionSummary ? `decision success ${phase27.decisionSummary.overallSuccessRate}` : "decision outcomes pending"),
        line$c(doc, `${phase27.benchmarks?.length ?? 0} benchmark runs`),
        line$c(doc, `${phase27.improvements?.length ?? 0} knowledge improvements`)
      );
      root.appendChild(summary27);
      const validationBlock = doc.createElement("div");
      validationBlock.className = "engineering-intelligence-phase26-block";
      if (accuracy) {
        validationBlock.appendChild(line$c(doc, `Accuracy · ${accuracy.accuracy} · correct ${accuracy.correct} · incorrect ${accuracy.incorrect} · precision ${accuracy.precision} · recall ${accuracy.recall}`, accuracy.accuracy < 0.5 ? "warning" : ""));
        validationBlock.appendChild(line$c(doc, `False positives ${accuracy.falsePositive} · false negatives ${accuracy.falseNegative} · calibration error ${accuracy.calibrationError}`));
        const populated = (accuracy.calibration ?? []).filter((bin) => bin.count > 0);
        if (populated.length) {
          validationBlock.appendChild(line$c(doc, `Confidence calibration · ${populated.map((bin) => `${bin.lower}-${bin.upper}: ${bin.binAccuracy}`).join(" · ")}`));
        }
      }
      const failed = phase27.failedPredictions ?? [];
      for (const record of failed.slice(0, 3)) {
        validationBlock.appendChild(line$c(doc, `Failed · ${record.prediction_id} · ${record.evaluation_kind} · ${record.prediction_result}`, "warning"));
      }
      if (!validationBlock.childElementCount) validationBlock.appendChild(line$c(doc, "No validation records yet"));
      root.appendChild(validationBlock);
      const effectivenessBlock = doc.createElement("div");
      effectivenessBlock.className = "engineering-intelligence-phase26-block";
      const effectivenessSummary = phase27.effectivenessSummary;
      if (effectivenessSummary) {
        effectivenessBlock.appendChild(line$c(doc, `Effectiveness · ${effectivenessSummary.effectivenessRate} · correct ${effectivenessSummary.correct} · partially useful ${effectivenessSummary.partiallyUseful} · incorrect ${effectivenessSummary.incorrect} · rejected ${effectivenessSummary.rejected}`));
      }
      for (const record of (phase27.effectiveness ?? []).slice(0, 3)) {
        effectivenessBlock.appendChild(line$c(doc, `Recommendation · ${record.classification} · score ${record.effectiveness_score} · ${record.content}`, record.classification === "incorrect" ? "warning" : ""));
      }
      if (effectivenessBlock.childElementCount) root.appendChild(effectivenessBlock);
      const decisionBlock2 = doc.createElement("div");
      decisionBlock2.className = "engineering-intelligence-phase26-block";
      const decisionSummary = phase27.decisionSummary;
      if (decisionSummary) {
        const rates = Object.entries(decisionSummary.byType ?? {}).map(([type, value]) => `${type} ${value.successRate}`).join(" · ");
        decisionBlock2.appendChild(line$c(doc, `Decision outcomes · ${decisionSummary.total} · overall success ${decisionSummary.overallSuccessRate}${rates ? ` · ${rates}` : ""}`));
      }
      for (const record of (phase27.decisionOutcomes ?? []).slice(0, 3)) {
        decisionBlock2.appendChild(line$c(doc, `Decision · ${record.decision_type} · ${record.status} · ${record.title}`));
      }
      if (decisionBlock2.childElementCount) root.appendChild(decisionBlock2);
      const benchmarkBlock = doc.createElement("div");
      benchmarkBlock.className = "engineering-intelligence-phase26-block";
      for (const run of (phase27.benchmarks ?? []).slice(0, 3)) {
        benchmarkBlock.appendChild(line$c(doc, `Benchmark · ${run.dataset_name ?? run.datasetName} · score ${run.score} · accuracy ${run.accuracy} · model ${run.model_id}`));
      }
      if (!benchmarkBlock.childElementCount) benchmarkBlock.appendChild(line$c(doc, "No benchmark runs recorded"));
      root.appendChild(benchmarkBlock);
      const improvementBlock = doc.createElement("div");
      improvementBlock.className = "engineering-intelligence-phase26-block";
      for (const improvement of (phase27.improvements ?? []).slice(0, 4)) {
        improvementBlock.appendChild(line$c(doc, `Improvement · ${improvement.status} · ${improvement.category} · confidence ${improvement.confidence}`, improvement.status === "pending" || improvement.status === "proposed" ? "recommendation" : ""));
      }
      if (!improvementBlock.childElementCount) improvementBlock.appendChild(line$c(doc, "No knowledge improvement proposals"));
      root.appendChild(improvementBlock);
      if (phase27.quality13) {
        root.appendChild(line$c(doc, `Quality Gate 13 · ${phase27.quality13.status} · ${phase27.quality13.quality}/100`, phase27.quality13.status === "BLOCK" ? "warning" : ""));
      }
    }
    if (phase28) {
      const heading28 = doc.createElement("h4");
      heading28.className = "engineering-intelligence-phase26-title";
      heading28.textContent = "Intelligence Governance · READ ONLY";
      root.appendChild(heading28);
      const quality14 = phase28.quality14;
      const summary28 = doc.createElement("div");
      summary28.className = "engineering-intelligence-phase26-summary";
      summary28.append(
        line$c(doc, quality14 ? `Quality Gate 14 · ${quality14.status} · ${quality14.quality}/100` : "Quality Gate 14 pending", quality14?.status === "BLOCKED" || quality14?.status === "REVIEW_REQUIRED" ? "warning" : ""),
        line$c(doc, `${phase28.records?.length ?? 0} governance records`),
        line$c(doc, `${phase28.risks?.length ?? 0} risk findings`),
        line$c(doc, `${phase28.violations?.length ?? 0} policy violations`),
        line$c(doc, `${phase28.reviews?.length ?? 0} review proposals`),
        line$c(doc, `${phase28.trends?.length ?? 0} governance trends`)
      );
      root.appendChild(summary28);
      const riskBlock = doc.createElement("div");
      riskBlock.className = "engineering-intelligence-phase26-block";
      if (quality14) {
        riskBlock.appendChild(line$c(doc, `Risk · max ${quality14.maxRiskLevel} · score ${quality14.maxRiskScore} · benchmark ${quality14.benchmarkScore ?? "n/a"}`, quality14.maxRiskLevel === "HIGH" || quality14.maxRiskLevel === "CRITICAL" ? "warning" : ""));
        if (quality14.regressionRate !== null && quality14.regressionRate !== void 0) riskBlock.appendChild(line$c(doc, `Regression rate · ${quality14.regressionRate}`, quality14.regressionRate > 0.2 ? "warning" : ""));
      }
      let riskCount = 0;
      for (const risk of (phase28.risks ?? []).slice(0, 4)) {
        riskBlock.appendChild(line$c(doc, `Risk · ${risk.risk_level} · ${risk.risk_score} · ${risk.reason}`, risk.risk_level === "HIGH" || risk.risk_level === "CRITICAL" ? "warning" : ""));
        riskCount += 1;
      }
      if (!riskCount) riskBlock.appendChild(line$c(doc, "No risk findings recorded"));
      root.appendChild(riskBlock);
      const trendBlock = doc.createElement("div");
      trendBlock.className = "engineering-intelligence-phase26-block";
      for (const trend of (phase28.trends ?? []).slice(0, 5)) {
        trendBlock.appendChild(line$c(doc, `Trend · ${trend.metric} · ${trend.direction} · Δ${trend.change_rate} · confidence ${trend.confidence}`, trend.direction === "declining" || trend.direction === "increasing" ? "warning" : ""));
      }
      for (const signal of (phase28.signals ?? []).slice(0, 3)) {
        trendBlock.appendChild(line$c(doc, `Signal · ${signal.signal} · ${signal.detail}`, "warning"));
      }
      if (!trendBlock.childElementCount) trendBlock.appendChild(line$c(doc, "No governance trends yet"));
      root.appendChild(trendBlock);
      const violationBlock = doc.createElement("div");
      violationBlock.className = "engineering-intelligence-phase26-block";
      for (const violation of (phase28.violations ?? []).slice(0, 3)) {
        violationBlock.appendChild(line$c(doc, `Violation · ${violation.policy_id} · ${violation.severity} · ${violation.reason}`, violation.severity === "blocking" ? "warning" : ""));
      }
      if (!violationBlock.childElementCount) violationBlock.appendChild(line$c(doc, "No policy violations"));
      root.appendChild(violationBlock);
      const reviewBlock = doc.createElement("div");
      reviewBlock.className = "engineering-intelligence-phase26-block";
      for (const review of (phase28.reviews ?? []).slice(0, 4)) {
        reviewBlock.appendChild(line$c(doc, `Review · ${review.status} · ${review.risk_level} · ${review.source_kind} ${review.source_id} · ${review.recommended_action}`, review.status === "proposed" ? "recommendation" : ""));
      }
      if (!reviewBlock.childElementCount) reviewBlock.appendChild(line$c(doc, "No governance review proposals"));
      root.appendChild(reviewBlock);
      const policyBlock = doc.createElement("div");
      policyBlock.className = "engineering-intelligence-phase26-block";
      for (const policy of (phase28.policies ?? []).slice(0, 4)) {
        policyBlock.appendChild(line$c(doc, `Policy · ${policy.policy_id} · ${policy.severity} · threshold ${policy.threshold} · scope ${policy.scope}`));
      }
      if (!policyBlock.childElementCount) policyBlock.appendChild(line$c(doc, "No policies registered"));
      root.appendChild(policyBlock);
      const graph = phase28.graph;
      if (graph) {
        root.appendChild(line$c(doc, `Governance graph · ${graph.nodeCount} node(s) · ${graph.edgeCount} edge(s) · read only`));
      }
    }
    return root;
  }
  function line$b(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `simulation-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function renderSimulationDashboard(doc, simulation, scenarios, evaluations, plans, quality) {
    const root = doc.createElement("section");
    root.className = "simulation-dashboard";
    root.dataset.role = "simulation-dashboard";
    const heading = doc.createElement("div");
    heading.className = "simulation-heading";
    const title = doc.createElement("strong");
    title.textContent = "Engineering Simulation";
    const badge = doc.createElement("span");
    badge.className = "simulation-badge";
    badge.textContent = "SIMULATION · READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    if (!simulation) {
      root.appendChild(line$b(doc, "No simulation created yet"));
      return root;
    }
    root.appendChild(line$b(doc, `Problem · ${simulation.problem}`, "simulation-problem"));
    root.appendChild(line$b(doc, `${scenarios.length} candidate solutions · ${simulation.status}`));
    const candidates = doc.createElement("div");
    candidates.className = "simulation-candidates";
    for (const scenario of scenarios.slice(0, 4)) {
      const block2 = doc.createElement("article");
      block2.className = "simulation-candidate";
      block2.appendChild(line$b(doc, scenario.name));
      block2.appendChild(line$b(doc, `${scenario.type} · ${scenario.risk.toUpperCase()} risk · impact ${scenario.impactScore}/100`, scenario.risk === "high" ? "warning" : ""));
      block2.appendChild(line$b(doc, `${scenario.affectedFiles.length} files · ${scenario.dependentModules.length} dependents`));
      const evaluation = evaluations.find((item2) => item2.scenario === scenario.id);
      if (evaluation) block2.appendChild(line$b(doc, `Score ${evaluation.score}/100 · ${evaluation.advantages[0] ?? "evaluated"}`));
      candidates.appendChild(block2);
    }
    if (!scenarios.length) candidates.appendChild(line$b(doc, "No scenarios analyzed yet"));
    root.appendChild(candidates);
    if (plans.length) {
      const plan = plans[0];
      const preview = doc.createElement("pre");
      preview.className = "simulation-plan";
      preview.textContent = plan.content.slice(0, 900);
      root.appendChild(preview);
    }
    if (quality) root.appendChild(line$b(doc, `Quality ${quality.quality}/100 · confidence ${(quality.simulationConfidence * 100).toFixed(0)}%`, "simulation-quality"));
    return root;
  }
  function line$a(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `execution-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function renderExecutionDashboard(doc, tasks, proposals, results, quality) {
    const root = doc.createElement("section");
    root.className = "execution-dashboard";
    root.dataset.role = "execution-dashboard";
    const heading = doc.createElement("div");
    heading.className = "execution-heading";
    const title = doc.createElement("strong");
    title.textContent = "Execution Control Center";
    const badge = doc.createElement("span");
    badge.className = "execution-badge";
    badge.textContent = "CONTROLLED · READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    if (!tasks.length && !proposals.length && !results.length && !quality) {
      root.appendChild(line$a(doc, "No controlled execution yet"));
      return root;
    }
    const waiting = proposals.filter((item2) => item2.status === "PROPOSED").length;
    const pendingTasks = tasks.filter((item2) => item2.status === "APPROVAL_REQUIRED").length;
    root.appendChild(line$a(doc, `${tasks.length} implementation tasks · ${pendingTasks} waiting approval · ${waiting} proposals pending`));
    const overview = doc.createElement("div");
    overview.className = "execution-overview";
    const items = [
      ["Tasks", String(tasks.length)],
      ["Proposal queue", String(waiting)],
      ["Executed", String(results.length)],
      ["Verified", String(results.filter((item2) => item2.verification.status === "PASS").length)]
    ];
    for (const [label2, value] of items) {
      const cell = doc.createElement("div");
      cell.className = "execution-item";
      cell.appendChild(line$a(doc, label2));
      cell.appendChild(line$a(doc, value, "execution-count"));
      overview.appendChild(cell);
    }
    root.appendChild(overview);
    if (tasks.length) {
      const block2 = doc.createElement("div");
      block2.className = "execution-block";
      const sub = doc.createElement("h4");
      sub.textContent = "Implementation Tasks";
      block2.appendChild(sub);
      for (const task of tasks.slice(0, 8)) {
        const row2 = doc.createElement("div");
        row2.className = "execution-task";
        row2.appendChild(line$a(doc, `${task.title} · ${task.status}`, task.risk === "high" ? "warning" : ""));
        row2.appendChild(line$a(doc, `${task.risk.toUpperCase()} risk ${task.riskScore}/100 · ${task.files.length} file(s)`));
        if (task.verification?.status) row2.appendChild(line$a(doc, `Verification ${task.verification.status}`, task.verification.status === "PASS" ? "pass" : "warning"));
        block2.appendChild(row2);
      }
      root.appendChild(block2);
    }
    if (proposals.length) {
      const block2 = doc.createElement("div");
      block2.className = "execution-block";
      const sub = doc.createElement("h4");
      sub.textContent = "Proposal Queue";
      block2.appendChild(sub);
      for (const proposal of proposals.slice(0, 6)) {
        const row2 = doc.createElement("div");
        row2.className = "execution-proposal";
        row2.appendChild(line$a(doc, `${proposal.id} · ${proposal.status}`, proposal.status === "PROPOSED" ? "pending" : ""));
        row2.appendChild(line$a(doc, `${proposal.operations.length} operation(s) · risk ${proposal.riskScore}/100`));
        block2.appendChild(row2);
      }
      root.appendChild(block2);
    }
    if (results.length) {
      const block2 = doc.createElement("div");
      block2.className = "execution-block";
      const sub = doc.createElement("h4");
      sub.textContent = "Execution History";
      block2.appendChild(sub);
      for (const result of results.slice(0, 6)) {
        const row2 = doc.createElement("div");
        row2.className = "execution-result";
        row2.appendChild(line$a(doc, `${result.id} · ${result.verification.status} in ${result.durationMs}ms`, result.verification.status === "PASS" ? "pass" : "warning"));
        row2.appendChild(line$a(doc, `${result.filesChanged.length} file(s) · ${result.verification.checks.join(" · ")}`));
        block2.appendChild(row2);
      }
      root.appendChild(block2);
    }
    if (quality) {
      root.appendChild(
        line$a(
          doc,
          `Quality ${quality.quality}/100 · execution ${quality.executionReady ? "ready" : "blocked"}`,
          quality.executionReady ? "pass" : "warning"
        )
      );
    }
    return root;
  }
  function line$9(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `loop-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function toneFor(status) {
    if (status === "COMPLETED" || status === "PROPOSAL_READY") return "pass";
    if (status === "FAILED" || status === "ROLLED_BACK" || status === "CANCELLED") return "warning";
    if (status === "WAITING_APPROVAL") return "pending";
    return "";
  }
  function renderExecutionLoopDashboard(doc, loops, quality, phase17 = {}) {
    const root = doc.createElement("section");
    root.className = "execution-loop-dashboard";
    root.dataset.role = "execution-loop-dashboard";
    const heading = doc.createElement("div");
    heading.className = "execution-loop-heading";
    const title = doc.createElement("strong");
    title.textContent = "Execution Loop";
    const badge = doc.createElement("span");
    badge.className = "execution-loop-badge";
    badge.textContent = "APPROVAL CONTROLLED · READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    if (!loops.length && !quality && !phase17.dags?.length && !phase17.metrics && !phase17.context) {
      root.appendChild(line$9(doc, "No execution loop yet"));
      return root;
    }
    const active = loops.filter((loop) => loop.status === "EXECUTING" || loop.status === "VERIFYING" || loop.status === "WAITING_APPROVAL").length;
    const completed = loops.filter((loop) => loop.status === "COMPLETED").length;
    root.appendChild(line$9(doc, `${loops.length} loop(s) · ${active} active · ${completed} completed`));
    if (loops.length) {
      const block2 = doc.createElement("div");
      block2.className = "execution-loop-block";
      const sub = doc.createElement("h4");
      sub.textContent = "Loop Timeline";
      block2.appendChild(sub);
      for (const loop of loops.slice(0, 4)) {
        const card = doc.createElement("div");
        card.className = "execution-loop-card";
        card.appendChild(line$9(doc, `${loop.id} · ${loop.status}`, toneFor(loop.status)));
        card.appendChild(line$9(doc, `workflow ${loop.workflowId ?? "standalone"} · plan ${loop.planId} · ${loop.taskIds.length} task(s)`));
        const steps = doc.createElement("div");
        steps.className = "execution-loop-steps";
        const ordered = [...loop.history].sort((a, b) => a.at.localeCompare(b.at));
        const seen = /* @__PURE__ */ new Set();
        for (const entry of ordered) {
          if (seen.has(entry.status)) continue;
          seen.add(entry.status);
          const step = doc.createElement("span");
          step.className = `execution-loop-step ${toneFor(entry.status)}`;
          step.textContent = entry.status;
          step.title = `${entry.at} · ${entry.detail}`;
          steps.appendChild(step);
        }
        card.appendChild(steps);
        if (loop.proposalId) card.appendChild(line$9(doc, `proposal ${loop.proposalId}`));
        if (loop.resultId) card.appendChild(line$9(doc, `result ${loop.resultId}`));
        if (loop.rollback?.count != null) card.appendChild(line$9(doc, `rollback restored ${String(loop.rollback.count)} file(s)`));
        if (loop.memoryProposalId) card.appendChild(line$9(doc, `learning memory proposal queued`, "pending"));
        block2.appendChild(card);
      }
      root.appendChild(block2);
    }
    if (quality) {
      const block2 = doc.createElement("div");
      block2.className = "execution-loop-block";
      const sub = doc.createElement("h4");
      sub.textContent = "Quality Gate 8.0";
      block2.appendChild(sub);
      const report = doc.createElement("div");
      report.className = "execution-loop-quality";
      report.appendChild(
        line$9(
          doc,
          `Quality ${quality.quality}/100 · ${quality.executionReady ? "execution ready" : "execution blocked"}`,
          quality.executionReady ? "pass" : "warning"
        )
      );
      report.appendChild(line$9(doc, `confidence ${quality.confidence}/100 · risk ${quality.riskLevel.toUpperCase()}`));
      if (quality.blockingIssues.length) {
        report.appendChild(line$9(doc, `blocking: ${quality.blockingIssues.join(", ")}`, "warning"));
      } else {
        report.appendChild(line$9(doc, "no blocking issues"));
      }
      const testLabel = quality.testResult === "not_run" ? "not run" : quality.testResult ?? "not run";
      report.appendChild(line$9(doc, `rollback ${quality.rollbackCapability ? "ready" : "unavailable"} · tests ${testLabel}`));
      report.appendChild(line$9(doc, `recommendation: ${quality.recommendation}`));
      block2.appendChild(report);
      root.appendChild(block2);
    }
    if (phase17.dags?.length || phase17.metrics || phase17.context) {
      const orchestration = doc.createElement("div");
      orchestration.className = "execution-loop-block execution-orchestration-block";
      const title2 = doc.createElement("h4");
      title2.textContent = "Execution Orchestration · Phase 17";
      orchestration.appendChild(title2);
      const dags = phase17.dags ?? [];
      if (dags.length) {
        const dag = dags[0];
        orchestration.appendChild(line$9(doc, `${dags.length} execution DAG(s) · ${dag.id} · ${dag.status}`, dag.status === "COMPLETED" ? "pass" : ""));
        orchestration.appendChild(line$9(doc, `${dag.loopIds.length} loop(s) · ${dag.edges.length} dependency edge(s)`));
        for (const edge of dag.edges.slice(0, 6)) {
          orchestration.appendChild(line$9(doc, `${edge.sourceLoop} → ${edge.targetLoop} · ${edge.dependencyType}`));
        }
        if (phase17.dagReady) {
          const ready = phase17.dagReady.readyLoops;
          orchestration.appendChild(line$9(doc, ready.length ? `ready: ${ready.join(", ")}` : "ready: none; dependencies pending", ready.length ? "pending" : "warning"));
        }
      } else {
        orchestration.appendChild(line$9(doc, "No execution DAGs recorded yet"));
      }
      if (phase17.metrics) {
        const metrics = phase17.metrics;
        orchestration.appendChild(line$9(doc, `Engineering metrics · ${metrics.totalLoops} loops · success ${metrics.successRate}% · rollback ${metrics.rollbackRate}%`));
        orchestration.appendChild(line$9(doc, `quality ${metrics.averageQuality}/100 · duration ${metrics.averageDurationMs}ms · recovered ${metrics.recovered}`));
        orchestration.appendChild(line$9(doc, `risk low ${metrics.riskDistribution.low ?? 0} · medium ${metrics.riskDistribution.medium ?? 0} · high ${metrics.riskDistribution.high ?? 0}`));
      }
      const context = phase17.context;
      if (context) {
        const incoming = context.dagRelations.incoming.length;
        const outgoing = context.dagRelations.outgoing.length;
        orchestration.appendChild(line$9(doc, `cross-loop context · ${context.relatedLoops.length} related · ${incoming} incoming · ${outgoing} outgoing`));
        const evidence = context.verification?.evidence;
        if (evidence && typeof evidence === "object") {
          const bundle = evidence;
          const testResult = typeof bundle.testResult === "string" ? bundle.testResult : "not_run";
          const qualityScore = typeof bundle.qualityScore === "number" ? bundle.qualityScore : "n/a";
          const riskScore = typeof bundle.riskScore === "number" ? bundle.riskScore : "n/a";
          orchestration.appendChild(line$9(doc, `evidence bundle · tests ${testResult} · quality ${qualityScore} · risk ${riskScore}`));
        } else {
          orchestration.appendChild(line$9(doc, "evidence bundle · not available yet"));
        }
        if (context.loop.status === "RECOVERED") {
          orchestration.appendChild(line$9(doc, "runtime recovered · explicit human confirmation required", "warning"));
        }
      }
      root.appendChild(orchestration);
    }
    return root;
  }
  function renderExecutionLoopTimeline(doc, loopId, timeline) {
    const root = doc.createElement("div");
    root.className = "execution-loop-block";
    root.dataset.role = "execution-loop-timeline";
    const sub = doc.createElement("h4");
    sub.textContent = `Timeline · ${loopId}`;
    root.appendChild(sub);
    if (!timeline.length) {
      root.appendChild(line$9(doc, "No timeline events yet"));
      return root;
    }
    const ordered = [...timeline].sort((a, b) => a.at.localeCompare(b.at));
    for (const entry of ordered.slice(-8)) {
      const row2 = doc.createElement("div");
      row2.className = "execution-loop-step-row";
      row2.appendChild(line$9(doc, `${entry.at} · ${entry.status}`, toneFor(entry.status)));
      if (entry.detail) row2.appendChild(line$9(doc, entry.detail));
      root.appendChild(row2);
    }
    return root;
  }
  function line$8(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `engineering-graph-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function renderEngineeringGraphDashboard(doc, data) {
    const root = doc.createElement("section");
    root.className = "engineering-graph-dashboard";
    root.dataset.role = "engineering-graph-dashboard";
    const heading = doc.createElement("div");
    heading.className = "engineering-graph-heading";
    const title = doc.createElement("strong");
    title.textContent = "Engineering Intelligence Graph";
    const badge = doc.createElement("span");
    badge.className = "engineering-graph-badge";
    badge.textContent = "READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    const graph = data.graph;
    if (!graph && !data.failures.length && !data.timeline.length && !data.capabilities.length) {
      root.appendChild(line$8(doc, "No engineering intelligence recorded yet"));
      return root;
    }
    root.appendChild(line$8(doc, `${graph?.nodes.length ?? 0} graph nodes · ${graph?.edges.length ?? 0} relations · ${data.failures.length} failure patterns`));
    const blocks = doc.createElement("div");
    blocks.className = "engineering-graph-blocks";
    const graphBlock = doc.createElement("div");
    graphBlock.className = "engineering-graph-block";
    const graphTitle = doc.createElement("h4");
    graphTitle.textContent = "Knowledge Graph";
    graphBlock.appendChild(graphTitle);
    for (const node of (graph?.nodes ?? []).slice(0, 8)) graphBlock.appendChild(line$8(doc, `${node.type} · ${node.label}`));
    for (const edge of (graph?.edges ?? []).slice(0, 8)) graphBlock.appendChild(line$8(doc, `${edge.source} → ${edge.target} · ${edge.relation}`));
    if (!graph?.nodes.length) graphBlock.appendChild(line$8(doc, "Graph index pending approval", "warning"));
    blocks.appendChild(graphBlock);
    const failureBlock = doc.createElement("div");
    failureBlock.className = "engineering-graph-block";
    const failureTitle = doc.createElement("h4");
    failureTitle.textContent = "Failure Intelligence";
    failureBlock.appendChild(failureTitle);
    for (const pattern of data.failures.slice(0, 6)) failureBlock.appendChild(line$8(doc, `${pattern.category} · ${pattern.signature} · ${pattern.occurrences} occurrence(s)`, pattern.severity === "high" ? "warning" : ""));
    if (!data.failures.length) failureBlock.appendChild(line$8(doc, "No failure pattern detected"));
    blocks.appendChild(failureBlock);
    const metricBlock = doc.createElement("div");
    metricBlock.className = "engineering-graph-block";
    const metricTitle = doc.createElement("h4");
    metricTitle.textContent = "Agent Capability Metrics";
    metricBlock.appendChild(metricTitle);
    for (const metric of data.capabilities.slice(0, 6)) metricBlock.appendChild(line$8(doc, `${metric.agentId} · success ${metric.successRate}% · review ${metric.reviewScore}/100 · rollback ${metric.rollbackRate}%`));
    if (!data.capabilities.length) metricBlock.appendChild(line$8(doc, "No agent metrics recorded yet"));
    blocks.appendChild(metricBlock);
    const timelineBlock = doc.createElement("div");
    timelineBlock.className = "engineering-graph-block";
    const timelineTitle = doc.createElement("h4");
    timelineTitle.textContent = "Engineering Timeline";
    timelineBlock.appendChild(timelineTitle);
    for (const entry of data.timeline.slice(0, 6)) timelineBlock.appendChild(line$8(doc, `${entry.kind} · ${entry.title}`));
    if (!data.timeline.length) timelineBlock.appendChild(line$8(doc, "No evolution events recorded yet"));
    blocks.appendChild(timelineBlock);
    root.appendChild(blocks);
    return root;
  }
  function line$7(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `benchmark-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function renderBenchmarkDashboard(doc, data) {
    const root = doc.createElement("section");
    root.className = "benchmark-dashboard";
    root.dataset.role = "benchmark-dashboard";
    const heading = doc.createElement("div");
    heading.className = "benchmark-heading";
    const title = doc.createElement("strong");
    title.textContent = "Benchmark Dashboard";
    const badge = doc.createElement("span");
    badge.className = "benchmark-badge";
    badge.textContent = "READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    const results = data.results;
    if (!data.benchmarks.length && !results.length && !data.capabilities.length) {
      root.appendChild(line$7(doc, "No benchmark data recorded yet"));
      return root;
    }
    const completed = results.length;
    const success = results.filter((result) => result.success).length;
    const successRate = completed ? Math.round(success / completed * 100) : 0;
    const avgQuality = completed ? Math.round(results.reduce((sum, result) => sum + result.qualityScore, 0) / completed) : 0;
    const rollbackCount = results.filter((result) => result.rollbackTriggered).length;
    const rollbackRate = completed ? Math.round(rollbackCount / completed * 100) : 0;
    root.appendChild(line$7(doc, `${data.benchmarks.length} benchmark(s) · ${completed} result(s) · success ${successRate}% · quality ${avgQuality}/100 · rollback ${rollbackRate}%`, completed ? "pass" : ""));
    const blocks = doc.createElement("div");
    blocks.className = "benchmark-blocks";
    const summary = doc.createElement("div");
    summary.className = "benchmark-block";
    const summaryTitle = doc.createElement("h4");
    summaryTitle.textContent = "Overview";
    summary.appendChild(summaryTitle);
    for (const record of data.benchmarks.slice(0, 5)) summary.appendChild(line$7(doc, `${record.id} · ${record.project} · ${record.status}`));
    if (!data.benchmarks.length) summary.appendChild(line$7(doc, "No benchmark projects recorded"));
    blocks.appendChild(summary);
    const agentBlock = doc.createElement("div");
    agentBlock.className = "benchmark-block";
    const agentTitle = doc.createElement("h4");
    agentTitle.textContent = "Agent Performance";
    agentBlock.appendChild(agentTitle);
    for (const metric of data.capabilities.slice(0, 5)) agentBlock.appendChild(line$7(doc, `${metric.agentId} · success ${metric.successRate}% · quality ${metric.averageQuality} · rollback ${metric.rollbackRate}%`));
    if (!data.capabilities.length) agentBlock.appendChild(line$7(doc, "No agent capability data recorded"));
    blocks.appendChild(agentBlock);
    const failureBlock = doc.createElement("div");
    failureBlock.className = "benchmark-block";
    const failureTitle = doc.createElement("h4");
    failureTitle.textContent = "Failure Patterns";
    failureBlock.appendChild(failureTitle);
    for (const pattern of data.failurePatterns.slice(0, 5)) failureBlock.appendChild(line$7(doc, `${pattern.category} · ${pattern.occurrences} occurrence(s)`, pattern.severity === "high" ? "warning" : ""));
    if (!data.failurePatterns.length) failureBlock.appendChild(line$7(doc, "No failure pattern detected"));
    blocks.appendChild(failureBlock);
    const resultBlock = doc.createElement("div");
    resultBlock.className = "benchmark-block";
    const resultTitle = doc.createElement("h4");
    resultTitle.textContent = "Results";
    resultBlock.appendChild(resultTitle);
    for (const result of results.slice(0, 5)) resultBlock.appendChild(line$7(doc, `${result.id} · ${result.success ? "pass" : "fail"} · quality ${result.qualityScore} · rollback ${result.rollbackTriggered ? "yes" : "no"}`));
    if (!results.length) resultBlock.appendChild(line$7(doc, "No results recorded yet"));
    blocks.appendChild(resultBlock);
    root.appendChild(blocks);
    return root;
  }
  function line$6(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `demo-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function renderDemoDashboard(doc, data) {
    const root = doc.createElement("section");
    root.className = "demo-dashboard";
    root.dataset.role = "demo-dashboard";
    const heading = doc.createElement("div");
    heading.className = "demo-heading";
    const title = doc.createElement("strong");
    title.textContent = "Engineering Demo";
    const badge = doc.createElement("span");
    badge.className = "demo-badge";
    badge.textContent = "READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    if (!data.scenarios.length && !data.replays.length && !data.artifacts.length) {
      root.appendChild(line$6(doc, "No demo artifacts recorded yet"));
      return root;
    }
    root.appendChild(line$6(doc, data.flow.length ? data.flow.join(" → ") : "Issue → Analysis → Proposal → Approval → Execution → Verification → Report"));
    const blocks = doc.createElement("div");
    blocks.className = "demo-blocks";
    const scenarioBlock = doc.createElement("div");
    scenarioBlock.className = "demo-block";
    const scenarioTitle = doc.createElement("h4");
    scenarioTitle.textContent = "Demo Scenarios";
    scenarioBlock.appendChild(scenarioTitle);
    for (const scenario of data.scenarios.slice(0, 5)) scenarioBlock.appendChild(line$6(doc, `${scenario.name} · ${scenario.issue}`));
    if (!data.scenarios.length) scenarioBlock.appendChild(line$6(doc, "No demo scenarios recorded"));
    blocks.appendChild(scenarioBlock);
    const replayBlock = doc.createElement("div");
    replayBlock.className = "demo-block";
    const replayTitle = doc.createElement("h4");
    replayTitle.textContent = "Engineering Replays";
    replayBlock.appendChild(replayTitle);
    for (const replay of data.replays.slice(0, 5)) replayBlock.appendChild(line$6(doc, `${replay.id} · ${replay.title} · ${replay.steps.length} step(s)`));
    if (!data.replays.length) replayBlock.appendChild(line$6(doc, "No replays recorded yet"));
    blocks.appendChild(replayBlock);
    const artifactBlock = doc.createElement("div");
    artifactBlock.className = "demo-block";
    const artifactTitle = doc.createElement("h4");
    artifactTitle.textContent = "Artifacts";
    artifactBlock.appendChild(artifactTitle);
    for (const artifact of data.artifacts.slice(0, 5)) artifactBlock.appendChild(line$6(doc, `${artifact.kind} · ${artifact.project}`));
    if (!data.artifacts.length) artifactBlock.appendChild(line$6(doc, "No artifacts exported yet"));
    blocks.appendChild(artifactBlock);
    root.appendChild(blocks);
    return root;
  }
  function line$5(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `governance-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function block$3(doc, title) {
    const wrapper = doc.createElement("div");
    wrapper.className = "governance-block";
    const heading = doc.createElement("h4");
    heading.textContent = title;
    wrapper.appendChild(heading);
    return wrapper;
  }
  function score(doc, className, value) {
    const node = doc.createElement("div");
    node.className = className;
    node.textContent = value;
    return node;
  }
  function renderGovernanceDashboard(doc, data) {
    const root = doc.createElement("section");
    root.className = "governance-dashboard";
    root.dataset.role = "governance-dashboard";
    const heading = doc.createElement("div");
    heading.className = "governance-heading";
    const title = doc.createElement("strong");
    title.textContent = "Engineering Governance";
    const badge = doc.createElement("span");
    badge.className = "governance-badge";
    badge.textContent = "READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    const { health, drift, debt, policies, quality9, timeline } = data;
    if (!health && !drift && !debt && !policies && !quality9) {
      root.appendChild(line$5(doc, "No governance data yet. Connect to a Local Bridge with Phase 21."));
      return root;
    }
    if (health) {
      const healthBlock = block$3(doc, "Engineering Health");
      const stats = doc.createElement("div");
      stats.className = "governance-stats";
      const scoreNode = score(doc, "governance-score", `${health.healthScore}/100`);
      const riskNode = score(doc, "governance-score", health.riskLevel.toUpperCase());
      stats.append(scoreNode, riskNode);
      healthBlock.appendChild(stats);
      for (const trend of health.trends.slice(0, 4)) {
        const arrow = trend.direction === "improving" ? "▲" : trend.direction === "declining" ? "▼" : "■";
        healthBlock.appendChild(line$5(doc, `${arrow} ${trend.dimension} ${trend.delta > 0 ? "+" : ""}${trend.delta}`));
      }
      for (const warning of health.warnings.slice(0, 4)) {
        healthBlock.appendChild(line$5(doc, `⚠ ${warning.message}`, "warning"));
      }
      for (const rec of health.recommendations.slice(0, 3)) {
        healthBlock.appendChild(line$5(doc, `→ ${rec.suggestion}`));
      }
      root.appendChild(healthBlock);
    }
    if (drift) {
      const driftBlock = block$3(doc, "Architecture Drift");
      driftBlock.appendChild(line$5(doc, `Drift ${drift.driftScore}/100 · ${drift.riskLevel.toUpperCase()} risk`, drift.driftScore >= 50 ? "warning" : ""));
      for (const issue of drift.issues.slice(0, 4)) {
        driftBlock.appendChild(line$5(doc, `${issue.type} · ${issue.severity} · ${issue.location}`, issue.severity === "high" ? "warning" : ""));
      }
      if (!drift.issues.length) driftBlock.appendChild(line$5(doc, "No drift issues detected"));
      root.appendChild(driftBlock);
    }
    if (debt) {
      const debtBlock = block$3(doc, "Technical Debt");
      for (const item2 of debt.debt.slice(0, 4)) {
        debtBlock.appendChild(line$5(doc, `${item2.category} · ${item2.severity} · ${item2.status} · est ${item2.estimatedCost}h · ${item2.source}`));
      }
      if (!debt.debt.length) debtBlock.appendChild(line$5(doc, "No open debt items"));
      root.appendChild(debtBlock);
    }
    if (policies) {
      const policyBlock = block$3(doc, "Engineering Policies");
      policyBlock.appendChild(line$5(doc, policies.policies.join(" · ") || "No policies registered"));
      for (const event of policies.events.slice(0, 3)) {
        const tone = event.result === "approval_required" ? "warning" : event.result === "warning" ? "pending" : "pass";
        policyBlock.appendChild(line$5(doc, `${event.policy} → ${event.result}`, tone));
      }
      root.appendChild(policyBlock);
    }
    if (quality9) {
      const qualityBlock = block$3(doc, "Quality Gate 9.0");
      qualityBlock.appendChild(line$5(doc, `Quality ${quality9.quality}/100 · health ${quality9.healthScore} · debt ${quality9.debtScore} · ${quality9.policyViolations} policy violation(s)`));
      for (const issue of quality9.blockingIssues.slice(0, 3)) qualityBlock.appendChild(line$5(doc, `blocked: ${issue}`, "warning"));
      if (!quality9.blockingIssues.length) qualityBlock.appendChild(line$5(doc, "No blocking issues", "pass"));
      root.appendChild(qualityBlock);
    }
    if (timeline) {
      const memoryBlock = block$3(doc, "Governance Timeline");
      for (const record of timeline.memory.slice(0, 4)) {
        memoryBlock.appendChild(line$5(doc, `${record.category} · ${record.document}`));
      }
      if (!timeline.memory.length) memoryBlock.appendChild(line$5(doc, "No governance memory yet"));
      root.appendChild(memoryBlock);
    }
    return root;
  }
  function line$4(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `organization-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function block$2(doc, title) {
    const wrapper = doc.createElement("div");
    wrapper.className = "organization-block";
    const heading = doc.createElement("h4");
    heading.textContent = title;
    wrapper.appendChild(heading);
    return wrapper;
  }
  function renderOrganizationDashboard(doc, data) {
    const root = doc.createElement("section");
    root.className = "organization-dashboard";
    root.dataset.role = "organization-dashboard";
    const heading = doc.createElement("div");
    heading.className = "organization-heading";
    const title = doc.createElement("strong");
    title.textContent = "Engineering Command Center";
    const badge = doc.createElement("span");
    badge.className = "organization-badge";
    badge.textContent = "ORG READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    const { health, dashboard, learning, quality10, impact, risk, strategies, recommendations, context } = data;
    if (!health && !dashboard && !learning && !quality10 && !impact && !risk && !strategies && !recommendations && !context) {
      root.appendChild(line$4(doc, "No organization data yet. Register projects in the org graph to begin."));
      return root;
    }
    if (health) {
      const healthBlock = block$2(doc, "Organization Health");
      const stats = doc.createElement("div");
      stats.className = "organization-stats";
      const scoreNode = doc.createElement("div");
      scoreNode.className = "organization-score";
      scoreNode.textContent = `${health.orgHealthScore}/100`;
      const countNode = doc.createElement("div");
      countNode.className = "organization-score";
      countNode.textContent = `${health.projectCount} project(s)`;
      stats.append(scoreNode, countNode);
      healthBlock.appendChild(stats);
      for (const item2 of health.healthByProject.slice(0, 5)) {
        healthBlock.appendChild(line$4(doc, `${item2.project} · ${item2.healthScore}/100 · ${item2.riskLevel}`, item2.riskLevel === "high" ? "warning" : item2.riskLevel === "medium" ? "pending" : ""));
      }
      for (const trend of health.riskTrends.slice(0, 3)) {
        const arrow = trend.direction === "improving" ? "▲" : trend.direction === "declining" ? "▼" : "■";
        healthBlock.appendChild(line$4(doc, `${arrow} ${trend.project} ${trend.delta > 0 ? "+" : ""}${trend.delta}`, trend.direction === "declining" ? "warning" : ""));
      }
      for (const warning of health.warnings.slice(0, 3)) {
        healthBlock.appendChild(line$4(doc, `⚠ ${warning.message}`, "warning"));
      }
      root.appendChild(healthBlock);
    }
    if (health && health.debtRanking.length) {
      const debtBlock = block$2(doc, "Technical Debt Ranking");
      for (const item2 of health.debtRanking.slice(0, 5)) {
        debtBlock.appendChild(line$4(doc, `${item2.project} · ${item2.openDebt} open · est ${item2.estimatedCost}h`));
      }
      root.appendChild(debtBlock);
    }
    if (dashboard?.graph) {
      const graphBlock = block$2(doc, "Organization Graph");
      const company = dashboard.graph.company ? `${dashboard.graph.company.name}` : "No company registered";
      graphBlock.appendChild(line$4(doc, `${company} · ${dashboard.graph.teams.length} team(s) · ${dashboard.graph.projects.length} project(s)`));
      for (const team of dashboard.graph.teams.slice(0, 3)) {
        const projects = dashboard.graph.projects.filter((project) => project.parentId === team.id);
        graphBlock.appendChild(line$4(doc, `${team.name}: ${projects.map((project) => project.name).join(", ") || "no projects"}`));
      }
      root.appendChild(graphBlock);
    }
    if (health && health.failurePatterns.length) {
      const patternBlock = block$2(doc, "Failure Patterns");
      for (const pattern of health.failurePatterns.slice(0, 4)) {
        patternBlock.appendChild(line$4(doc, `${pattern.project} · ${pattern.category} · ${pattern.signature} ×${pattern.occurrences}`, pattern.severity === "high" ? "warning" : ""));
      }
      root.appendChild(patternBlock);
    }
    if (learning && learning.matches.length) {
      const learningBlock = block$2(doc, "Cross-Project Learning");
      for (const match of learning.matches.slice(0, 4)) {
        learningBlock.appendChild(line$4(doc, `${match.message} (score ${match.matchScore})`, "warning"));
      }
      root.appendChild(learningBlock);
    }
    if (dashboard && dashboard.patterns.length) {
      const libraryBlock = block$2(doc, "Engineering Pattern Library");
      for (const pattern of dashboard.patterns.slice(0, 4)) {
        libraryBlock.appendChild(line$4(doc, `${pattern.category} · ${pattern.name} · ${pattern.project}`));
      }
      root.appendChild(libraryBlock);
    }
    if (dashboard && dashboard.incidents.length) {
      const incidentBlock = block$2(doc, "Incidents");
      for (const incident of dashboard.incidents.slice(0, 3)) {
        incidentBlock.appendChild(line$4(doc, `${incident.status} · ${incident.project} · ${incident.title}`, incident.severity === "high" ? "warning" : ""));
      }
      root.appendChild(incidentBlock);
    }
    if (quality10) {
      const qualityBlock = block$2(doc, "Quality Gate 10.0");
      qualityBlock.appendChild(line$4(doc, `Quality ${quality10.quality}/100 · health ${quality10.orgHealthScore} · ${quality10.openIncidents} incident(s)`));
      for (const issue of quality10.blockingIssues.slice(0, 3)) qualityBlock.appendChild(line$4(doc, `blocked: ${issue}`, "warning"));
      if (!quality10.blockingIssues.length) qualityBlock.appendChild(line$4(doc, "No blocking issues", "pass"));
      root.appendChild(qualityBlock);
    }
    if (impact) {
      const impactBlock = block$2(doc, "Cross-Project Impact");
      const stats = doc.createElement("div");
      stats.className = "organization-stats";
      const scoreNode = doc.createElement("div");
      scoreNode.className = "organization-score";
      scoreNode.textContent = `impact ${impact.impact_score}/100`;
      const levelNode = doc.createElement("div");
      levelNode.className = "organization-score";
      levelNode.textContent = `risk ${impact.risk_level} · confidence ${impact.confidence}`;
      stats.append(scoreNode, levelNode);
      impactBlock.appendChild(stats);
      impactBlock.appendChild(line$4(doc, `source: ${impact.source_node} · projects: ${impact.affected_projects.join(", ") || "none"}`));
      impactBlock.appendChild(line$4(doc, `teams: ${impact.affected_teams.join(", ") || "none"} · services: ${impact.affected_services.join(", ") || "none"}`));
      for (const path of impact.dependency_paths.slice(0, 3)) {
        impactBlock.appendChild(line$4(doc, `path: ${path.join(" → ")}`));
      }
      for (const issue of impact.blocking_issues.slice(0, 3)) {
        impactBlock.appendChild(line$4(doc, `⚠ ${issue}`, "warning"));
      }
      root.appendChild(impactBlock);
    }
    if (risk) {
      const riskBlock = block$2(doc, "Risk Propagation");
      riskBlock.appendChild(line$4(doc, `${risk.source} · ${risk.severity}/${risk.likelihood} · impact ${risk.impact} · confidence ${risk.confidence}`, risk.severity === "high" ? "warning" : risk.severity === "medium" ? "pending" : ""));
      for (const entry of risk.propagation_path.slice(0, 3)) {
        riskBlock.appendChild(line$4(doc, `${entry.node} via ${entry.via} (${entry.severity})`));
      }
      for (const node of risk.affected_nodes.slice(0, 4)) {
        riskBlock.appendChild(line$4(doc, `affects ${node.name} (${node.type}) · ${node.severity}`, node.severity === "high" ? "warning" : ""));
      }
      for (const recommendation of risk.recommendations.slice(0, 2)) {
        riskBlock.appendChild(line$4(doc, `→ ${recommendation}`));
      }
      root.appendChild(riskBlock);
    }
    if (strategies && strategies.strategies.length) {
      const strategyBlock = block$2(doc, "Active Strategies");
      for (const strategy of strategies.strategies.slice(0, 5)) {
        strategyBlock.appendChild(line$4(doc, `${strategy.strategy_type} · ${strategy.title} · ${strategy.status} · confidence ${strategy.confidence}`, strategy.status === "SELECTED" ? "pass" : strategy.priority === "high" ? "pending" : ""));
      }
      root.appendChild(strategyBlock);
    }
    if (context && context.pending_decisions.length) {
      const decisionBlock = block$2(doc, "Pending Decisions");
      for (const decision of context.pending_decisions.slice(0, 4)) {
        decisionBlock.appendChild(line$4(doc, `${decision.status} · ${decision.title} · confidence ${decision.confidence}`, "pending"));
      }
      root.appendChild(decisionBlock);
    }
    if (recommendations && recommendations.recommendations.length) {
      const recommendationBlock = block$2(doc, "Strategic Recommendations");
      for (const recommendation of recommendations.recommendations.slice(0, 4)) {
        recommendationBlock.appendChild(line$4(doc, `${recommendation.problem} — ${recommendation.recommendation} (confidence ${recommendation.confidence})`));
        recommendationBlock.appendChild(line$4(doc, `  benefit: ${recommendation.expected_benefit} · risk: ${recommendation.risk}`));
      }
      root.appendChild(recommendationBlock);
    }
    return root;
  }
  function line$3(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `developer-context-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function summaryRow(doc, label2, value, tone = "") {
    const row2 = doc.createElement("div");
    row2.className = "developer-context-summary-row";
    const key = doc.createElement("span");
    key.className = "developer-context-summary-key";
    key.textContent = label2;
    const val = doc.createElement("span");
    val.className = "developer-context-summary-value";
    val.textContent = value;
    row2.append(key, val);
    if (tone) row2.dataset.tone = tone;
    return row2;
  }
  function renderContextDashboard(doc, devContext, selection, onToggle) {
    const root = doc.createElement("section");
    root.className = "developer-context-dashboard";
    root.dataset.role = "developer-context-dashboard";
    const heading = doc.createElement("div");
    heading.className = "developer-context-heading";
    const title = doc.createElement("strong");
    title.textContent = "Developer Context";
    const badge = doc.createElement("span");
    badge.className = "developer-context-badge";
    badge.textContent = "READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    if (!devContext) {
      root.appendChild(line$3(doc, "No developer context loaded. Select a project and refresh."));
      return root;
    }
    const meta = doc.createElement("div");
    meta.className = "developer-context-meta";
    meta.append(
      summaryRow(doc, "Project", devContext.project),
      summaryRow(doc, "Agent", devContext.agent),
      summaryRow(doc, "Size", `${(devContext.size / 1024).toFixed(1)} KB`),
      summaryRow(doc, "Truncated", devContext.truncated ? "yes" : "no", devContext.truncated ? "warn" : ""),
      summaryRow(doc, "Security filtering", devContext.securityFiltering ? "active" : "off", "ok")
    );
    root.appendChild(meta);
    const preview = doc.createElement("div");
    preview.className = "developer-context-preview";
    const previewTitle = doc.createElement("h4");
    previewTitle.textContent = "Context Preview (user sends)";
    preview.appendChild(previewTitle);
    const note = doc.createElement("div");
    note.className = "developer-context-note";
    note.textContent = "Nothing is sent automatically. Select items below to attach them to your next message; remove any item before sending. Tool proposals still require human approval.";
    preview.appendChild(note);
    const project = devContext.projectContext;
    const sections = [
      {
        id: "project",
        label: "Project context",
        detail: project ? `${project.fileCount} files · ${Object.keys(project.languages).join(", ") || "no languages"} · ${project.packageManagers.join(", ") || "no package managers"}` : "unavailable"
      },
      {
        id: "files",
        label: "Files",
        detail: devContext.files ? `${devContext.files.length} file(s)` : "unavailable"
      },
      {
        id: "symbols",
        label: "Symbols",
        detail: devContext.symbols ? `${devContext.symbols.total} symbol(s)` : "unavailable"
      },
      {
        id: "dependencies",
        label: "Dependencies",
        detail: devContext.dependencies ? `${devContext.dependencies.total} dependency(ies)` : "unavailable"
      },
      {
        id: "git",
        label: "Git",
        detail: devContext.git ? `branch ${devContext.git.branch} · ${devContext.git.clean ? "clean" : `${devContext.git.changedFiles.length} changed`} · ${devContext.git.commits.length} commit(s)` : "unavailable"
      },
      {
        id: "tests",
        label: "Tests / build",
        detail: devContext.tests ? `test ${devContext.tests.testStatus?.status ?? "unknown"} · build ${devContext.tests.buildStatus?.status ?? "unknown"}` : "unavailable"
      }
    ];
    for (const section of sections) {
      const row2 = doc.createElement("div");
      row2.className = "developer-context-preview-row";
      const toggle = doc.createElement("input");
      toggle.type = "checkbox";
      toggle.dataset.role = "context-select";
      toggle.dataset.contextId = section.id;
      toggle.checked = selection.includes(section.id);
      toggle.addEventListener("change", () => onToggle(section.id));
      const label2 = doc.createElement("span");
      label2.className = "developer-context-preview-label";
      label2.textContent = section.label;
      const detail = doc.createElement("span");
      detail.className = "developer-context-preview-detail";
      detail.textContent = section.detail;
      row2.append(toggle, label2, detail);
      preview.appendChild(row2);
    }
    const selected = doc.createElement("div");
    selected.className = "developer-context-selected";
    selected.textContent = selection.length ? `${selection.length} context item(s) ready to attach: ${selection.join(", ")}` : "No context items selected";
    preview.appendChild(selected);
    root.appendChild(preview);
    const blocks = doc.createElement("div");
    blocks.className = "developer-context-blocks";
    if (project) {
      const block2 = doc.createElement("div");
      block2.className = "developer-context-block";
      const blockTitle = doc.createElement("h4");
      blockTitle.textContent = "Project";
      block2.appendChild(blockTitle);
      block2.append(
        line$3(doc, `Workspace: ${project.workspaceRoot}`),
        line$3(doc, `Languages: ${Object.entries(project.languages).map(([lang, count]) => `${lang} (${count})`).join(", ") || "none"}`),
        line$3(doc, `Files: ${project.fileCount}`),
        line$3(doc, `Package managers: ${project.packageManagers.join(", ") || "none"}`),
        line$3(doc, `Test: ${project.testStatus?.status ?? "unknown"} · Build: ${project.buildStatus?.status ?? "unknown"}`)
      );
      blocks.appendChild(block2);
    }
    if (devContext.git) {
      const block2 = doc.createElement("div");
      block2.className = "developer-context-block";
      const blockTitle = doc.createElement("h4");
      blockTitle.textContent = "Git (read-only)";
      block2.appendChild(blockTitle);
      block2.append(
        line$3(doc, `Branch: ${devContext.git.branch}`),
        line$3(doc, `State: ${devContext.git.clean ? "clean" : "dirty"}`),
        line$3(doc, `Changed: ${devContext.git.changedFiles.slice(0, 5).join(", ") || "none"}${devContext.git.changedFiles.length > 5 ? " …" : ""}`),
        line$3(doc, `Diff: ${devContext.git.diffTruncated ? `${devContext.git.diff.length} chars (truncated)` : `${devContext.git.diff.length} chars`}`)
      );
      blocks.appendChild(block2);
    }
    if (devContext.symbols && devContext.symbols.symbols.length) {
      const block2 = doc.createElement("div");
      block2.className = "developer-context-block";
      const blockTitle = doc.createElement("h4");
      blockTitle.textContent = "Symbols";
      block2.appendChild(blockTitle);
      for (const symbol of devContext.symbols.symbols.slice(0, 6)) {
        block2.append(line$3(doc, `${symbol.type} ${symbol.name}${symbol.exported ? " (exported)" : ""} — ${symbol.file}:${symbol.line}`));
      }
      if (devContext.symbols.symbols.length > 6) block2.append(line$3(doc, `… ${devContext.symbols.symbols.length - 6} more`));
      blocks.appendChild(block2);
    }
    if (devContext.dependencies && devContext.dependencies.dependencies.length) {
      const block2 = doc.createElement("div");
      block2.className = "developer-context-block";
      const blockTitle = doc.createElement("h4");
      blockTitle.textContent = "Dependencies";
      block2.appendChild(blockTitle);
      for (const dep of devContext.dependencies.dependencies.slice(0, 6)) {
        block2.append(line$3(doc, `${dep.name}@${dep.version} (${dep.type}) — ${dep.sourceFile}`));
      }
      if (devContext.dependencies.dependencies.length > 6) block2.append(line$3(doc, `… ${devContext.dependencies.dependencies.length - 6} more`));
      blocks.appendChild(block2);
    }
    if (devContext.tests) {
      const block2 = doc.createElement("div");
      block2.className = "developer-context-block";
      const blockTitle = doc.createElement("h4");
      blockTitle.textContent = "Tests / build (read-only)";
      block2.appendChild(blockTitle);
      block2.append(
        line$3(doc, `Last test result: ${devContext.tests.testStatus?.status ?? "not recorded"}`),
        line$3(doc, `Build status: ${devContext.tests.buildStatus?.status ?? "not recorded"}`)
      );
      blocks.appendChild(block2);
    }
    root.appendChild(blocks);
    const footer = doc.createElement("div");
    footer.className = "developer-context-footer";
    footer.textContent = "Read-only context. No execution, apply, fix, auto-approve, or source modification.";
    root.appendChild(footer);
    return root;
  }
  function line$2(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `phase30-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function block$1(doc, title, children) {
    const section = doc.createElement("div");
    section.className = "phase30-block";
    const heading = doc.createElement("h4");
    heading.textContent = title;
    section.appendChild(heading);
    for (const child of children) section.appendChild(child);
    return section;
  }
  function severityTone(severity) {
    switch (severity) {
      case "Critical":
      case "High":
        return "danger";
      case "Medium":
        return "warn";
      case "Low":
      case "Info":
        return "ok";
      default:
        return "";
    }
  }
  function renderIntelligenceDashboard(doc, snapshot) {
    const root = doc.createElement("section");
    root.className = "phase30-dashboard";
    root.dataset.role = "phase30-dashboard";
    const heading = doc.createElement("div");
    heading.className = "phase30-heading";
    const title = doc.createElement("strong");
    title.textContent = "Context Intelligence";
    const badge = doc.createElement("span");
    badge.className = "phase30-badge";
    badge.textContent = "READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    if (!snapshot) {
      root.appendChild(line$2(doc, "No context intelligence loaded. Select a project and refresh."));
      return root;
    }
    const suggested = snapshot.suggested;
    const suggestedChildren = [];
    if (suggested) {
      suggestedChildren.push(line$2(doc, `Query: ${suggested.query || "(no query)"} · ${suggested.items.length} candidate(s)`));
      for (const item2 of suggested.items.slice(0, 8)) {
        const row2 = doc.createElement("div");
        row2.className = "phase30-row";
        const name = doc.createElement("span");
        name.className = "phase30-row-name";
        name.textContent = item2.included ? "✓" : "·";
        const text2 = doc.createElement("span");
        text2.textContent = `${item2.path || item2.name} — score ${item2.score.toFixed(2)}`;
        const reason = doc.createElement("span");
        reason.className = "phase30-reason";
        reason.textContent = item2.reason;
        row2.append(name, text2, reason);
        suggestedChildren.push(row2);
      }
    } else {
      suggestedChildren.push(line$2(doc, "No suggestion data in this snapshot."));
    }
    root.appendChild(block$1(doc, "Suggested Context (why this context?)", suggestedChildren));
    const errorChildren = [];
    if (snapshot.errorBundle) {
      errorChildren.push(line$2(doc, `Error: ${snapshot.errorBundle.error.slice(0, 200)}`, "warn"));
      errorChildren.push(line$2(doc, `Kind: ${snapshot.errorBundle.kind} · sanitized=${String(snapshot.errorBundle.sanitized)} · absPathsRemoved=${String(snapshot.errorBundle.absolutePathsRemoved)}`));
      if (snapshot.errorBundle.relatedFiles.length) errorChildren.push(line$2(doc, `Related files: ${snapshot.errorBundle.relatedFiles.slice(0, 5).join(", ")}`));
    } else {
      errorChildren.push(line$2(doc, "No error analysis in this snapshot."));
    }
    root.appendChild(block$1(doc, "Error Analysis", errorChildren));
    const testChildren = [];
    if (snapshot.testFailure) {
      testChildren.push(line$2(doc, `Test: ${snapshot.testFailure.test.slice(0, 120)}`, "warn"));
      if (snapshot.testFailure.testFile) testChildren.push(line$2(doc, `Test file: ${snapshot.testFailure.testFile}`));
      if (snapshot.testFailure.suggestedInvestigation.length) {
        for (const step of snapshot.testFailure.suggestedInvestigation.slice(0, 4)) testChildren.push(line$2(doc, `• ${step}`));
      }
      testChildren.push(line$2(doc, "Changes only via Patch Proposal → Approval.", "ok"));
    } else {
      testChildren.push(line$2(doc, "No test-failure analysis in this snapshot."));
    }
    root.appendChild(block$1(doc, "Test Failure Intelligence", testChildren));
    const gitChildren = [];
    if (snapshot.gitAnalysis) {
      for (const summary of snapshot.gitAnalysis.changeSummary) gitChildren.push(line$2(doc, summary));
      const risk = snapshot.gitAnalysis.riskIndicators;
      if (risk.length) {
        for (const item2 of risk) gitChildren.push(line$2(doc, `Risk: ${item2.label} (${item2.severity}) ×${item2.matches}`, severityTone(item2.severity)));
      }
      for (const point of snapshot.gitAnalysis.reviewPoints.slice(0, 4)) gitChildren.push(line$2(doc, `• ${point}`));
    } else {
      gitChildren.push(line$2(doc, "No git diff analysis in this snapshot."));
    }
    root.appendChild(block$1(doc, "Git Diff Intelligence", gitChildren));
    const reviewChildren = [];
    if (snapshot.review) {
      reviewChildren.push(line$2(doc, snapshot.review.summary));
      for (const finding of snapshot.review.findings.slice(0, 8)) {
        const row2 = doc.createElement("div");
        row2.className = "phase30-row";
        const sev = doc.createElement("span");
        sev.className = `phase30-severity ${severityTone(finding.severity)}`;
        sev.textContent = finding.severity;
        const text2 = doc.createElement("span");
        text2.textContent = `${finding.title} @ ${finding.location}`;
        row2.append(sev, text2);
        reviewChildren.push(row2);
      }
    } else {
      reviewChildren.push(line$2(doc, "No code review in this snapshot."));
    }
    root.appendChild(block$1(doc, "Code Review (suggestions only)", reviewChildren));
    const injectionChildren = [];
    if (snapshot.injection) {
      const verdict = snapshot.injection.verdict;
      const tone = verdict === "clean" ? "ok" : "warn";
      injectionChildren.push(line$2(doc, `Verdict: ${verdict} — project content is UNTRUSTED data, never instructions.`, tone));
      for (const signal of snapshot.injection.signals.slice(0, 5)) {
        injectionChildren.push(line$2(doc, `• ${signal.pattern} (${signal.severity}): ${signal.snippet.slice(0, 80)}`, severityTone(signal.severity)));
      }
    } else {
      injectionChildren.push(line$2(doc, "No injection scan in this snapshot."));
    }
    root.appendChild(block$1(doc, "Prompt Injection Protection", injectionChildren));
    const budgetChildren = [];
    for (const usage of snapshot.budget) {
      budgetChildren.push(line$2(doc, `${usage.bucket}: ${usage.used} / ${usage.limit} B (${usage.items} item(s), ${usage.remaining} B left)`));
    }
    root.appendChild(block$1(doc, "Context Budget 2.0", budgetChildren));
    const proposalChildren = [];
    if (snapshot.proposals.length) {
      for (const proposal of snapshot.proposals.slice(0, 5)) {
        proposalChildren.push(
          line$2(doc, `${proposal.id.slice(0, 8)} · ${proposal.targetFile} (${proposal.risk}) — ${proposal.reason.slice(0, 100)}`, proposal.risk === "high" ? "warn" : "")
        );
      }
      proposalChildren.push(line$2(doc, "Approved proposal records only — source files are never modified here.", "ok"));
    } else {
      proposalChildren.push(line$2(doc, "No approved patch proposals yet."));
    }
    root.appendChild(block$1(doc, "Patch Proposals (record only)", proposalChildren));
    const footer = doc.createElement("div");
    footer.className = "phase30-footer";
    footer.textContent = "Read-only. No execute, approve, apply, fix, auto-learn or auto-govern.";
    root.appendChild(footer);
    return root;
  }
  function line$1(doc, text2, tone = "") {
    const node = doc.createElement("div");
    node.className = `llm-line ${tone}`.trim();
    node.textContent = text2;
    return node;
  }
  function block(doc, title, children) {
    const section = doc.createElement("div");
    section.className = "llm-block";
    const heading = doc.createElement("h4");
    heading.textContent = title;
    section.appendChild(heading);
    for (const child of children) section.appendChild(child);
    return section;
  }
  function renderLlmGatewayDashboard(doc, snapshot) {
    const root = doc.createElement("section");
    root.className = "llm-dashboard";
    root.dataset.role = "llm-dashboard";
    const heading = doc.createElement("div");
    heading.className = "llm-heading";
    const title = doc.createElement("strong");
    title.textContent = "LLM Gateway";
    const badge = doc.createElement("span");
    badge.className = "llm-badge";
    badge.textContent = "READ ONLY";
    heading.append(title, badge);
    root.appendChild(heading);
    if (!snapshot) {
      root.appendChild(line$1(doc, "No LLM gateway data loaded. Select a project and refresh."));
      return root;
    }
    const providerChildren = [];
    if (snapshot.providers.length) {
      for (const provider of snapshot.providers) {
        const tone = provider.enabled ? "ok" : "";
        providerChildren.push(
          line$1(
            doc,
            `${provider.name} — ${provider.enabled ? "configured" : "not configured"} · ${provider.models.length} model(s)`,
            tone
          )
        );
      }
      providerChildren.push(line$1(doc, "Vendor providers activate only when their API key is set in the environment.", "ok"));
    } else {
      providerChildren.push(line$1(doc, "No providers registered."));
    }
    root.appendChild(block(doc, "Provider Registry", providerChildren));
    const modelChildren = [];
    if (snapshot.models.length) {
      const enabled = snapshot.models.filter((model) => model.enabled);
      const shown = enabled.slice(0, 10);
      for (const model of shown) {
        modelChildren.push(
          line$1(doc, `${model.id} — ${model.provider} · ${model.capabilities.join(", ")}`)
        );
      }
      if (enabled.length > shown.length) {
        modelChildren.push(line$1(doc, `+${enabled.length - shown.length} more enabled model(s)`, "warn"));
      }
      const disabledCount = snapshot.models.length - enabled.length;
      if (disabledCount) {
        modelChildren.push(line$1(doc, `${disabledCount} vendor model(s) disabled until provider keys are configured.`, "warn"));
      }
    } else {
      modelChildren.push(line$1(doc, "No models in the registry."));
    }
    root.appendChild(block(doc, "Model Registry", modelChildren));
    const conversationChildren = [];
    if (snapshot.conversations.length) {
      for (const conversation of snapshot.conversations.slice(0, 6)) {
        const agent = conversation.agent ? ` · agent=${conversation.agent}` : "";
        conversationChildren.push(
          line$1(doc, `${conversation.title.slice(0, 80)} — ${conversation.provider}/${conversation.model}${agent}`)
        );
      }
    } else {
      conversationChildren.push(line$1(doc, "No persisted conversations for this project yet."));
    }
    conversationChildren.push(line$1(doc, "Conversation persistence is approval-gated on the bridge.", "ok"));
    root.appendChild(block(doc, "Conversations (bound to project/agent)", conversationChildren));
    const proposalChildren = [];
    if (snapshot.toolProposals.length) {
      for (const proposal of snapshot.toolProposals.slice(0, 6)) {
        proposalChildren.push(
          line$1(doc, `${proposal.toolName} — ${proposal.status} · ${proposal.reason.slice(0, 80)}`)
        );
      }
      proposalChildren.push(line$1(doc, "Recorded proposals only — tools are never executed by the gateway.", "ok"));
    } else {
      proposalChildren.push(line$1(doc, "No recorded tool-call proposals for this project."));
    }
    root.appendChild(block(doc, "Tool-Call Proposals (record only)", proposalChildren));
    const footer = doc.createElement("div");
    footer.className = "llm-footer";
    footer.textContent = "Read-only. No execute, approve, apply, fix, auto-learn or auto-govern. Chat is stateless; tool calls are proposals only.";
    root.appendChild(footer);
    return root;
  }
  const STATE_LABELS = {
    approving: "Executing via Local Bridge...",
    approved: "Approved and executed",
    rejected: "Rejected by user",
    failed: "Failed"
  };
  function field$1(doc, label2, value, mono = false) {
    const row2 = doc.createElement("div");
    row2.className = "field";
    const strong = doc.createElement("b");
    strong.textContent = `${label2}: `;
    const span = doc.createElement("span");
    if (mono) span.className = "mono";
    span.textContent = value;
    row2.append(strong, span);
    return row2;
  }
  function renderRecoveredApprovalCard(doc, item2, onReconfirm, onApprove = () => {
  }) {
    const card = doc.createElement("div");
    card.className = "card recovered-card";
    card.dataset.requestId = item2.requestId;
    card.dataset.state = item2.status;
    const head = doc.createElement("div");
    head.className = "card-head";
    const title = doc.createElement("span");
    title.className = "card-action";
    title.textContent = `Recovered approval · ${item2.action}`;
    const badge = doc.createElement("span");
    badge.className = "risk medium";
    badge.textContent = "RECONFIRM REQUIRED";
    head.append(title, badge);
    card.appendChild(head);
    card.appendChild(field$1(doc, "Project", item2.project, true));
    card.appendChild(field$1(doc, "Target", item2.path, true));
    card.appendChild(field$1(doc, "Reason", item2.reason));
    if (item2.preview) {
      const preview = doc.createElement("pre");
      preview.className = "preview";
      preview.textContent = item2.preview;
      card.appendChild(preview);
    }
    const button2 = doc.createElement("button");
    button2.className = "btn btn-approve";
    if (item2.status === "reconfirmed") {
      button2.dataset.role = "approve-recovered";
      button2.textContent = "Approve execution";
      button2.addEventListener("click", () => onApprove(item2.requestId));
    } else {
      button2.dataset.role = "reconfirm";
      button2.textContent = "Reconfirm approval";
      button2.addEventListener("click", () => onReconfirm(item2.requestId));
    }
    card.appendChild(button2);
    const note = doc.createElement("div");
    note.className = "state approving";
    note.textContent = item2.status === "reconfirmed" ? "Reconfirmed. Execution still requires this separate explicit approval." : "Recovery never approves or executes automatically.";
    card.appendChild(note);
    return card;
  }
  function renderApprovalCard(doc, item2, handlers) {
    const card = doc.createElement("div");
    card.className = "card";
    card.dataset.actionId = item2.id;
    card.dataset.state = item2.state;
    const head = doc.createElement("div");
    head.className = "card-head";
    const title = doc.createElement("span");
    title.className = "card-action";
    title.textContent = ACTION_LABELS[item2.action.action] ?? item2.action.action;
    const risk = doc.createElement("span");
    risk.className = `risk ${item2.action.risk}`;
    risk.textContent = item2.action.risk;
    head.append(title, risk);
    card.appendChild(head);
    card.appendChild(field$1(doc, "Project", item2.action.target.project, true));
    if (isMemoryAction(item2.action.action)) {
      card.appendChild(
        field$1(doc, "Memory", item2.action.target.document ?? item2.action.target.path, true)
      );
      if (item2.action.action === "memory.decision") {
        card.appendChild(field$1(doc, "ADR Title", item2.action.payload.title ?? ""));
      }
    } else {
      card.appendChild(field$1(doc, "File", item2.action.target.path, true));
    }
    card.appendChild(field$1(doc, "Reason", item2.action.reason));
    if (item2.preview) {
      const preview = doc.createElement("pre");
      preview.className = "preview";
      preview.textContent = item2.preview;
      card.appendChild(preview);
    }
    if (item2.state === "pending") {
      const actions = doc.createElement("div");
      actions.className = "actions";
      const approve = doc.createElement("button");
      approve.className = "btn btn-approve";
      approve.textContent = "Approve";
      approve.dataset.role = "approve";
      approve.addEventListener("click", () => handlers.onApprove(item2.id));
      const reject = doc.createElement("button");
      reject.className = "btn btn-reject";
      reject.textContent = "Reject";
      reject.dataset.role = "reject";
      reject.addEventListener("click", () => handlers.onReject(item2.id));
      actions.append(approve, reject);
      card.appendChild(actions);
    } else {
      const state = doc.createElement("div");
      state.className = `state ${item2.state}`;
      state.textContent = item2.message ?? STATE_LABELS[item2.state] ?? item2.state;
      card.appendChild(state);
    }
    return card;
  }
  const HEADING = /^(#{1,6})\s+(.*)$/;
  const FENCE = /^```([A-Za-z0-9+#._-]*)\s*$/;
  const BULLET = /^[-*+]\s+(.*)$/;
  const ORDERED = /^\d{1,3}[.)]\s+(.*)$/;
  const QUOTE = /^>\s?(.*)$/;
  function parseMarkdown(source) {
    const blocks = [];
    const lines = (source ?? "").replace(/\r\n?/g, "\n").split("\n");
    let index = 0;
    const flushParagraph = (buffer) => {
      if (buffer.length) blocks.push({ kind: "paragraph", level: 0, language: "", lines: [buffer.join(" ")], ordered: false });
      buffer.length = 0;
    };
    const paragraph = [];
    while (index < lines.length) {
      const line2 = lines[index];
      const fence = FENCE.exec(line2.trim());
      if (fence) {
        flushParagraph(paragraph);
        const body = [];
        index += 1;
        while (index < lines.length && !FENCE.test(lines[index].trim())) {
          body.push(lines[index]);
          index += 1;
        }
        index += 1;
        blocks.push({ kind: "code", level: 0, language: fence[1] ?? "", lines: body, ordered: false });
        continue;
      }
      const heading = HEADING.exec(line2);
      if (heading) {
        flushParagraph(paragraph);
        blocks.push({ kind: "heading", level: heading[1].length, language: "", lines: [heading[2].trim()], ordered: false });
        index += 1;
        continue;
      }
      const quote = QUOTE.exec(line2);
      if (quote) {
        flushParagraph(paragraph);
        const body = [quote[1]];
        index += 1;
        while (index < lines.length && QUOTE.test(lines[index])) {
          body.push(QUOTE.exec(lines[index])[1]);
          index += 1;
        }
        blocks.push({ kind: "quote", level: 0, language: "", lines: [body.join(" ")], ordered: false });
        continue;
      }
      const bullet = BULLET.exec(line2);
      const ordered = ORDERED.exec(line2);
      if (bullet || ordered) {
        flushParagraph(paragraph);
        const isOrdered = Boolean(ordered);
        const items = [(bullet ?? ordered)[1]];
        index += 1;
        while (index < lines.length) {
          const next = isOrdered ? ORDERED.exec(lines[index]) : BULLET.exec(lines[index]);
          if (!next) break;
          items.push(next[1]);
          index += 1;
        }
        blocks.push({ kind: "list", level: 0, language: "", lines: items, ordered: isOrdered });
        continue;
      }
      if (!line2.trim()) {
        flushParagraph(paragraph);
        index += 1;
        continue;
      }
      paragraph.push(line2.trim());
      index += 1;
    }
    flushParagraph(paragraph);
    return blocks;
  }
  function appendInline(doc, parent, text2) {
    const parts = (text2 ?? "").split("`");
    parts.forEach((part, position) => {
      if (position % 2 === 1 && position < parts.length - 1) {
        const code = doc.createElement("code");
        code.className = "assistant-inline-code";
        code.textContent = part;
        parent.appendChild(code);
        return;
      }
      const literal = position % 2 === 1 ? "`" + part : part;
      if (literal) parent.appendChild(doc.createTextNode(literal));
    });
  }
  function renderCodeBlock(doc, block2, handlers) {
    const wrapper = doc.createElement("div");
    wrapper.className = "assistant-code";
    wrapper.dataset.role = "code-block";
    const head = doc.createElement("div");
    head.className = "assistant-code-head";
    const language = doc.createElement("span");
    language.className = "assistant-code-language";
    language.dataset.role = "code-language";
    language.textContent = block2.language || "text";
    const copy = doc.createElement("button");
    copy.className = "assistant-code-copy";
    copy.dataset.role = "copy-code";
    copy.type = "button";
    copy.textContent = "Copy";
    const body = block2.lines.join("\n");
    copy.addEventListener("click", () => {
      handlers.onCopy?.(body);
      const clipboard = globalThis.navigator?.clipboard;
      void clipboard?.writeText(body)?.catch?.(() => {
      });
      copy.dataset.copied = "true";
      copy.textContent = "Copied";
    });
    head.append(language, copy);
    const pre = doc.createElement("pre");
    pre.className = "assistant-code-body";
    const code = doc.createElement("code");
    code.textContent = body;
    pre.appendChild(code);
    wrapper.append(head, pre);
    return wrapper;
  }
  function renderMarkdown(doc, source, handlers = {}) {
    const root = doc.createElement("div");
    root.className = "assistant-markdown";
    for (const block2 of parseMarkdown(source)) {
      if (block2.kind === "code") {
        root.appendChild(renderCodeBlock(doc, block2, handlers));
        continue;
      }
      if (block2.kind === "heading") {
        const heading = doc.createElement(`h${Math.min(Math.max(block2.level, 1), 6)}`);
        heading.className = "assistant-heading";
        appendInline(doc, heading, block2.lines[0] ?? "");
        root.appendChild(heading);
        continue;
      }
      if (block2.kind === "quote") {
        const quote = doc.createElement("blockquote");
        quote.className = "assistant-quote";
        appendInline(doc, quote, block2.lines[0] ?? "");
        root.appendChild(quote);
        continue;
      }
      if (block2.kind === "list") {
        const list2 = doc.createElement(block2.ordered ? "ol" : "ul");
        list2.className = "assistant-list";
        for (const item2 of block2.lines) {
          const entry = doc.createElement("li");
          appendInline(doc, entry, item2);
          list2.appendChild(entry);
        }
        root.appendChild(list2);
        continue;
      }
      const paragraph = doc.createElement("p");
      paragraph.className = "assistant-paragraph";
      appendInline(doc, paragraph, block2.lines[0] ?? "");
      root.appendChild(paragraph);
    }
    return root;
  }
  const MAX_COMPOSER_HEIGHT = 160;
  function autoGrowComposer(input) {
    input.style.maxHeight = `${MAX_COMPOSER_HEIGHT}px`;
    input.style.height = "auto";
    const needed = input.scrollHeight;
    if (!needed) return;
    input.style.height = `${Math.min(needed, MAX_COMPOSER_HEIGHT)}px`;
    input.style.overflowY = needed > MAX_COMPOSER_HEIGHT ? "auto" : "hidden";
  }
  function renderToolProposal(doc, call) {
    const card = doc.createElement("div");
    card.className = "assistant-tool-proposal";
    card.dataset.role = "tool-proposal";
    const head = doc.createElement("div");
    head.className = "assistant-tool-head";
    const name = doc.createElement("span");
    name.className = "assistant-tool-name";
    name.textContent = call.name;
    const state = doc.createElement("span");
    state.className = "assistant-tool-state";
    state.dataset.role = "tool-state";
    state.textContent = "Waiting Approval";
    head.append(name, state);
    const args = doc.createElement("pre");
    args.className = "assistant-tool-arguments";
    args.dataset.role = "tool-arguments";
    args.textContent = call.arguments;
    const note = doc.createElement("div");
    note.className = "assistant-tool-note";
    note.textContent = "Proposal only. A human approves it in the approval list; the assistant cannot run it.";
    card.append(head, args, note);
    return card;
  }
  function renderChatTurn(doc, turn, mode, handlers) {
    const row2 = doc.createElement("div");
    row2.className = `assistant-message ${turn.role}`;
    row2.dataset.role = "chat-message";
    row2.dataset.messageRole = turn.role;
    const who = doc.createElement("div");
    who.className = "assistant-message-role";
    who.textContent = turn.role === "user" ? "You" : "Assistant";
    row2.appendChild(who);
    if (turn.role === "assistant") {
      row2.appendChild(renderMarkdown(doc, turn.content, { onCopy: handlers.onCopy }));
    } else {
      const body = doc.createElement("div");
      body.className = "assistant-message-body";
      body.textContent = turn.content;
      row2.appendChild(body);
    }
    if (turn.streaming) {
      const streaming = doc.createElement("div");
      streaming.className = "assistant-message-state";
      streaming.dataset.role = "chat-streaming";
      streaming.textContent = "Streaming…";
      row2.appendChild(streaming);
    }
    if (turn.stopped) {
      const stopped = doc.createElement("div");
      stopped.className = "assistant-message-state";
      stopped.dataset.role = "chat-stopped";
      stopped.textContent = "Streaming stopped";
      row2.appendChild(stopped);
    }
    if (turn.failed) {
      const failed = doc.createElement("div");
      failed.className = "assistant-message-state failed";
      failed.dataset.role = "chat-failed";
      failed.textContent = "Request failed";
      row2.appendChild(failed);
    }
    if (mode === "developer" && turn.toolCalls?.length) {
      for (const call of turn.toolCalls) row2.appendChild(renderToolProposal(doc, call));
    }
    return row2;
  }
  function historyButton(doc, role, label2, className, title, handler) {
    const element = doc.createElement("button");
    element.className = className;
    element.dataset.role = role;
    element.type = "button";
    element.textContent = label2;
    element.title = title;
    element.addEventListener("click", handler);
    return element;
  }
  function renderRenameBox(doc, conversation, handlers) {
    const box = doc.createElement("div");
    box.className = "assistant-history-rename";
    box.dataset.role = "rename-box";
    const field2 = doc.createElement("input");
    field2.className = "assistant-history-rename-input";
    field2.dataset.role = "rename-input";
    field2.type = "text";
    field2.maxLength = 80;
    field2.value = conversation.title;
    field2.setAttribute("aria-label", "Conversation name");
    const save = () => handlers.onRename?.(conversation.id, field2.value);
    field2.addEventListener("keydown", (event) => {
      const key = event.key;
      if (key === "Enter") {
        event.preventDefault();
        save();
      } else if (key === "Escape") {
        event.preventDefault();
        handlers.onCancelRename?.();
      }
    });
    box.append(
      field2,
      historyButton(doc, "rename-save", "Save", "assistant-history-rename-save", "Rename in this view only", save),
      historyButton(
        doc,
        "rename-cancel",
        "Cancel",
        "assistant-history-rename-cancel",
        "Keep the current name",
        () => handlers.onCancelRename?.()
      )
    );
    return box;
  }
  function renderHistory(doc, state, handlers) {
    const history = doc.createElement("div");
    history.className = "assistant-history";
    history.dataset.role = "chat-history";
    const head = doc.createElement("div");
    head.className = "assistant-history-head";
    const label2 = doc.createElement("span");
    label2.textContent = "History";
    const newChat = doc.createElement("button");
    newChat.className = "assistant-new-chat";
    newChat.dataset.role = "new-chat";
    newChat.type = "button";
    newChat.textContent = "New Chat";
    newChat.addEventListener("click", () => handlers.onNewChat?.());
    head.append(label2, newChat);
    history.appendChild(head);
    const search = doc.createElement("input");
    search.className = "assistant-history-search";
    search.dataset.role = "chat-search";
    search.type = "search";
    search.placeholder = "Search conversations…";
    search.maxLength = 120;
    search.value = state.query ?? "";
    search.setAttribute("aria-label", "Search conversations in this view");
    search.addEventListener("input", () => handlers.onSearchConversations?.(search.value));
    history.appendChild(search);
    if (state.conversations.length === 0) {
      const empty = doc.createElement("div");
      empty.className = "assistant-history-empty";
      empty.dataset.role = "history-empty";
      empty.textContent = "No conversations in this view yet.";
      history.appendChild(empty);
      return history;
    }
    const visible = visibleAssistantConversations(state.conversations, state.query ?? "");
    if (visible.length === 0) {
      const none = doc.createElement("div");
      none.className = "assistant-history-empty";
      none.dataset.role = "history-empty";
      none.textContent = "No conversation matches this search.";
      history.appendChild(none);
      return history;
    }
    for (const conversation of visible) {
      const row2 = doc.createElement("div");
      row2.className = `assistant-history-entry${conversation.id === state.activeConversation ? " active" : ""}${conversation.pinned ? " pinned" : ""}`;
      row2.dataset.role = "history-entry";
      row2.dataset.conversationId = conversation.id;
      if (conversation.pinned) row2.dataset.pinned = "true";
      const open = doc.createElement("button");
      open.className = "assistant-history-open";
      open.dataset.role = "open-conversation";
      open.type = "button";
      open.textContent = `${conversation.pinned ? "📌 " : ""}${conversation.title || "Untitled chat"}`;
      open.addEventListener("click", () => handlers.onSelectConversation?.(conversation.id));
      row2.appendChild(open);
      row2.appendChild(
        historyButton(
          doc,
          "pin-conversation",
          conversation.pinned ? "Unpin" : "Pin",
          "assistant-history-pin",
          "Keeps it at the top of this view only",
          () => handlers.onTogglePin?.(conversation.id)
        )
      );
      row2.appendChild(
        historyButton(
          doc,
          "rename-conversation",
          "Rename",
          "assistant-history-rename-open",
          "Rename in this view only",
          () => handlers.onBeginRename?.(conversation.id)
        )
      );
      row2.appendChild(
        historyButton(
          doc,
          "remove-conversation",
          "Remove from view",
          "assistant-history-remove",
          "Hides it in the extension only; the Bridge keeps its own records",
          () => handlers.onRemoveConversation?.(conversation.id)
        )
      );
      if (state.renaming === conversation.id) row2.appendChild(renderRenameBox(doc, conversation, handlers));
      history.appendChild(row2);
    }
    const note = doc.createElement("div");
    note.className = "assistant-history-note";
    note.dataset.role = "history-note";
    note.textContent = "Search, rename, pin and remove change this list only. The Bridge keeps its own records.";
    history.appendChild(note);
    return history;
  }
  function renderAssistantChat(doc, state, handlers) {
    const root = doc.createElement("div");
    root.className = "assistant-chat";
    root.dataset.role = "assistant-chat";
    root.appendChild(renderHistory(doc, state, handlers));
    const transcript = doc.createElement("div");
    transcript.className = "assistant-transcript";
    transcript.dataset.role = "chat-transcript";
    const active = state.conversations.find((item2) => item2.id === state.activeConversation) ?? null;
    if (!active || active.turns.length === 0) {
      const empty = doc.createElement("div");
      empty.className = "assistant-transcript-empty";
      empty.textContent = "Ask anything. The assistant explains and drafts; it never executes.";
      transcript.appendChild(empty);
    } else {
      for (const turn of active.turns) transcript.appendChild(renderChatTurn(doc, turn, state.uiMode, handlers));
    }
    root.appendChild(transcript);
    if (state.streaming) {
      const loading = doc.createElement("div");
      loading.className = "assistant-loading";
      loading.dataset.role = "chat-loading";
      loading.textContent = "Loading…";
      root.appendChild(loading);
    }
    if (state.status) {
      const status = doc.createElement("div");
      status.className = "assistant-status";
      status.dataset.role = "chat-status";
      status.textContent = sanitizeStatusText(state.status);
      root.appendChild(status);
    }
    if (state.canRetry && !state.streaming) {
      const retry = doc.createElement("button");
      retry.className = "assistant-retry";
      retry.dataset.role = "chat-retry";
      retry.type = "button";
      retry.textContent = "Retry";
      retry.title = "Re-sends your last message. Nothing is retried automatically.";
      retry.addEventListener("click", () => handlers.onRetry?.());
      root.appendChild(retry);
    }
    const composer = doc.createElement("div");
    composer.className = "assistant-composer";
    const input = doc.createElement("textarea");
    input.className = "assistant-input";
    input.dataset.role = "chat-input";
    input.rows = 2;
    input.placeholder = "Ask the assistant…";
    input.style.maxHeight = `${MAX_COMPOSER_HEIGHT}px`;
    if (state.draft) input.value = state.draft;
    const send = doc.createElement("button");
    send.className = "assistant-send";
    send.dataset.role = "chat-send";
    send.type = "button";
    send.textContent = "Send";
    send.disabled = state.streaming;
    const submit = () => {
      if (state.streaming) return;
      const value = input.value.trim();
      if (!value) return;
      input.value = "";
      autoGrowComposer(input);
      handlers.onSend(value);
    };
    send.addEventListener("click", submit);
    input.addEventListener("keydown", (event) => {
      const key = event.key;
      if (key !== "Enter") return;
      const keyboard = event;
      if (keyboard.shiftKey || keyboard.ctrlKey || keyboard.metaKey || keyboard.altKey || keyboard.isComposing) return;
      event.preventDefault();
      submit();
    });
    input.addEventListener("input", () => autoGrowComposer(input));
    autoGrowComposer(input);
    composer.append(input, send);
    if (state.streaming) {
      const stop = doc.createElement("button");
      stop.className = "assistant-stop";
      stop.dataset.role = "chat-stop";
      stop.type = "button";
      stop.textContent = "Stop";
      stop.addEventListener("click", () => handlers.onStop?.());
      composer.appendChild(stop);
    }
    const hint = doc.createElement("div");
    hint.className = "assistant-composer-hint";
    hint.dataset.role = "composer-hint";
    hint.textContent = "Enter sends · Shift+Enter adds a line";
    composer.appendChild(hint);
    root.appendChild(composer);
    return root;
  }
  const STATUS_LABEL = {
    connected: "Connected",
    not_configured: "Not configured",
    failed: "Failed"
  };
  function statusLabel(status) {
    return STATUS_LABEL[status] ?? "Not configured";
  }
  function findEntry(state) {
    return state.providers.find((entry) => entry.provider === state.provider) ?? state.providers[0] ?? null;
  }
  function select(doc, role, options, current) {
    const element = doc.createElement("select");
    element.className = "assistant-select";
    element.dataset.role = role;
    for (const option of options) {
      const item2 = doc.createElement("option");
      item2.value = option;
      item2.textContent = option;
      if (option === current) item2.selected = true;
      element.appendChild(item2);
    }
    return element;
  }
  function field(doc, label2, control) {
    const row2 = doc.createElement("label");
    row2.className = "assistant-field";
    const caption = doc.createElement("span");
    caption.className = "assistant-field-label";
    caption.textContent = label2;
    row2.append(caption, control);
    return row2;
  }
  function renderModelSelector(doc, state, handlers) {
    const root = doc.createElement("div");
    root.className = "assistant-model-selector";
    root.dataset.role = "model-selector";
    const entry = findEntry(state);
    const providers = state.providers.map((item2) => item2.provider);
    const providerSelect = select(doc, "provider-select", providers, state.provider);
    providerSelect.addEventListener("change", () => handlers.onSelectProvider?.(providerSelect.value));
    const models = entry?.models ?? [];
    const modelSelect = select(doc, "model-select", models, state.model || entry?.selectedModel || "");
    modelSelect.addEventListener("change", () => handlers.onSelectModel?.(modelSelect.value));
    const status = doc.createElement("span");
    status.className = "assistant-badge";
    status.dataset.role = "provider-status-badge";
    status.textContent = statusLabel(entry?.status ?? "not_configured");
    root.append(field(doc, "Provider", providerSelect), field(doc, "Model", modelSelect), status);
    return root;
  }
  function renderModeToggle(doc, mode, handlers) {
    const root = doc.createElement("div");
    root.className = "assistant-mode-toggle";
    root.dataset.role = "mode-toggle";
    root.dataset.mode = mode;
    const label2 = doc.createElement("span");
    label2.className = "assistant-field-label";
    label2.textContent = mode === "developer" ? "Developer Mode" : "User Mode";
    const button2 = doc.createElement("button");
    button2.className = "assistant-mode-button";
    button2.dataset.role = "toggle-mode";
    button2.type = "button";
    button2.textContent = mode === "developer" ? "Switch to User Mode" : "Switch to Developer Mode";
    button2.addEventListener("click", () => handlers.onSetMode?.(mode === "developer" ? "user" : "developer"));
    root.append(label2, button2);
    return root;
  }
  function renderProviderStatusList(doc, state) {
    const list2 = doc.createElement("div");
    list2.className = "assistant-provider-list";
    list2.dataset.role = "provider-status-list";
    for (const entry of state.providers) {
      const row2 = doc.createElement("div");
      row2.className = "assistant-provider-row";
      row2.dataset.role = "provider-row";
      row2.dataset.provider = entry.provider;
      row2.dataset.status = entry.status;
      const name = doc.createElement("span");
      name.className = "assistant-provider-name";
      name.textContent = entry.displayName || entry.provider;
      const status = doc.createElement("span");
      status.className = "assistant-badge";
      status.dataset.role = "provider-status";
      status.textContent = statusLabel(entry.status);
      const hint = doc.createElement("span");
      hint.className = "assistant-provider-hint";
      hint.dataset.role = "provider-key-hint";
      hint.textContent = entry.hasStoredKey ? entry.keyHint || "stored" : "no key stored";
      row2.append(name, status, hint);
      list2.appendChild(row2);
    }
    return list2;
  }
  function renderProviderSettings(doc, state, handlers) {
    const root = doc.createElement("div");
    root.className = "assistant-settings";
    root.dataset.role = "provider-settings";
    const head = doc.createElement("div");
    head.className = "assistant-settings-head";
    const title = doc.createElement("span");
    title.textContent = "Provider Settings";
    head.appendChild(title);
    root.appendChild(head);
    const entry = findEntry(state);
    const providerSelect = select(doc, "settings-provider", state.providers.map((item2) => item2.provider), state.provider);
    providerSelect.addEventListener("change", () => handlers.onSelectProvider?.(providerSelect.value));
    const modelSelect = select(doc, "settings-model", entry?.models ?? [], state.model || entry?.selectedModel || "");
    modelSelect.addEventListener("change", () => handlers.onSelectModel?.(modelSelect.value));
    const apiKey = doc.createElement("input");
    apiKey.className = "assistant-input";
    apiKey.dataset.role = "api-key-input";
    apiKey.type = "password";
    apiKey.autocomplete = "off";
    apiKey.name = "assistant-provider-secret";
    apiKey.placeholder = entry?.hasStoredKey ? "Stored — type a new key to replace it" : "Paste your API key";
    const baseUrl = doc.createElement("input");
    baseUrl.className = "assistant-input";
    baseUrl.dataset.role = "base-url-input";
    baseUrl.type = "text";
    baseUrl.value = entry?.baseUrl ?? "";
    baseUrl.placeholder = "Default endpoint";
    root.append(
      field(doc, "Provider", providerSelect),
      field(doc, "Model", modelSelect),
      field(doc, "API Key", apiKey),
      field(doc, "Base URL", baseUrl)
    );
    const actions = doc.createElement("div");
    actions.className = "assistant-settings-actions";
    const test = doc.createElement("button");
    test.className = "assistant-settings-test";
    test.dataset.role = "test-connection";
    test.type = "button";
    test.textContent = "Test Connection";
    test.addEventListener("click", () => {
      const key = apiKey.value;
      apiKey.value = "";
      handlers.onTestConnection?.({ provider: providerSelect.value, model: modelSelect.value, apiKey: key });
    });
    const save = doc.createElement("button");
    save.className = "assistant-settings-save";
    save.dataset.role = "save-provider";
    save.type = "button";
    save.textContent = "Save";
    save.addEventListener("click", () => {
      const key = apiKey.value;
      apiKey.value = "";
      handlers.onSaveProvider?.({
        provider: providerSelect.value,
        model: modelSelect.value,
        baseUrl: baseUrl.value.trim(),
        apiKey: key
      });
    });
    const forget = doc.createElement("button");
    forget.className = "assistant-settings-forget";
    forget.dataset.role = "forget-key";
    forget.type = "button";
    forget.textContent = "Forget stored key";
    forget.addEventListener("click", () => handlers.onForgetKey?.(providerSelect.value));
    actions.append(test, save, forget);
    root.appendChild(actions);
    if (state.test) {
      const result = doc.createElement("div");
      result.className = "assistant-settings-result";
      result.dataset.role = "provider-test-result";
      result.dataset.status = state.test.status;
      result.textContent = `${statusLabel(state.test.status)} — ${state.test.message}`;
      root.appendChild(result);
    }
    root.appendChild(renderProviderStatusList(doc, state));
    const keyStorage = state.settings?.keyStorage;
    const note = doc.createElement("div");
    note.className = "assistant-settings-note";
    note.dataset.role = "key-storage-note";
    note.textContent = keyStorage ? `Keys are encrypted by the Bridge (${keyStorage.algorithm}) and stored at ${keyStorage.location}. The extension never keeps a plaintext key.` : "Keys are encrypted by the Bridge before storage. The extension never keeps a plaintext key.";
    root.appendChild(note);
    return root;
  }
  const ASK_AI_TRIGGER = "ask_ai";
  const MAX_SELECTED_TEXT = 8e3;
  const MAX_READABLE_CONTENT = 2e4;
  const READABLE_SELECTORS = ["main", "article", "[role='main']"];
  function nowIso() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  function isShareableUrl(raw) {
    return /^https?:\/\//i.test(raw.trim());
  }
  function safeUrl(raw) {
    const candidate = (raw ?? "").trim();
    if (!isShareableUrl(candidate)) return "";
    const cut = candidate.split(/[?#]/, 1)[0];
    return cut.slice(0, 2e3);
  }
  function selectionText(doc) {
    const view = doc.defaultView;
    const selection = view?.getSelection?.();
    return (selection?.toString() ?? "").trim().slice(0, MAX_SELECTED_TEXT);
  }
  function readableContent(doc) {
    let host = null;
    for (const selector of READABLE_SELECTORS) {
      host = doc.querySelector(selector);
      if (host) break;
    }
    const source = host ?? doc.body ?? null;
    if (!source) return "";
    const text2 = (source.textContent ?? "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
    return text2.slice(0, MAX_READABLE_CONTENT);
  }
  function collectWebContext(doc, options = {}) {
    const timestamp = options.timestamp ?? nowIso();
    const href = options.url ?? doc.defaultView?.location?.href ?? "";
    return {
      trigger: ASK_AI_TRIGGER,
      consented_at: timestamp,
      page_title: (doc.title ?? "").slice(0, 300),
      page_url: safeUrl(href),
      selected_text: selectionText(doc),
      readable_content: readableContent(doc),
      timestamp
    };
  }
  function renderAskAiButton(doc, handlers) {
    const button2 = doc.createElement("button");
    button2.className = "assistant-ask-ai";
    button2.dataset.role = "ask-ai";
    button2.type = "button";
    button2.textContent = "Ask AI";
    button2.title = "Share this page with the assistant (collected only now, sent only when you send a message)";
    button2.addEventListener("click", () => {
      const collect = handlers.collect ?? ((target) => collectWebContext(target));
      handlers.onAskAi(collect(doc));
    });
    return button2;
  }
  function renderWebContextPreview(doc, bundle, handlers = {}) {
    const root = doc.createElement("div");
    root.className = "assistant-context";
    root.dataset.role = "web-context";
    const head = doc.createElement("div");
    head.className = "assistant-context-head";
    const title = doc.createElement("span");
    title.textContent = "Page Context";
    const badge = doc.createElement("span");
    badge.className = "assistant-badge";
    badge.textContent = "READ ONLY";
    head.append(title, badge);
    root.appendChild(head);
    if (!bundle) {
      const empty = doc.createElement("div");
      empty.className = "assistant-context-line";
      empty.textContent = "No page context. Click Ask AI to share this page.";
      root.append(empty);
      return root;
    }
    const line2 = (label2, value) => {
      const row2 = doc.createElement("div");
      row2.className = "assistant-context-line";
      const key = doc.createElement("span");
      key.className = "assistant-context-label";
      key.textContent = label2;
      const val = doc.createElement("span");
      val.className = "assistant-context-value";
      val.textContent = value;
      row2.append(key, val);
      root.appendChild(row2);
    };
    line2("Page:", bundle.page_title || "(untitled)");
    line2("URL:", bundle.page_url || "(local page — not shared)");
    line2("Selected Text:", bundle.selected_text || "(none)");
    line2("Readable Content:", bundle.readable_content ? `${bundle.readable_content.length} characters` : "(none)");
    line2("Timestamp:", bundle.timestamp);
    line2("Trigger:", bundle.trigger);
    const note = doc.createElement("div");
    note.className = "assistant-context-note";
    note.textContent = "Collected when you clicked Ask AI. It is sent only with your next message.";
    root.appendChild(note);
    const clear = doc.createElement("button");
    clear.className = "assistant-context-clear";
    clear.dataset.role = "clear-context";
    clear.type = "button";
    clear.textContent = "Remove context";
    clear.addEventListener("click", () => handlers.onClearContext?.());
    root.appendChild(clear);
    return root;
  }
  const CONTEXT_PREVIEW_LIMIT = 1200;
  function injectedContextText(bundle) {
    if (!bundle) return "";
    const parts = [];
    if (bundle.page_title) parts.push(`Page: ${bundle.page_title}`);
    if (bundle.page_url) parts.push(`URL: ${bundle.page_url}`);
    if (bundle.selected_text) parts.push(`Selected text:
${bundle.selected_text}`);
    if (bundle.readable_content) parts.push(`Readable content:
${bundle.readable_content}`);
    return parts.join("\n\n");
  }
  function selectedTextSummary(bundle) {
    const selected = bundle?.selected_text ?? "";
    if (!selected) return "(nothing selected)";
    const head = selected.replace(/\s+/g, " ").trim().slice(0, 120);
    return `${selected.length} characters — “${head}${selected.length > head.length ? "…" : ""}”`;
  }
  function row(doc, label2, value, role) {
    const line2 = doc.createElement("div");
    line2.className = "assistant-context-line";
    line2.dataset.role = role;
    const key = doc.createElement("span");
    key.className = "assistant-context-label";
    key.textContent = label2;
    const val = doc.createElement("span");
    val.className = "assistant-context-value";
    val.textContent = value;
    line2.append(key, val);
    return line2;
  }
  function contextSource(state) {
    const sources = [];
    if (state.bundle) sources.push("Ask AI (this page, on your click)");
    const developer = state.contextStatus?.developerContext;
    if (state.uiMode === "developer" && developer?.loaded) {
      const names = developer.sources?.length ? developer.sources.join(", ") : "project files";
      sources.push(`Developer Context (read-only: ${names})`);
    }
    return sources.length ? sources.join(" · ") : "No context captured";
  }
  function renderContextBundlePanel(doc, state, handlers = {}) {
    const root = doc.createElement("div");
    root.className = "assistant-context-panel";
    root.dataset.role = "context-bundle";
    root.dataset.include = state.include && state.bundle ? "true" : "false";
    const head = doc.createElement("div");
    head.className = "assistant-context-panel-head";
    const title = doc.createElement("span");
    title.className = "assistant-context-panel-title";
    title.textContent = "Context Bundle";
    const badge = doc.createElement("span");
    badge.className = "assistant-badge";
    badge.dataset.role = "context-readonly";
    badge.textContent = "READ ONLY";
    head.append(title, badge);
    root.appendChild(head);
    root.appendChild(row(doc, "Project:", state.project || "(no project selected)", "context-project"));
    root.appendChild(
      row(
        doc,
        "Agent:",
        state.provider ? `${state.provider}${state.model ? ` · ${state.model}` : ""}` : "(local simulator)",
        "context-agent"
      )
    );
    root.appendChild(
      row(doc, "Status:", "Read-only context. The assistant proposes; a human approves every change.", "context-status")
    );
    root.appendChild(row(doc, "Context source:", contextSource(state), "context-source"));
    root.appendChild(row(doc, "Current page:", state.bundle?.page_title || "(no page captured)", "context-page-title"));
    root.appendChild(row(doc, "Selected text:", selectedTextSummary(state.bundle), "context-selected-summary"));
    const injected = injectedContextText(state.bundle);
    const preview = doc.createElement("pre");
    preview.className = "assistant-context-injected";
    preview.dataset.role = "context-injected-preview";
    preview.dataset.length = String(injected.length);
    preview.textContent = injected ? injected.slice(0, CONTEXT_PREVIEW_LIMIT) + (injected.length > CONTEXT_PREVIEW_LIMIT ? "\n…" : "") : "Nothing would be sent. Click Ask AI to capture this page.";
    root.appendChild(preview);
    const decision = doc.createElement("div");
    decision.className = "assistant-context-decision";
    decision.dataset.role = "context-decision";
    decision.textContent = state.bundle ? state.include ? "This context goes with your next message." : "This context stays here and is not sent." : "No context is attached to your next message.";
    root.appendChild(decision);
    if (state.bundle) {
      const toggle = doc.createElement("button");
      toggle.className = "assistant-context-include";
      toggle.dataset.role = "toggle-context-include";
      toggle.dataset.include = state.include ? "true" : "false";
      toggle.type = "button";
      toggle.textContent = state.include ? "Do not send this context" : "Send this context";
      toggle.title = "Decides whether the captured page travels with your next message";
      toggle.addEventListener("click", () => handlers.onToggleContextInclude?.(!state.include));
      root.appendChild(toggle);
    }
    root.appendChild(renderWebContextPreview(doc, state.bundle, handlers));
    return root;
  }
  const ONBOARDING_VISIBLE_STATES = ["new", "active"];
  function isOnboardingVisible(state) {
    return ONBOARDING_VISIBLE_STATES.includes(state);
  }
  function isOnboardingDeferred(state) {
    return state === "later";
  }
  function clampOnboardingStep(step) {
    if (!Number.isFinite(step)) return 0;
    return Math.min(Math.max(Math.trunc(step), 0), ONBOARDING_STEP_COUNT - 1);
  }
  function stepSignal(step, state) {
    if (step.id === "start_bridge") {
      return state.bridgeReachable ? "Bridge reachable" : "Bridge not detected — you can continue anyway";
    }
    if (step.id === "configure_provider" || step.id === "test_connection") {
      return state.providerConfigured ? "A provider is configured" : "No provider configured — you can continue anyway";
    }
    return "Chat works without a provider using the local simulator";
  }
  function button(doc, role, label2, className, handler) {
    const element = doc.createElement("button");
    element.className = className;
    element.dataset.role = role;
    element.type = "button";
    element.textContent = label2;
    element.addEventListener("click", () => handler?.());
    return element;
  }
  function renderOnboarding(doc, state, handlers = {}) {
    const root = doc.createElement("div");
    root.className = "assistant-onboarding";
    root.dataset.role = "onboarding";
    root.dataset.onboardingState = state.onboardingState;
    const index = clampOnboardingStep(state.onboardingStep);
    const step = ONBOARDING_STEPS[index];
    root.dataset.stepId = step.id;
    root.dataset.step = String(index + 1);
    const head = doc.createElement("div");
    head.className = "assistant-onboarding-head";
    const title = doc.createElement("span");
    title.className = "assistant-onboarding-title";
    title.textContent = "Getting started";
    const progress = doc.createElement("span");
    progress.className = "assistant-onboarding-progress";
    progress.dataset.role = "onboarding-progress";
    progress.textContent = `Step ${index + 1} of ${ONBOARDING_STEP_COUNT}`;
    head.append(title, progress);
    root.appendChild(head);
    const list2 = doc.createElement("ol");
    list2.className = "assistant-onboarding-steps";
    list2.dataset.role = "onboarding-steps";
    ONBOARDING_STEPS.forEach((entry, position) => {
      const row2 = doc.createElement("li");
      row2.className = `assistant-onboarding-step${position === index ? " current" : ""}${position < index ? " done" : ""}`;
      row2.dataset.role = "onboarding-step";
      row2.dataset.stepId = entry.id;
      if (position === index) row2.dataset.current = "true";
      const label2 = doc.createElement("span");
      label2.className = "assistant-onboarding-step-title";
      label2.textContent = `${position + 1}. ${entry.title}`;
      row2.appendChild(label2);
      if (position === index) {
        const detail = doc.createElement("div");
        detail.className = "assistant-onboarding-detail";
        detail.dataset.role = "onboarding-detail";
        detail.textContent = entry.detail;
        row2.appendChild(detail);
        const signal = doc.createElement("div");
        signal.className = "assistant-onboarding-signal";
        signal.dataset.role = "onboarding-signal";
        signal.textContent = stepSignal(entry, state);
        row2.appendChild(signal);
      }
      list2.appendChild(row2);
    });
    root.appendChild(list2);
    const note = doc.createElement("div");
    note.className = "assistant-onboarding-note";
    note.dataset.role = "onboarding-note";
    note.textContent = "This guide only shows you where things are. It stores no API key and changes no permission: every write still waits for your approval in the Bridge.";
    root.appendChild(note);
    const actions = doc.createElement("div");
    actions.className = "assistant-onboarding-actions";
    if (index > 0) {
      actions.appendChild(button(doc, "onboarding-back", "Back", "assistant-onboarding-secondary", handlers.onBack));
    }
    const last = index === ONBOARDING_STEP_COUNT - 1;
    if (last) {
      actions.appendChild(
        button(doc, "onboarding-finish", "Start Chat", "assistant-onboarding-primary", handlers.onFinish)
      );
    } else {
      actions.appendChild(button(doc, "onboarding-next", "Next", "assistant-onboarding-primary", handlers.onNext));
    }
    actions.appendChild(button(doc, "onboarding-skip", "Skip", "assistant-onboarding-secondary", handlers.onSkip));
    actions.appendChild(
      button(doc, "onboarding-later", "Setup Later", "assistant-onboarding-secondary", handlers.onSetupLater)
    );
    root.appendChild(actions);
    return root;
  }
  function renderOnboardingHint(doc, handlers = {}) {
    const hint = doc.createElement("div");
    hint.className = "assistant-onboarding-hint";
    hint.dataset.role = "onboarding-hint";
    const text2 = doc.createElement("span");
    text2.textContent = "Setup postponed. Chat is available now.";
    hint.appendChild(text2);
    hint.appendChild(
      button(doc, "onboarding-reopen", "Show setup guide", "assistant-onboarding-secondary", handlers.onReopen)
    );
    return hint;
  }
  function line(doc, label2, value) {
    const row2 = doc.createElement("div");
    row2.className = "assistant-context-line";
    const key = doc.createElement("span");
    key.className = "assistant-context-label";
    key.textContent = label2;
    const val = doc.createElement("span");
    val.className = "assistant-context-value";
    val.textContent = value;
    row2.append(key, val);
    return row2;
  }
  function renderDeveloperContext(doc, status) {
    const root = doc.createElement("div");
    root.className = "assistant-dev-context";
    root.dataset.role = "developer-context";
    const head = doc.createElement("div");
    head.className = "assistant-context-head";
    const title = doc.createElement("span");
    title.textContent = "Developer Context";
    const badge = doc.createElement("span");
    badge.className = "assistant-badge";
    badge.textContent = "READ ONLY";
    head.append(title, badge);
    root.appendChild(head);
    if (!status) {
      root.appendChild(line(doc, "Status:", "not loaded"));
      return root;
    }
    const developer = status.developerContext;
    root.appendChild(line(doc, "Loaded:", developer.loaded ? "yes" : "no"));
    root.appendChild(line(doc, "Project:", developer.project || "(none selected)"));
    root.appendChild(line(doc, "Sources:", developer.sources?.length ? developer.sources.join(", ") : "(none)"));
    root.appendChild(line(doc, "Endpoint:", developer.endpoint || "(none)"));
    root.appendChild(
      line(doc, "Modifications:", developer.modificationRequiresApproval === false ? "unknown" : "require human approval")
    );
    root.appendChild(line(doc, "Web capture:", status.web.automaticCapture ? "automatic" : "explicit Ask AI only"));
    root.appendChild(line(doc, "Web upload:", status.web.automaticUpload ? "automatic" : "only with your message"));
    const note = doc.createElement("div");
    note.className = "assistant-context-note";
    note.textContent = "The assistant reads and explains this context and may draft a proposal. It cannot modify source files or run anything.";
    root.appendChild(note);
    return root;
  }
  const STATUS_TEXT = {
    unknown: "Not connected",
    connected: "Connected",
    offline: "Local Bridge unavailable",
    error: "Error"
  };
  class Panel {
    doc;
    handlers;
    root;
    projects = [];
    collapsed = false;
    constructor(doc, container, handlers) {
      this.doc = doc;
      this.handlers = handlers;
      this.root = doc.createElement("div");
      this.root.className = "panel";
      container.appendChild(this.root);
    }
    setProjects(projects) {
      this.projects = projects;
    }
    render(state) {
      this.root.className = `panel${this.collapsed ? " collapsed" : ""}`;
      this.root.textContent = "";
      this.root.append(
        this.renderHeader(state),
        this.renderStatus(state),
        this.renderToolbar(state),
        this.renderBody(state),
        this.renderFooter(state)
      );
    }
    renderHeader(state) {
      const header = this.doc.createElement("div");
      header.className = "header";
      const title = this.doc.createElement("span");
      title.className = "title";
      title.textContent = "ChatGPT Cursor Bridge";
      const toggle = this.doc.createElement("button");
      toggle.className = "icon-button";
      toggle.dataset.role = "toggle";
      toggle.textContent = this.collapsed ? "+" : "–";
      toggle.title = this.collapsed ? "Expand" : "Collapse";
      toggle.addEventListener("click", () => {
        this.collapsed = !this.collapsed;
        this.render(state);
      });
      header.append(title, toggle);
      return header;
    }
    renderStatus(state) {
      const grid = this.doc.createElement("div");
      grid.className = "status-grid";
      const addRow = (key, valueNode) => {
        const k = this.doc.createElement("span");
        k.className = "status-key";
        k.textContent = key;
        const v = this.doc.createElement("span");
        v.className = "status-value";
        v.appendChild(valueNode);
        grid.append(k, v);
      };
      const bridge = this.doc.createElement("span");
      const dot = this.doc.createElement("span");
      dot.className = `dot ${state.bridgeStatus}`;
      bridge.append(dot, this.doc.createTextNode(STATUS_TEXT[state.bridgeStatus] ?? state.bridgeStatus));
      addRow("Bridge:", bridge);
      addRow("Project:", this.doc.createTextNode(state.currentProject ?? "none"));
      const pending = state.pendingActions.filter((item2) => item2.state === "pending").length;
      addRow("Pending Actions:", this.doc.createTextNode(String(pending + state.recoveredApprovals.length)));
      if (state.uiMode === "developer") {
        addRow("Sessions:", this.doc.createTextNode(String(state.sessions.length)));
      }
      return grid;
    }
    renderToolbar(state) {
      const bar = this.doc.createElement("div");
      bar.className = "toolbar";
      const select2 = this.doc.createElement("select");
      select2.dataset.role = "project-select";
      const placeholder = this.doc.createElement("option");
      placeholder.value = "";
      placeholder.textContent = this.projects.length ? "Select project" : "No projects";
      select2.appendChild(placeholder);
      for (const name of this.projects) {
        const option = this.doc.createElement("option");
        option.value = name;
        option.textContent = name;
        option.selected = name === state.currentProject;
        select2.appendChild(option);
      }
      select2.addEventListener("change", () => {
        if (select2.value) this.handlers.onSelectProject(select2.value);
      });
      const connect = this.doc.createElement("button");
      connect.dataset.role = "connect";
      connect.textContent = state.bridgeStatus === "connected" ? "Refresh" : "Connect";
      connect.addEventListener("click", () => this.handlers.onConnect());
      bar.append(select2, connect);
      return bar;
    }
    renderBody(state) {
      const body = this.doc.createElement("div");
      body.className = "body";
      body.appendChild(this.renderAssistantSurface(state));
      if (state.uiMode === "developer") body.appendChild(this.renderDeveloperSurface(state));
      if (state.bridgeStatus === "offline") {
        const warn = this.doc.createElement("div");
        warn.className = "empty";
        warn.textContent = "Local Bridge unavailable. Start it with: uvicorn app.main:app --port 8765";
        body.appendChild(warn);
      }
      if (state.uiMode === "user") {
        const waiting = state.pendingActions.filter((item2) => item2.state === "pending").length + state.recoveredApprovals.length;
        if (waiting > 0) {
          const hint = this.doc.createElement("div");
          hint.className = "empty";
          hint.dataset.role = "approval-hint";
          hint.textContent = `${waiting} action(s) waiting for approval. Switch to Developer Mode to review them.`;
          body.appendChild(hint);
        }
        return body;
      }
      for (const approval of state.recoveredApprovals) {
        body.appendChild(renderRecoveredApprovalCard(
          this.doc,
          approval,
          this.handlers.onReconfirm ?? (() => {
          }),
          this.handlers.onApproveRecovered ?? (() => {
          })
        ));
      }
      if (state.pendingActions.length === 0 && state.recoveredApprovals.length === 0) {
        const empty = this.doc.createElement("div");
        empty.className = "empty";
        empty.textContent = "No actions captured yet.";
        body.appendChild(empty);
        return body;
      }
      const ordered = [...state.pendingActions].reverse();
      for (const item2 of ordered) {
        body.appendChild(
          renderApprovalCard(this.doc, item2, {
            onApprove: this.handlers.onApprove,
            onReject: this.handlers.onReject
          })
        );
      }
      return body;
    }
    /**
     * The User Mode surface set (spec §2): chat, model selector, context,
     * history and settings. Nothing here executes, approves, applies or auto-fixes.
     *
     * Phase 34 renders the first-run guide **above** Chat rather than instead of
     * it, so the first surface a new user sees is still the chat panel and Skip is
     * always reachable.
     */
    renderAssistantSurface(state) {
      const surface = this.doc.createElement("div");
      surface.className = "assistant-surface";
      surface.dataset.role = "assistant-surface";
      surface.dataset.mode = state.uiMode;
      surface.appendChild(renderModeToggle(this.doc, state.uiMode, this.handlers));
      if (isOnboardingVisible(state.onboardingState)) {
        surface.appendChild(
          renderOnboarding(
            this.doc,
            {
              onboardingState: state.onboardingState,
              onboardingStep: state.onboardingStep,
              bridgeReachable: state.bridgeStatus === "connected",
              providerConfigured: state.assistantProviders.some((entry) => entry.status === "connected")
            },
            this.handlers
          )
        );
      } else if (isOnboardingDeferred(state.onboardingState)) {
        surface.appendChild(renderOnboardingHint(this.doc, this.handlers));
      }
      const settingsState = {
        uiMode: state.uiMode,
        provider: state.assistantProvider,
        model: state.assistantModel,
        providers: state.assistantProviders,
        settings: state.assistantSettings,
        test: state.assistantProviderTest
      };
      surface.appendChild(renderModelSelector(this.doc, settingsState, this.handlers));
      const context = this.doc.createElement("div");
      context.className = "assistant-context-block";
      context.appendChild(renderAskAiButton(this.doc, { onAskAi: (bundle) => this.handlers.onAskAi?.(bundle) }));
      context.appendChild(
        renderContextBundlePanel(
          this.doc,
          {
            bundle: state.assistantWebContext,
            include: state.assistantContextInclude,
            project: state.currentProject,
            provider: state.assistantProvider,
            model: state.assistantModel,
            uiMode: state.uiMode,
            contextStatus: state.assistantContextStatus
          },
          {
            onClearContext: () => this.handlers.onClearContext?.(),
            onToggleContextInclude: (include) => this.handlers.onToggleContextInclude?.(include)
          }
        )
      );
      surface.appendChild(context);
      const active = state.assistantConversations.find((item2) => item2.id === state.assistantActiveConversation) ?? null;
      const lastTurn = active?.turns[active.turns.length - 1] ?? null;
      surface.appendChild(
        renderAssistantChat(
          this.doc,
          {
            uiMode: state.uiMode,
            conversations: state.assistantConversations,
            activeConversation: state.assistantActiveConversation,
            streaming: state.assistantStreaming,
            status: state.assistantStatus,
            query: state.assistantConversationQuery,
            renaming: state.assistantRenaming,
            draft: state.assistantDraft,
            // Retry is offered only after a failure, and only as a button.
            canRetry: lastTurn?.failed === true
          },
          { ...this.handlers, onSend: this.handlers.onSend ?? (() => {
          }) }
        )
      );
      surface.appendChild(renderProviderSettings(this.doc, settingsState, this.handlers));
      return surface;
    }
    /** Developer Mode extras. Every dashboard below is read-only. */
    renderDeveloperSurface(state) {
      const body = this.doc.createElement("div");
      body.className = "developer-surface";
      body.dataset.role = "developer-surface";
      body.appendChild(renderDeveloperContext(this.doc, state.assistantContextStatus));
      body.appendChild(renderWorkflowDashboard(this.doc, state.projectContext, {
        agents: state.agents,
        modelSelection: state.modelSelection
      }));
      body.appendChild(renderRuntimeDashboard(this.doc, state.runtimes, state.tasks, state.runtimeEvents, state.qualityReport));
      body.appendChild(renderCollaborationDashboard(this.doc, state.teams, state.agents, state.dependencies, state.collaborationEvents));
      body.appendChild(renderProjectIntelligenceDashboard(this.doc, state.projectProfile, state.projectGraph, state.impactReport, state.projectMemoryHistory));
      body.appendChild(renderContextDashboard(this.doc, state.devContext, state.devContextSelection, (id) => {
        this.handlers.onToggleContextSelection?.(id);
      }));
      body.appendChild(renderIntelligenceDashboard(this.doc, state.phase30Intelligence));
      body.appendChild(
        renderLlmGatewayDashboard(this.doc, {
          providers: state.llmProviders,
          models: state.llmModels,
          conversations: state.llmConversations,
          toolProposals: state.llmToolProposals
        })
      );
      body.appendChild(renderIntelligenceDashboard$1(this.doc, state.intelligenceInsights, state.intelligenceProposals, state.intelligenceDecisions, state.intelligenceQuality, {
        project: state.currentProject ?? "",
        observations: state.intelligenceObservations,
        patterns: state.intelligencePatterns,
        predictions: state.intelligencePredictions,
        recommendations: state.intelligenceRecommendations,
        outcomes: state.intelligenceOutcomes,
        knowledge: state.intelligenceKnowledge,
        evidence: state.intelligenceEvidence,
        quality: state.intelligenceQuality11
      }, {
        project: state.currentProject ?? "",
        trends: state.intelligenceTrends,
        correlations: state.intelligenceCorrelations,
        impact: state.intelligenceImpactPredictions,
        dependencies: state.intelligenceDependencyRisks,
        ranking: state.intelligenceRecommendationRanking,
        evaluations: state.intelligenceEvaluations,
        metrics: state.intelligenceEvaluationMetrics,
        evidenceGraph: state.intelligenceEvidenceGraph
      }, state.intelligenceValidation, state.intelligenceGovernance));
      body.appendChild(renderSimulationDashboard(this.doc, state.simulation, state.simulationScenarios, state.simulationEvaluations, state.simulationPlans, state.simulationQuality));
      body.appendChild(renderExecutionDashboard(this.doc, state.executionTasks, state.executionProposals, state.executionResults, state.executionQuality7));
      body.appendChild(renderExecutionLoopDashboard(this.doc, state.executionLoops, state.executionLoopQuality8, {
        dags: state.executionDags,
        dagReady: state.executionDagReady,
        metrics: state.engineeringMetrics,
        context: state.executionLoopContext
      }));
      if (state.executionLoops[0]) {
        body.appendChild(renderExecutionLoopTimeline(this.doc, state.executionLoops[0].id, state.executionLoopTimeline));
      }
      body.appendChild(renderEngineeringGraphDashboard(this.doc, {
        graph: state.engineeringGraph,
        failures: state.failurePatterns,
        timeline: state.evolutionTimeline,
        capabilities: state.agentCapabilityMetrics
      }));
      body.appendChild(renderBenchmarkDashboard(this.doc, {
        benchmarks: state.benchmarks,
        results: [],
        failurePatterns: state.failurePatterns,
        capabilities: state.agentCapabilityMetrics
      }));
      body.appendChild(renderDemoDashboard(this.doc, {
        scenarios: state.demoScenarios,
        flow: state.demoFlow,
        replays: state.replays,
        artifacts: state.artifacts
      }));
      body.appendChild(renderGovernanceDashboard(this.doc, {
        health: state.governanceHealth,
        drift: state.governanceDrift,
        debt: state.governanceDebt,
        policies: state.governancePolicies,
        timeline: state.governanceTimeline,
        quality9: state.governanceQuality9
      }));
      body.appendChild(renderOrganizationDashboard(this.doc, {
        health: state.organizationHealth,
        dashboard: state.organizationDashboard,
        learning: state.organizationLearning,
        quality10: state.organizationQuality10,
        impact: state.organizationStrategyImpact,
        risk: state.organizationStrategyRisk,
        strategies: state.organizationStrategies,
        recommendations: state.organizationRecommendations,
        context: state.organizationStrategyContext
      }));
      return body;
    }
    renderFooter(state) {
      const footer = this.doc.createElement("div");
      footer.className = "footer";
      footer.textContent = state.lastResult ?? "Every action requires explicit approval.";
      return footer;
    }
  }
  const styles = ':host {\n  all: initial;\n}\n\n* {\n  box-sizing: border-box;\n  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;\n}\n\n.panel {\n  position: fixed;\n  top: 84px;\n  right: 18px;\n  width: 380px;\n  max-height: 76vh;\n  display: flex;\n  flex-direction: column;\n  background: #ffffff;\n  color: #0f172a;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  box-shadow: 0 18px 48px rgba(15, 23, 42, 0.18);\n  z-index: 2147483000;\n  overflow: hidden;\n}\n\n.panel.collapsed .body {\n  display: none;\n}\n\n.header {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 12px 14px;\n  background: #0f172a;\n  color: #f8fafc;\n}\n\n.title {\n  font-size: 13px;\n  font-weight: 700;\n  flex: 1;\n  letter-spacing: 0.02em;\n}\n\n.icon-button {\n  background: rgba(248, 250, 252, 0.12);\n  color: #f8fafc;\n  border: none;\n  border-radius: 8px;\n  width: 26px;\n  height: 26px;\n  cursor: pointer;\n  font-size: 14px;\n  line-height: 1;\n}\n\n.icon-button:hover {\n  background: rgba(248, 250, 252, 0.24);\n}\n\n.status-grid {\n  display: grid;\n  grid-template-columns: auto 1fr;\n  gap: 6px 12px;\n  padding: 12px 14px;\n  border-bottom: 1px solid #e2e8f0;\n  font-size: 12px;\n  background: #f8fafc;\n}\n\n.status-key {\n  color: #64748b;\n  font-weight: 600;\n}\n\n.status-value {\n  color: #0f172a;\n  font-weight: 600;\n  word-break: break-all;\n}\n\n.dot {\n  display: inline-block;\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  margin-right: 6px;\n  background: #94a3b8;\n}\n\n.dot.connected { background: #16a34a; }\n.dot.offline { background: #dc2626; }\n.dot.error { background: #f59e0b; }\n\n.toolbar {\n  display: flex;\n  gap: 8px;\n  padding: 10px 14px;\n  border-bottom: 1px solid #e2e8f0;\n}\n\n.toolbar select,\n.toolbar button {\n  font-size: 12px;\n  border-radius: 8px;\n  border: 1px solid #cbd5f5;\n  padding: 6px 10px;\n  background: #ffffff;\n  color: #0f172a;\n  cursor: pointer;\n}\n\n.toolbar select { flex: 1; }\n\n.body {\n  overflow-y: auto;\n  padding: 12px 14px;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n}\n\n.empty {\n  font-size: 12px;\n  color: #64748b;\n  text-align: center;\n  padding: 18px 8px;\n  border: 1px dashed #cbd5f5;\n  border-radius: 12px;\n}\n\n.card {\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 12px;\n  background: #ffffff;\n}\n\n.card-head {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 8px;\n}\n\n.card-action {\n  font-size: 13px;\n  font-weight: 700;\n}\n\n.risk {\n  font-size: 10px;\n  font-weight: 800;\n  text-transform: uppercase;\n  padding: 3px 8px;\n  border-radius: 999px;\n  letter-spacing: 0.06em;\n}\n\n.risk.low { background: #dcfce7; color: #166534; }\n.risk.medium { background: #fef3c7; color: #92400e; }\n.risk.high { background: #fee2e2; color: #991b1b; }\n\n.field {\n  font-size: 12px;\n  margin: 4px 0;\n  color: #334155;\n}\n\n.field b { color: #0f172a; }\n\n.mono {\n  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;\n  font-size: 11px;\n  word-break: break-all;\n}\n\n.preview {\n  margin-top: 8px;\n  max-height: 168px;\n  overflow: auto;\n  background: #0f172a;\n  color: #e2e8f0;\n  border-radius: 8px;\n  padding: 10px;\n  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;\n  font-size: 11px;\n  white-space: pre-wrap;\n}\n\n.actions {\n  display: flex;\n  gap: 8px;\n  margin-top: 10px;\n}\n\n.btn {\n  flex: 1;\n  border: none;\n  border-radius: 8px;\n  padding: 8px 10px;\n  font-size: 12px;\n  font-weight: 700;\n  cursor: pointer;\n}\n\n.btn-approve { background: #16a34a; color: #ffffff; }\n.btn-approve:hover { background: #15803d; }\n.btn-reject { background: #e2e8f0; color: #0f172a; }\n.btn-reject:hover { background: #cbd5f5; }\n.btn:disabled { opacity: 0.55; cursor: not-allowed; }\n\n.state {\n  margin-top: 8px;\n  font-size: 11px;\n  font-weight: 700;\n  padding: 6px 8px;\n  border-radius: 8px;\n}\n\n.state.approved { background: #dcfce7; color: #166534; }\n.state.rejected { background: #e2e8f0; color: #475569; }\n.state.failed { background: #fee2e2; color: #991b1b; }\n.state.approving { background: #e0f2fe; color: #075985; }\n\n.footer {\n  padding: 8px 14px;\n  border-top: 1px solid #e2e8f0;\n  font-size: 11px;\n  color: #64748b;\n  background: #f8fafc;\n}\n\n.workflow-dashboard {\n  border-bottom: 1px solid #e2e8f0;\n  padding: 12px 14px;\n  background: linear-gradient(145deg, #f8fafc, #eef6ff);\n}\n\n.dashboard-heading, .dashboard-lower { display: flex; align-items: center; gap: 8px; }\n.dashboard-heading { justify-content: space-between; margin-bottom: 10px; }\n.dashboard-title { font-size: 12px; font-weight: 800; letter-spacing: .04em; }\n.dashboard-badge { font-size: 9px; font-weight: 800; letter-spacing: .08em; color: #0369a1; background: #dbeafe; padding: 3px 6px; border-radius: 999px; }\n.dashboard-empty { color: #64748b; font-size: 11px; line-height: 1.5; }\n.dashboard-stats { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px; }\n.dashboard-stat { min-width: 0; border: 1px solid #dbeafe; border-radius: 8px; padding: 7px; background: #ffffffb8; }\n.dashboard-stat strong, .dashboard-stat small, .dashboard-label { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.dashboard-stat strong { font-size: 12px; color: #0f172a; margin-top: 2px; }\n.dashboard-stat small, .dashboard-label { color: #64748b; font-size: 9px; }\n.workflow-dashboard h4 { margin: 12px 0 6px; color: #334155; font-size: 10px; text-transform: uppercase; letter-spacing: .08em; }\n.workflow-timeline { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 5px; }\n.timeline-stage { min-width: 0; position: relative; border: 1px solid #cbd5e1; border-radius: 8px; padding: 7px 6px; background: #fff; }\n.timeline-stage.done { border-color: #86efac; background: #f0fdf4; }\n.timeline-stage.active { border-color: #60a5fa; background: #eff6ff; }\n.timeline-marker { display: inline-block; color: #94a3b8; font-weight: 800; margin-right: 4px; }\n.timeline-stage.done .timeline-marker { color: #16a34a; }\n.timeline-stage.active .timeline-marker { color: #2563eb; }\n.timeline-stage strong { display: block; font-size: 9px; line-height: 1.2; color: #0f172a; }\n.timeline-stage small { display: block; margin-top: 3px; font-size: 9px; color: #64748b; }\n.timeline-meta { color: #0369a1 !important; }\n.stage-approval { color: #b45309 !important; font-weight: 700; }\n.stage-report { margin-top: 6px; font-size: 9px; }\n.stage-report summary { cursor: pointer; color: #2563eb; }\n.stage-report pre { max-height: 100px; overflow: auto; white-space: pre-wrap; margin: 4px 0 0; padding: 6px; border-radius: 6px; background: #0f172a; color: #e2e8f0; font-size: 9px; }\n.dashboard-lower { align-items: flex-start; gap: 8px; }\n.dashboard-column { min-width: 0; flex: 1; }\n.dashboard-list { display: grid; gap: 4px; color: #475569; font-size: 10px; }\n.dashboard-list-item { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.dashboard-agents { margin-top: 10px; padding-top: 8px; border-top: 1px solid #dbeafe; }\n.agent-summary { margin-bottom: 5px; color: #0369a1; font-size: 10px; font-weight: 700; }\n\n.runtime-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #dbeafe; background: #f8fafc; }\n.runtime-heading { display: flex; justify-content: space-between; align-items: center; color: #0f172a; font-size: 12px; }\n.runtime-badge { color: #475569; background: #e2e8f0; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.runtime-summary { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; margin-top: 8px; }\n.runtime-summary .runtime-item { border: 1px solid #e2e8f0; background: #fff; border-radius: 7px; padding: 6px; font-size: 9px; font-weight: 700; }\n.runtime-block { margin-top: 9px; }\n.runtime-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.runtime-item { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #334155; font-size: 10px; line-height: 1.6; }\n.runtime-item.warning { color: #b45309; font-weight: 700; }\n\n.collaboration-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #dbeafe; background: linear-gradient(145deg, #f8fafc, #f5f3ff); }\n.collaboration-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.collaboration-badge { color: #6d28d9; background: #ede9fe; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.collaboration-summary { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; margin-top: 8px; }\n.collaboration-summary .collaboration-row { border: 1px solid #e2e8f0; border-radius: 7px; padding: 6px; background: #fff; font-size: 9px; font-weight: 700; }\n.collaboration-block { margin-top: 9px; }\n.collaboration-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.collaboration-row { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #334155; font-size: 10px; line-height: 1.6; }\n.collaboration-row.warning { color: #b45309; font-weight: 700; }\n\n@media (max-width: 420px) {\n  .workflow-timeline { grid-template-columns: repeat(2, minmax(0, 1fr)); }\n}\n\n.project-intelligence-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #dbeafe; background: linear-gradient(145deg, #f0fdfa, #eff6ff); }\n.project-intelligence-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.project-intelligence-badge { color: #0f766e; background: #ccfbf1; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.project-intelligence-overview { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; margin-top: 8px; }\n.project-intelligence-overview .project-intelligence-item { border: 1px solid #bae6fd; border-radius: 7px; padding: 6px; background: rgba(255,255,255,.8); color: #155e75; font-size: 9px; font-weight: 700; }\n.project-intelligence-columns { display: grid; gap: 9px; margin-top: 9px; }\n.project-intelligence-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.project-intelligence-item { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #334155; font-size: 10px; line-height: 1.6; }\n.project-intelligence-item.warning { color: #b45309; font-weight: 700; }\n\n.engineering-intelligence-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #99f6e4; background: linear-gradient(145deg, #fff7ed, #f0fdfa); }\n.engineering-intelligence-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.engineering-intelligence-badge { color: #9a3412; background: #ffedd5; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.engineering-intelligence-summary { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; margin-top: 8px; }\n.engineering-intelligence-summary .engineering-intelligence-line { border: 1px solid #fed7aa; border-radius: 7px; padding: 6px; background: rgba(255,255,255,.8); color: #7c2d12; font-size: 9px; font-weight: 700; }\n.engineering-intelligence-blocks { display: grid; gap: 9px; margin-top: 9px; }\n.engineering-intelligence-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.engineering-intelligence-line { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #334155; font-size: 10px; line-height: 1.6; }\n.engineering-intelligence-line.warning { color: #b91c1c; font-weight: 700; }\n.engineering-intelligence-debt { display: block; margin-top: 9px; color: #64748b; font-size: 9px; }\n\n.simulation-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #fed7aa; background: linear-gradient(145deg, #f5f3ff, #fff7ed); }\n.simulation-heading { display: flex; justify-content: space-between; align-items: center; color: #0f172a; font-size: 12px; }\n.simulation-badge { color: #6d28d9; background: #ede9fe; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.simulation-line { margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #475569; font-size: 10px; line-height: 1.5; }\n.simulation-problem { color: #1e1b4b; font-weight: 800; white-space: normal; }\n.simulation-line.warning { color: #b91c1c; font-weight: 800; }\n.simulation-candidates { display: grid; gap: 6px; margin-top: 9px; }\n.simulation-candidate { border: 1px solid #ddd6fe; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.85); }\n.simulation-candidate .simulation-line:first-child { margin-top: 0; color: #312e81; font-weight: 800; }\n.simulation-plan { max-height: 150px; overflow: auto; margin: 9px 0 0; padding: 8px; border-radius: 7px; background: #1e1b4b; color: #ede9fe; white-space: pre-wrap; font: 9px/1.5 ui-monospace, SFMono-Regular, Menlo, monospace; }\n.simulation-quality { color: #166534; font-weight: 800; }\n\n.execution-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #bae6fd; background: linear-gradient(145deg, #f0f9ff, #f8fafc); }\n.execution-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.execution-badge { color: #075985; background: #e0f2fe; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.execution-line { margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #475569; font-size: 10px; line-height: 1.5; }\n.execution-line.warning { color: #b91c1c; font-weight: 800; }\n.execution-line.pass { color: #166534; font-weight: 800; }\n.execution-line.pending { color: #b45309; font-weight: 800; }\n.execution-count { margin-top: 0; color: #0f172a; font-size: 15px; font-weight: 800; }\n.execution-overview { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 5px; margin-top: 8px; }\n.execution-overview .execution-item { border: 1px solid #bae6fd; border-radius: 7px; padding: 6px; background: rgba(255,255,255,.85); }\n.execution-block { margin-top: 9px; }\n.execution-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.execution-task, .execution-proposal, .execution-result { border: 1px solid #e2e8f0; border-radius: 7px; padding: 6px; background: #fff; margin-bottom: 4px; }\n.execution-task .execution-line:first-child, .execution-proposal .execution-line:first-child, .execution-result .execution-line:first-child { margin-top: 0; color: #0c4a6e; font-weight: 800; }\n\n.execution-loop-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #d8b4fe; background: linear-gradient(145deg, #f5f3ff, #f0f9ff); }\n.execution-loop-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.execution-loop-badge { color: #6d28d9; background: #ede9fe; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.loop-line { margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #475569; font-size: 10px; line-height: 1.5; }\n.loop-line.warning { color: #b91c1c; font-weight: 800; }\n.loop-line.pass { color: #166534; font-weight: 800; }\n.loop-line.pending { color: #b45309; font-weight: 800; }\n.execution-loop-block { margin-top: 9px; }\n.execution-loop-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.execution-loop-card { border: 1px solid #ddd6fe; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.85); margin-bottom: 5px; }\n.execution-loop-card .loop-line:first-child { margin-top: 0; color: #312e81; font-weight: 800; }\n.execution-loop-steps { display: flex; flex-wrap: wrap; gap: 3px; margin-top: 5px; }\n.execution-loop-step { font-size: 8px; font-weight: 800; letter-spacing: .04em; color: #475569; background: #e2e8f0; border-radius: 999px; padding: 2px 6px; }\n.execution-loop-step.pass { color: #166534; background: #dcfce7; }\n.execution-loop-step.pending { color: #b45309; background: #fef3c7; }\n.execution-loop-step.warning { color: #991b1b; background: #fee2e2; }\n.execution-loop-quality { border: 1px solid #c4b5fd; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.85); }\n.execution-loop-step-row { margin-top: 4px; }\n.execution-loop-step-row .loop-line:first-child { margin-top: 0; }\n.execution-orchestration-block { border-top: 1px solid #bae6fd; padding-top: 8px; }\n.execution-orchestration-block .loop-line { white-space: normal; }\n\n.engineering-graph-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #99f6e4; background: linear-gradient(145deg, #ecfeff, #f0fdf4); }\n.engineering-graph-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.engineering-graph-badge { color: #0f766e; background: #ccfbf1; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.engineering-graph-line { margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #475569; font-size: 10px; line-height: 1.5; }\n.engineering-graph-line.warning { color: #b91c1c; font-weight: 800; }\n.engineering-graph-blocks { display: grid; gap: 9px; margin-top: 9px; }\n.engineering-graph-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.engineering-graph-block { border: 1px solid #a7f3d0; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.82); }\n.engineering-graph-block .engineering-graph-line:first-child { margin-top: 0; color: #115e59; font-weight: 800; }\n\n.governance-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #e9d5ff; background: linear-gradient(145deg, #faf5ff, #f8fafc); }\n.governance-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.governance-badge { color: #6d28d9; background: #ede9fe; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.governance-line { margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #475569; font-size: 10px; line-height: 1.5; }\n.governance-line.warning { color: #b91c1c; font-weight: 800; }\n.governance-line.pass { color: #166534; font-weight: 800; }\n.governance-line.pending { color: #b45309; font-weight: 800; }\n.governance-stats { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; margin-top: 8px; }\n.governance-score { border: 1px solid #ddd6fe; border-radius: 7px; padding: 6px; background: rgba(255,255,255,.85); color: #0f172a; font-size: 13px; font-weight: 800; text-align: center; }\n.governance-block { margin-top: 9px; }\n.governance-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.governance-block .governance-line:first-child { margin-top: 0; }\n\n.organization-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #7dd3fc; background: linear-gradient(145deg, #eff6ff, #f8fafc); }\n.organization-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.organization-badge { color: #0369a1; background: #e0f2fe; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.organization-line { margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #475569; font-size: 10px; line-height: 1.5; }\n.organization-line.warning { color: #b91c1c; font-weight: 800; }\n.organization-line.pass { color: #166534; font-weight: 800; }\n.organization-line.pending { color: #b45309; font-weight: 800; }\n.organization-stats { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; margin-top: 8px; }\n.organization-score { border: 1px solid #bae6fd; border-radius: 7px; padding: 6px; background: rgba(255,255,255,.85); color: #0f172a; font-size: 13px; font-weight: 800; text-align: center; }\n.organization-block { margin-top: 9px; }\n.organization-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.organization-block .organization-line:first-child { margin-top: 0; }\n\n.engineering-intelligence-evolution-title { margin: 12px 0 6px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.engineering-intelligence-evolution-summary { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; }\n.engineering-intelligence-evolution-summary .engineering-intelligence-line { border: 1px solid #99f6e4; border-radius: 7px; padding: 6px; background: rgba(255,255,255,.8); color: #115e59; font-size: 9px; font-weight: 700; }\n.engineering-intelligence-evolution-block { margin-top: 8px; border: 1px solid #99f6e4; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.78); }\n.engineering-intelligence-evolution-block .engineering-intelligence-line:first-child { margin-top: 0; }\n.engineering-intelligence-line.recommendation { color: #0f766e; white-space: normal; }\n.engineering-intelligence-phase26-title { margin: 12px 0 6px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.engineering-intelligence-phase26-summary { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; }\n.engineering-intelligence-phase26-summary .engineering-intelligence-line { border: 1px solid #bfdbfe; border-radius: 7px; padding: 6px; background: rgba(255,255,255,.8); color: #1d4ed8; font-size: 9px; font-weight: 700; }\n.engineering-intelligence-phase26-block { margin-top: 8px; border: 1px solid #bfdbfe; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.78); }\n.engineering-intelligence-phase26-block .engineering-intelligence-line:first-child { margin-top: 0; }\n\n/* Phase 29 · Developer Context (read-only) */\n.developer-context-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #fde68a; background: linear-gradient(145deg, #fffbeb, #f8fafc); }\n.developer-context-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.developer-context-badge { color: #a16207; background: #fef3c7; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.developer-context-line { margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #475569; font-size: 10px; line-height: 1.5; }\n.developer-context-line.warning { color: #b91c1c; font-weight: 800; }\n.developer-context-meta { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 5px; margin-top: 8px; }\n.developer-context-summary-row { border: 1px solid #fde68a; border-radius: 7px; padding: 5px 6px; background: rgba(255,255,255,.85); display: flex; justify-content: space-between; gap: 4px; }\n.developer-context-summary-row[data-tone="warn"] { border-color: #fecaca; color: #b91c1c; }\n.developer-context-summary-row[data-tone="ok"] { border-color: #a7f3d0; color: #166534; }\n.developer-context-summary-key { color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .06em; }\n.developer-context-summary-value { color: #0f172a; font-size: 10px; font-weight: 700; }\n.developer-context-preview { margin-top: 9px; border: 1px solid #fde68a; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.78); }\n.developer-context-preview h4 { margin: 0 0 4px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.developer-context-note { color: #92400e; font-size: 9px; line-height: 1.5; margin-bottom: 6px; }\n.developer-context-preview-row { display: flex; align-items: center; gap: 6px; padding: 3px 0; }\n.developer-context-preview-label { color: #0f172a; font-size: 10px; font-weight: 700; min-width: 96px; }\n.developer-context-preview-detail { color: #64748b; font-size: 9px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.developer-context-selected { margin-top: 6px; border-top: 1px dashed #fde68a; padding-top: 6px; color: #92400e; font-size: 9px; font-weight: 700; }\n.developer-context-block { margin-top: 9px; border: 1px solid #fde68a; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.78); }\n.developer-context-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.developer-context-block .developer-context-line:first-child { margin-top: 0; }\n.developer-context-footer { margin-top: 9px; color: #92400e; font-size: 9px; font-weight: 700; }\n\n/* Phase 30 · Context Intelligence (read-only) */\n.phase30-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #bfdbfe; background: linear-gradient(145deg, #eff6ff, #f8fafc); }\n.phase30-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.phase30-badge { color: #1d4ed8; background: #dbeafe; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.phase30-line { margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #475569; font-size: 10px; line-height: 1.5; }\n.phase30-line.warn { color: #b45309; font-weight: 700; }\n.phase30-line.danger { color: #b91c1c; font-weight: 800; }\n.phase30-line.ok { color: #166534; }\n.phase30-block { margin-top: 9px; border: 1px solid #bfdbfe; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.78); }\n.phase30-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.phase30-block .phase30-line:first-child { margin-top: 0; }\n.phase30-row { display: flex; align-items: center; gap: 5px; margin-top: 4px; color: #475569; font-size: 10px; min-width: 0; }\n.phase30-row-name { color: #16a34a; font-weight: 800; }\n.phase30-reason { color: #64748b; font-size: 9px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.phase30-severity { border-radius: 999px; padding: 1px 5px; font-size: 8px; font-weight: 800; text-transform: uppercase; }\n.phase30-severity.danger { color: #b91c1c; background: #fee2e2; }\n\n/* Phase 31 · LLM Gateway dashboard (read-only) */\n.llm-dashboard { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #c7d2fe; background: linear-gradient(145deg, #eef2ff, #f8fafc); }\n.llm-heading { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 12px; }\n.llm-badge { color: #4338ca; background: #e0e7ff; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.llm-line { margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #475569; font-size: 10px; line-height: 1.5; }\n.llm-line.warn { color: #b45309; font-weight: 700; }\n.llm-line.danger { color: #b91c1c; font-weight: 800; }\n.llm-line.ok { color: #166534; }\n.llm-block { margin-top: 9px; border: 1px solid #c7d2fe; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.78); }\n.llm-block h4 { margin: 0 0 5px; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .08em; }\n.llm-block .llm-line:first-child { margin-top: 0; }\n.llm-footer { margin-top: 9px; color: #64748b; font-size: 9px; line-height: 1.5; }\n.phase30-severity.warn { color: #b45309; background: #fef3c7; }\n.phase30-severity.ok { color: #166534; background: #dcfce7; }\n.phase30-footer { margin-top: 9px; color: #1d4ed8; font-size: 9px; font-weight: 700; }\n\n/* Phase 32 · AI Assistant (User Mode default; Developer Mode adds read-only extras) */\n.assistant-surface { margin: 0 -14px; padding: 12px 14px; border-top: 1px solid #ddd6fe; background: linear-gradient(145deg, #f5f3ff, #f8fafc); }\n.assistant-mode-toggle { display: flex; align-items: center; justify-content: space-between; gap: 6px; }\n.assistant-mode-button { border: 1px solid #c4b5fd; border-radius: 7px; padding: 3px 7px; background: #ede9fe; color: #5b21b6; font-size: 9px; font-weight: 800; cursor: pointer; }\n.assistant-badge { color: #5b21b6; background: #ede9fe; border-radius: 999px; padding: 3px 6px; font-size: 8px; font-weight: 800; letter-spacing: .08em; }\n.assistant-model-selector { display: flex; align-items: center; gap: 6px; margin-top: 8px; flex-wrap: wrap; }\n.assistant-field { display: flex; align-items: center; gap: 5px; min-width: 0; }\n.assistant-field-label { color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .06em; }\n.assistant-select { border: 1px solid #c4b5fd; border-radius: 6px; padding: 2px 4px; background: #fff; color: #0f172a; font-size: 10px; max-width: 130px; }\n.assistant-input { border: 1px solid #c4b5fd; border-radius: 6px; padding: 4px 6px; background: #fff; color: #0f172a; font-size: 10px; width: 100%; box-sizing: border-box; font-family: inherit; }\n\n.assistant-context-block { margin-top: 9px; }\n.assistant-ask-ai { border: 1px solid #a78bfa; border-radius: 7px; padding: 4px 9px; background: #7c3aed; color: #fff; font-size: 10px; font-weight: 800; cursor: pointer; }\n.assistant-context { margin-top: 7px; border: 1px solid #ddd6fe; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.82); }\n.assistant-context-head { display: flex; align-items: center; justify-content: space-between; color: #0f172a; font-size: 11px; font-weight: 700; }\n.assistant-context-line { display: flex; align-items: center; gap: 5px; margin-top: 4px; min-width: 0; }\n.assistant-context-label { color: #64748b; font-size: 9px; min-width: 96px; }\n.assistant-context-value { color: #0f172a; font-size: 10px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.assistant-context-note { margin-top: 6px; color: #6d28d9; font-size: 9px; line-height: 1.5; }\n.assistant-context-clear { margin-top: 6px; border: 1px solid #c4b5fd; border-radius: 6px; padding: 2px 6px; background: #fff; color: #5b21b6; font-size: 9px; font-weight: 700; cursor: pointer; }\n\n.assistant-chat { margin-top: 9px; border: 1px solid #ddd6fe; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.82); }\n.assistant-history { border-bottom: 1px dashed #ddd6fe; padding-bottom: 6px; }\n.assistant-history-head { display: flex; align-items: center; justify-content: space-between; color: #64748b; font-size: 9px; text-transform: uppercase; letter-spacing: .06em; }\n.assistant-new-chat { border: 1px solid #c4b5fd; border-radius: 6px; padding: 2px 6px; background: #ede9fe; color: #5b21b6; font-size: 9px; font-weight: 800; cursor: pointer; }\n.assistant-history-empty { margin-top: 5px; color: #94a3b8; font-size: 9px; }\n.assistant-history-entry { display: flex; align-items: center; gap: 5px; margin-top: 4px; min-width: 0; }\n.assistant-history-entry.active .assistant-history-open { color: #5b21b6; font-weight: 800; }\n.assistant-history-open { flex: 1; border: none; background: none; padding: 0; text-align: left; color: #334155; font-size: 10px; cursor: pointer; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.assistant-history-remove { border: 1px solid #e2e8f0; border-radius: 6px; padding: 1px 5px; background: #fff; color: #64748b; font-size: 8px; cursor: pointer; }\n\n.assistant-transcript { margin-top: 7px; display: flex; flex-direction: column; gap: 7px; }\n.assistant-transcript-empty { color: #94a3b8; font-size: 10px; line-height: 1.5; }\n.assistant-message { border: 1px solid #e2e8f0; border-radius: 8px; padding: 6px 7px; background: #fff; }\n.assistant-message.user { border-color: #ddd6fe; background: #f5f3ff; }\n.assistant-message-role { color: #64748b; font-size: 8px; text-transform: uppercase; letter-spacing: .08em; }\n.assistant-message-body { margin-top: 3px; color: #0f172a; font-size: 10px; line-height: 1.55; white-space: pre-wrap; word-break: break-word; }\n.assistant-message-state { margin-top: 4px; color: #6d28d9; font-size: 9px; font-weight: 700; }\n\n.assistant-markdown { margin-top: 3px; color: #0f172a; font-size: 10px; line-height: 1.55; word-break: break-word; }\n.assistant-paragraph { margin: 4px 0; }\n.assistant-heading { margin: 6px 0 3px; font-size: 11px; }\n.assistant-list { margin: 4px 0 4px 16px; padding: 0; }\n.assistant-quote { margin: 4px 0; border-left: 2px solid #c4b5fd; padding-left: 6px; color: #475569; }\n.assistant-inline-code { border-radius: 4px; padding: 0 3px; background: #f1f5f9; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 9px; }\n.assistant-code { margin: 5px 0; border: 1px solid #e2e8f0; border-radius: 7px; overflow: hidden; }\n.assistant-code-head { display: flex; align-items: center; justify-content: space-between; padding: 3px 6px; background: #f8fafc; }\n.assistant-code-language { color: #64748b; font-size: 8px; text-transform: uppercase; letter-spacing: .06em; }\n.assistant-code-copy { border: 1px solid #e2e8f0; border-radius: 6px; padding: 1px 6px; background: #fff; color: #334155; font-size: 8px; font-weight: 700; cursor: pointer; }\n.assistant-code-body { margin: 0; padding: 6px; background: #0f172a; color: #e2e8f0; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 9px; overflow-x: auto; }\n\n.assistant-tool-proposal { margin-top: 6px; border: 1px solid #fde68a; border-radius: 7px; padding: 6px; background: #fffbeb; }\n.assistant-tool-head { display: flex; align-items: center; justify-content: space-between; gap: 5px; }\n.assistant-tool-name { color: #92400e; font-size: 10px; font-weight: 800; }\n.assistant-tool-state { color: #a16207; background: #fef3c7; border-radius: 999px; padding: 1px 6px; font-size: 8px; font-weight: 800; text-transform: uppercase; }\n.assistant-tool-arguments { margin: 5px 0 0; padding: 5px; border-radius: 6px; background: #fff; color: #334155; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 9px; overflow-x: auto; }\n.assistant-tool-note { margin-top: 5px; color: #92400e; font-size: 9px; line-height: 1.5; }\n\n.assistant-loading { margin-top: 7px; color: #6d28d9; font-size: 9px; font-weight: 700; }\n.assistant-status { margin-top: 7px; color: #64748b; font-size: 9px; line-height: 1.5; }\n.assistant-composer { display: flex; align-items: flex-end; gap: 5px; margin-top: 7px; }\n.assistant-send, .assistant-stop { border: 1px solid #a78bfa; border-radius: 7px; padding: 4px 9px; background: #7c3aed; color: #fff; font-size: 10px; font-weight: 800; cursor: pointer; }\n.assistant-send[disabled] { background: #cbd5e1; border-color: #cbd5e1; cursor: not-allowed; }\n.assistant-stop { background: #fff; color: #b91c1c; border-color: #fecaca; }\n\n.assistant-settings { margin-top: 9px; border: 1px solid #ddd6fe; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.82); display: flex; flex-direction: column; gap: 5px; }\n.assistant-settings-head { color: #0f172a; font-size: 11px; font-weight: 700; }\n.assistant-settings .assistant-field { display: flex; align-items: center; gap: 6px; }\n.assistant-settings .assistant-field-label { min-width: 66px; }\n.assistant-settings-actions { display: flex; gap: 5px; flex-wrap: wrap; }\n.assistant-settings-test, .assistant-settings-save, .assistant-settings-forget { border: 1px solid #c4b5fd; border-radius: 7px; padding: 3px 8px; background: #ede9fe; color: #5b21b6; font-size: 9px; font-weight: 800; cursor: pointer; }\n.assistant-settings-forget { border-color: #fecaca; background: #fff; color: #b91c1c; }\n.assistant-settings-result { border-radius: 6px; padding: 4px 6px; background: #f1f5f9; color: #334155; font-size: 9px; font-weight: 700; }\n.assistant-settings-result[data-status="connected"] { background: #dcfce7; color: #166534; }\n.assistant-settings-result[data-status="failed"] { background: #fee2e2; color: #b91c1c; }\n.assistant-provider-list { display: flex; flex-direction: column; gap: 4px; }\n.assistant-provider-row { display: flex; align-items: center; justify-content: space-between; gap: 5px; border: 1px solid #e2e8f0; border-radius: 7px; padding: 3px 6px; background: #fff; }\n.assistant-provider-name { color: #0f172a; font-size: 10px; font-weight: 700; }\n.assistant-provider-hint { color: #64748b; font-size: 8px; }\n.assistant-settings-note { color: #6d28d9; font-size: 9px; line-height: 1.5; }\n\n.developer-surface { margin-top: 4px; }\n.assistant-dev-context { margin: 9px -14px 0; padding: 12px 14px; border-top: 1px solid #ddd6fe; background: linear-gradient(145deg, #f5f3ff, #f8fafc); }\n\n/* Phase 34 · onboarding, context bundle, conversation management, retry */\n.assistant-onboarding { margin-top: 9px; border: 1px solid #c4b5fd; border-radius: 8px; padding: 8px; background: rgba(255,255,255,.9); }\n.assistant-onboarding-head { display: flex; align-items: center; justify-content: space-between; gap: 6px; }\n.assistant-onboarding-title { color: #0f172a; font-size: 11px; font-weight: 800; }\n.assistant-onboarding-progress { color: #5b21b6; background: #ede9fe; border-radius: 999px; padding: 2px 6px; font-size: 8px; font-weight: 800; }\n.assistant-onboarding-steps { margin: 6px 0 0; padding-left: 16px; display: flex; flex-direction: column; gap: 3px; list-style: decimal; }\n.assistant-onboarding-step { color: #64748b; font-size: 9px; line-height: 1.5; }\n.assistant-onboarding-step.current { color: #0f172a; }\n.assistant-onboarding-step.done { color: #94a3b8; text-decoration: line-through; }\n.assistant-onboarding-step-title { font-weight: 700; }\n.assistant-onboarding-detail { margin-top: 2px; color: #334155; font-size: 9px; line-height: 1.5; }\n.assistant-onboarding-signal { margin-top: 2px; color: #6d28d9; font-size: 8px; font-weight: 700; }\n.assistant-onboarding-note { margin-top: 6px; color: #6d28d9; font-size: 9px; line-height: 1.5; }\n.assistant-onboarding-actions { display: flex; gap: 5px; flex-wrap: wrap; margin-top: 7px; }\n.assistant-onboarding-primary { border: 1px solid #a78bfa; border-radius: 7px; padding: 3px 9px; background: #7c3aed; color: #fff; font-size: 9px; font-weight: 800; cursor: pointer; }\n.assistant-onboarding-secondary { border: 1px solid #c4b5fd; border-radius: 7px; padding: 3px 8px; background: #ede9fe; color: #5b21b6; font-size: 9px; font-weight: 800; cursor: pointer; }\n.assistant-onboarding-hint { display: flex; align-items: center; justify-content: space-between; gap: 6px; margin-top: 9px; border: 1px dashed #c4b5fd; border-radius: 8px; padding: 5px 7px; color: #5b21b6; font-size: 9px; }\n\n.assistant-context-panel { margin-top: 7px; border: 1px solid #ddd6fe; border-radius: 8px; padding: 7px; background: rgba(255,255,255,.82); }\n.assistant-context-panel[data-include="false"] { border-style: dashed; }\n.assistant-context-panel-head { display: flex; align-items: center; justify-content: space-between; gap: 6px; }\n.assistant-context-panel-title { color: #0f172a; font-size: 11px; font-weight: 700; }\n.assistant-context-injected { margin: 6px 0 0; padding: 6px; border-radius: 6px; max-height: 132px; background: #0f172a; color: #e2e8f0; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 9px; line-height: 1.5; white-space: pre-wrap; word-break: break-word; overflow: auto; }\n.assistant-context-decision { margin-top: 6px; color: #6d28d9; font-size: 9px; font-weight: 700; line-height: 1.5; }\n.assistant-context-include { margin-top: 6px; border: 1px solid #c4b5fd; border-radius: 6px; padding: 2px 7px; background: #ede9fe; color: #5b21b6; font-size: 9px; font-weight: 800; cursor: pointer; }\n.assistant-context-include[data-include="false"] { border-color: #a78bfa; background: #7c3aed; color: #fff; }\n\n.assistant-history-search { width: 100%; box-sizing: border-box; margin-top: 5px; border: 1px solid #ddd6fe; border-radius: 6px; padding: 3px 6px; background: #fff; color: #0f172a; font-size: 9px; font-family: inherit; }\n.assistant-history-entry.pinned .assistant-history-open { color: #5b21b6; }\n.assistant-history-pin, .assistant-history-rename-open { border: 1px solid #e2e8f0; border-radius: 6px; padding: 1px 5px; background: #fff; color: #64748b; font-size: 8px; cursor: pointer; }\n.assistant-history-rename { display: flex; align-items: center; gap: 4px; width: 100%; margin-top: 4px; }\n.assistant-history-rename-input { flex: 1; min-width: 0; border: 1px solid #c4b5fd; border-radius: 6px; padding: 2px 5px; background: #fff; color: #0f172a; font-size: 9px; font-family: inherit; }\n.assistant-history-rename-save { border: 1px solid #a78bfa; border-radius: 6px; padding: 1px 6px; background: #7c3aed; color: #fff; font-size: 8px; font-weight: 800; cursor: pointer; }\n.assistant-history-rename-cancel { border: 1px solid #e2e8f0; border-radius: 6px; padding: 1px 6px; background: #fff; color: #64748b; font-size: 8px; cursor: pointer; }\n.assistant-history-note { margin-top: 6px; color: #94a3b8; font-size: 8px; line-height: 1.5; }\n\n.assistant-message-state.failed { color: #b91c1c; }\n.assistant-retry { margin-top: 7px; border: 1px solid #c4b5fd; border-radius: 7px; padding: 3px 9px; background: #fff; color: #5b21b6; font-size: 9px; font-weight: 800; cursor: pointer; }\n.assistant-composer-hint { width: 100%; margin-top: 4px; color: #94a3b8; font-size: 8px; }\n.assistant-composer { flex-wrap: wrap; }\n';
  const HOST_ID = "ccb-extension-root";
  function mountShadowHost(doc = document) {
    const existing = doc.getElementById(HOST_ID);
    existing?.remove();
    const host = doc.createElement("div");
    host.id = HOST_ID;
    host.setAttribute("data-ccb", "root");
    host.style.setProperty("all", "initial");
    const shadow = host.attachShadow({ mode: "open" });
    const styleEl = doc.createElement("style");
    styleEl.textContent = styles;
    shadow.appendChild(styleEl);
    const container = doc.createElement("div");
    container.className = "ccb-container";
    shadow.appendChild(container);
    (doc.body ?? doc.documentElement).appendChild(host);
    return {
      host,
      shadow,
      container,
      destroy() {
        host.remove();
      }
    };
  }
  const ATTACH_RETRY_MS = 1500;
  const MAX_ATTACH_ATTEMPTS = 20;
  async function bootstrap() {
    if (!defaultSelectorAdapter.isChatGPTHost(window.location.hostname)) {
      return;
    }
    if (document.getElementById("ccb-extension-root")) {
      return;
    }
    const store = new ExtensionStore();
    await store.hydrate();
    const state = store.getState();
    const client = new BridgeClient({ origin: state.bridgeOrigin });
    const ui = mountShadowHost(document);
    let panel;
    const render = () => panel.render(store.getState());
    const controller = new Controller({
      store,
      client,
      render: () => render(),
      onProjects: (projects) => panel.setProjects(projects)
    });
    panel = new Panel(document, ui.container, {
      onConnect: () => void controller.connect(),
      onSelectProject: (project) => void controller.selectProject(project),
      onApprove: (id) => void controller.approve(id),
      onReject: (id) => void controller.reject(id),
      onReconfirm: (requestId) => void controller.reconfirm(requestId),
      onApproveRecovered: (requestId) => void controller.approveRecovered(requestId),
      onToggleContextSelection: (id) => void store.toggleDevContextSelection(id),
      // Phase 32 · assistant surfaces. Every callback below is driven by a click.
      onSetMode: (mode) => void controller.setUiMode(mode),
      onSelectProvider: (provider) => void controller.selectAssistantProvider(provider),
      onSelectModel: (model) => void controller.selectAssistantModel(model),
      onSaveProvider: (input) => void controller.saveProvider(input),
      onTestConnection: (input) => void controller.testProvider(input),
      onForgetKey: (provider) => void controller.forgetProviderKey(provider),
      onSend: (text2) => void controller.sendAssistantMessage(text2),
      onStop: () => void controller.stopAssistant(),
      onNewChat: () => void controller.newConversation(),
      onSelectConversation: (id) => void controller.selectConversation(id),
      onRemoveConversation: (id) => void controller.removeConversation(id),
      onAskAi: (bundle) => void controller.askAi(bundle),
      onClearContext: () => void controller.clearWebContext(),
      // Phase 34 · retry, conversation management, context decision and the
      // first-run guide. All of them are clicks; none of them auto-sends anything.
      onRetry: () => void controller.retryAssistant(),
      onSearchConversations: (query) => void controller.searchConversations(query),
      onBeginRename: (id) => void controller.beginRenameConversation(id),
      onRename: (id, title) => void controller.renameConversation(id, title),
      onCancelRename: () => void controller.cancelRenameConversation(),
      onTogglePin: (id) => void controller.toggleConversationPinned(id),
      onToggleContextInclude: (include) => void controller.toggleContextInclude(include),
      onNext: () => void controller.onboardingNext(),
      onBack: () => void controller.onboardingBack(),
      onSkip: () => void controller.onboardingSkip(),
      onSetupLater: () => void controller.onboardingLater(),
      onFinish: () => void controller.onboardingFinish(),
      onReopen: () => void controller.onboardingReopen()
    });
    render();
    const observer = new ConversationObserver({
      adapter: defaultSelectorAdapter,
      onResults: (results) => void controller.handleParseResults(results)
    });
    let attempts = 0;
    const attach = () => {
      if (observer.start(document)) return;
      attempts += 1;
      if (attempts < MAX_ATTACH_ATTEMPTS) {
        setTimeout(attach, ATTACH_RETRY_MS);
      }
    };
    attach();
    void controller.connect();
    window.setInterval(() => {
      void controller.refreshApprovals();
      void controller.refreshContext();
    }, 1e4);
  }
  void bootstrap();
})();
