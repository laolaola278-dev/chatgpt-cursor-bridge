(function() {
  "use strict";
  const DEFAULT_BRIDGE_ORIGIN = "http://127.0.0.1:8765";
  const ONBOARDING_STEPS = Object.freeze([
    Object.freeze({
      id: "start_bridge",
      title: "Start Local Bridge",
      detail: "Run: uvicorn app.main:app --port 8765 — the extension talks to 127.0.0.1 only."
    }),
    Object.freeze({
      id: "configure_provider",
      title: "Configure Provider",
      detail: "Open Settings and pick a provider. The API key goes to the Bridge and is encrypted there."
    }),
    Object.freeze({
      id: "test_connection",
      title: "Test Connection",
      detail: "Use Test connection in Settings. The result is a fixed status word, never a provider response."
    }),
    Object.freeze({
      id: "start_chat",
      title: "Start Chat",
      detail: "Ask a question. The assistant explains and drafts; every change stays a proposal."
    })
  ]);
  ONBOARDING_STEPS.length;
  const STORAGE_KEY = "ccb_state_v1";
  function createInitialState() {
    return {
      bridgeStatus: "unknown",
      bridgeOrigin: DEFAULT_BRIDGE_ORIGIN,
      currentProject: null,
      uiMode: "user",
      onboardingState: "new",
      onboardingStep: 0,
      assistantProvider: "local",
      assistantModel: "",
      assistantSettings: null,
      assistantProviders: [],
      assistantProviderTest: null,
      assistantContextStatus: null,
      assistantWebContext: null,
      assistantConversations: [],
      assistantActiveConversation: null,
      assistantStreaming: false,
      assistantStatus: "",
      assistantConversationQuery: "",
      assistantRenaming: null,
      assistantContextInclude: true,
      assistantDraft: "",
      pendingActions: [],
      lastResult: null,
      projectContext: null,
      devContext: null,
      devContextSelection: [],
      phase30Intelligence: null,
      llmProviders: [],
      llmModels: [],
      llmConversations: [],
      llmToolProposals: [],
      recoveredApprovals: [],
      sessions: [],
      agents: [],
      modelSelection: null,
      runtimes: [],
      tasks: [],
      runtimeEvents: [],
      qualityReport: null,
      teams: [],
      dependencies: [],
      collaborationEvents: [],
      projectProfile: null,
      projectGraph: null,
      impactReport: null,
      projectMemoryHistory: null,
      intelligenceInsights: [],
      intelligenceProposals: [],
      intelligenceDecisions: [],
      intelligenceQuality: null,
      intelligenceObservations: [],
      intelligencePatterns: [],
      intelligencePredictions: [],
      intelligenceRecommendations: [],
      intelligenceOutcomes: [],
      intelligenceKnowledge: [],
      intelligenceEvidence: [],
      intelligenceQuality11: null,
      intelligenceTrends: [],
      intelligenceCorrelations: [],
      intelligenceImpactPredictions: [],
      intelligenceDependencyRisks: [],
      intelligenceEvaluations: [],
      intelligenceEvaluationMetrics: null,
      intelligenceRecommendationRanking: null,
      intelligenceEvidenceGraph: null,
      intelligenceValidation: null,
      intelligenceAccuracy: null,
      intelligenceEffectiveness: [],
      intelligenceEffectivenessSummary: null,
      intelligenceDecisionOutcomes: [],
      intelligenceDecisionSummary: null,
      intelligenceBenchmarks: [],
      intelligenceImprovements: [],
      intelligenceGovernance: null,
      simulation: null,
      simulationScenarios: [],
      simulationEvaluations: [],
      simulationPlans: [],
      simulationQuality: null,
      planningMemoryHistory: null,
      executionTasks: [],
      executionProposals: [],
      executionResults: [],
      executionQuality7: null,
      executionMemoryHistory: null,
      executionLoops: [],
      executionLoopTimeline: [],
      executionLoopQuality8: null,
      executionDags: [],
      executionDagReady: null,
      engineeringMetrics: null,
      executionLoopContext: null,
      engineeringGraph: null,
      failurePatterns: [],
      evolutionTimeline: [],
      agentCapabilityMetrics: [],
      benchmarks: [],
      demoScenarios: [],
      demoFlow: [],
      replays: [],
      artifacts: [],
      governanceHealth: null,
      governanceDrift: null,
      governanceDebt: null,
      governancePolicies: null,
      governanceTimeline: null,
      governanceQuality9: null,
      organizationGraph: null,
      organizationHealth: null,
      organizationDashboard: null,
      organizationPatterns: null,
      organizationIncidents: null,
      organizationLearning: null,
      organizationQuality10: null,
      organizationStrategyImpact: null,
      organizationStrategyRisk: null,
      organizationStrategies: null,
      organizationRecommendations: null,
      organizationStrategyContext: null,
      lastContextRefresh: null,
      log: []
    };
  }
  chrome.runtime.onInstalled.addListener(() => {
    void chrome.storage.local.get(STORAGE_KEY).then((stored) => {
      if (!stored[STORAGE_KEY]) {
        void chrome.storage.local.set({ [STORAGE_KEY]: createInitialState() });
      }
    });
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "ccb:ping") {
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === "ccb:get-state") {
      void chrome.storage.local.get(STORAGE_KEY).then((stored) => {
        sendResponse({ ok: true, state: stored[STORAGE_KEY] ?? createInitialState() });
      });
      return true;
    }
    return false;
  });
})();
